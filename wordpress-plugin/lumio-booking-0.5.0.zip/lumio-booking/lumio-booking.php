<?php
/**
 * Plugin Name:       Lumio Booking
 * Plugin URI:        https://lumiobooking.com
 * Description:        Embed your salon's Lumio booking form on WordPress AND manage everything (dashboard, calendar, bookings) right inside wp-admin. Configure the booking URL + salon slug under Lumio Booking → Settings, then add the [lumio_booking] shortcode to any page.
 * Version:           0.5.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Lumio
 * License:           GPL-2.0-or-later
 * Text Domain:       lumio-booking
 */

if (!defined('ABSPATH')) {
    exit; // No direct access.
}

/* Everything is guarded so a duplicate/leftover copy can never cause a
 * "Cannot redeclare function" fatal error on activation. The first copy to
 * load wins; any other copy quietly no-ops. */
if (!function_exists('lumio_booking_base')) {

    if (!defined('LUMIO_BOOKING_OPT_SITE_URL')) {
        define('LUMIO_BOOKING_OPT_SITE_URL', 'lumio_booking_site_url'); // hosted web base
    }
    if (!defined('LUMIO_BOOKING_OPT_SLUG')) {
        define('LUMIO_BOOKING_OPT_SLUG', 'lumio_booking_slug');         // salon slug
    }

    /** Base URL of the hosted Lumio app (defaults to the public domain). */
    function lumio_booking_base()
    {
        $u = get_option(LUMIO_BOOKING_OPT_SITE_URL, '');
        return $u ? rtrim($u, '/') : 'https://lumiobooking.com';
    }

    /* ---- Admin menu: salon-admin dashboard embedded inside wp-admin ---- */
    add_action('admin_menu', function () {
        add_menu_page('Lumio Booking', 'Lumio Booking', 'manage_options', 'lumio-booking', 'lumio_booking_page_dashboard', 'dashicons-calendar-alt', 26);
        add_submenu_page('lumio-booking', 'Dashboard', 'Dashboard', 'manage_options', 'lumio-booking', 'lumio_booking_page_dashboard');
        add_submenu_page('lumio-booking', 'Calendar', 'Calendar', 'manage_options', 'lumio-booking-calendar', 'lumio_booking_page_calendar');
        add_submenu_page('lumio-booking', 'Bookings', 'Bookings', 'manage_options', 'lumio-booking-bookings', 'lumio_booking_page_bookings');
        add_submenu_page('lumio-booking', 'Settings', 'Settings', 'manage_options', 'lumio-booking-settings', 'lumio_booking_render_settings_page');
    });

    /** Render one embedded salon-admin page (an iframe into the hosted app). */
    function lumio_booking_embed($path, $title)
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $src = esc_url(lumio_booking_base() . $path);
        echo '<div class="wrap">';
        echo '<h1>' . esc_html($title) . '</h1>';
        echo '<p style="color:#646970;margin:4px 0 12px">Your salon overview. If prompted, sign in with your Lumio salon admin account.</p>';
        echo '<iframe src="' . $src . '" title="' . esc_attr($title) . '" allow="payment; clipboard-write" ';
        echo 'style="width:100%;height:calc(100vh - 170px);min-height:600px;border:1px solid #c3c4c7;border-radius:10px;background:#0b1120;"></iframe>';
        echo '</div>';
    }

    function lumio_booking_page_dashboard() { lumio_booking_embed('/salon', 'Lumio Dashboard'); }
    function lumio_booking_page_calendar()  { lumio_booking_embed('/salon/calendar', 'Calendar'); }
    function lumio_booking_page_bookings()  { lumio_booking_embed('/salon/bookings', 'Bookings'); }

    /* ---- Settings: URL + slug for the customer [lumio_booking] shortcode ---- */
    add_action('admin_init', function () {
        register_setting('lumio_booking_settings', LUMIO_BOOKING_OPT_SITE_URL, array(
            'type' => 'string', 'sanitize_callback' => 'esc_url_raw', 'default' => '',
        ));
        register_setting('lumio_booking_settings', LUMIO_BOOKING_OPT_SLUG, array(
            'type' => 'string', 'sanitize_callback' => 'sanitize_title', 'default' => '',
        ));
    });

    function lumio_booking_render_settings_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $site_url = get_option(LUMIO_BOOKING_OPT_SITE_URL, '');
        $slug     = get_option(LUMIO_BOOKING_OPT_SLUG, '');
        $preview  = $slug ? lumio_booking_base() . '/book/' . $slug : '';
        $opt_url  = esc_attr(LUMIO_BOOKING_OPT_SITE_URL);
        $opt_slug = esc_attr(LUMIO_BOOKING_OPT_SLUG);

        echo '<div class="wrap">';
        echo '<h1>Lumio Booking — Settings</h1>';
        echo '<p>Connect this site to your salon, then add the shortcode <code>[lumio_booking]</code> to any page.</p>';
        echo '<form method="post" action="options.php">';
        settings_fields('lumio_booking_settings');
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th scope="row"><label for="lumio_site_url">Booking site URL</label></th><td>';
        echo '<input name="' . $opt_url . '" id="lumio_site_url" type="url" class="regular-text" value="' . esc_attr($site_url) . '" placeholder="https://lumiobooking.com" />';
        echo '<p class="description">Leave blank to use https://lumiobooking.com.</p></td></tr>';
        echo '<tr><th scope="row"><label for="lumio_slug">Salon slug</label></th><td>';
        echo '<input name="' . $opt_slug . '" id="lumio_slug" type="text" class="regular-text" value="' . esc_attr($slug) . '" placeholder="lux-nail-spa" />';
        echo '<p class="description">The part after <code>/book/</code> in your booking link.</p></td></tr>';
        if ($preview) {
            echo '<tr><th scope="row">Your booking link</th><td><a href="' . esc_url($preview) . '" target="_blank" rel="noopener">' . esc_html($preview) . '</a></td></tr>';
        }
        echo '</table>';
        submit_button('Save settings');
        echo '</form>';
        echo '<hr /><h2>Show the booking form to customers</h2>';
        echo '<p>Add this shortcode to any page: <code>[lumio_booking]</code></p>';
        echo '<p>To manage appointments use <strong>Lumio Booking → Dashboard / Calendar / Bookings</strong> on the left.</p>';
        echo '</div>';
    }

    /* ---- Customer shortcode: [lumio_booking] ---- */
    function lumio_booking_shortcode($atts)
    {
        // 'height' is only the INITIAL height; the iframe auto-resizes to the
        // form's real content height (via a postMessage the hosted form sends),
        // so there is never empty space below it.
        $atts = shortcode_atts(array('slug' => '', 'url' => '', 'height' => '560'), $atts, 'lumio_booking');
        $site = ($atts['url'] !== '') ? rtrim($atts['url'], '/') : lumio_booking_base();
        $slug = ($atts['slug'] !== '') ? $atts['slug'] : get_option(LUMIO_BOOKING_OPT_SLUG, '');
        $slug = trim((string) $slug);
        if (!$slug) {
            return current_user_can('manage_options') ? '<p><em>Lumio Booking: set your Salon slug under Lumio Booking &rarr; Settings.</em></p>' : '';
        }
        $src    = esc_url($site . '/book/' . rawurlencode($slug));
        $height = max(320, intval($atts['height']));

        // Origin of the booking site, for a safe postMessage check.
        $scheme = parse_url($site, PHP_URL_SCHEME);
        $host   = parse_url($site, PHP_URL_HOST);
        $origin = ($scheme && $host) ? $scheme . '://' . $host : '';
        $fid    = 'lumio-booking-' . wp_rand(1000, 99999);

        $html  = '<div class="lumio-booking-embed" style="width:100%;max-width:980px;margin:0 auto;">';
        $html .= '<iframe id="' . esc_attr($fid) . '" src="' . $src . '" loading="lazy" title="Book an appointment" allow="payment" ';
        $html .= 'style="width:100%;min-height:' . $height . 'px;border:0;border-radius:16px;overflow:hidden;background:transparent;display:block;"></iframe>';
        $html .= '</div>';
        // Auto-resize: match the iframe to the form's reported content height.
        $html .= '<script>(function(){var f=document.getElementById(' . wp_json_encode($fid) . ');if(!f){return;}var o=' . wp_json_encode($origin) . ';window.addEventListener("message",function(e){if(o&&e.origin!==o){return;}var d=e.data;if(!d||d.type!=="lumio-embed-height"){return;}var h=parseInt(d.height,10);if(h&&h>120){f.style.height=h+"px";f.style.minHeight="0px";}});})();</script>';
        return $html;
    }
    add_shortcode('lumio_booking', 'lumio_booking_shortcode');
}
