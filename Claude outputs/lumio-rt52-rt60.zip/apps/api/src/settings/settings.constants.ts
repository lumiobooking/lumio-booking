// Streamlined booking settings. All stored as JSON in the `settings` table
// (no schema migration needed). Times are minutes from midnight, salon-local.
export const BOOKING_RULES_KEY = 'booking_rules';
export const COMPANY_EXTRA_KEY = 'company_extra';
export const PAYMENT_GATEWAYS_KEY = 'payment_gateways';
export const NOTIFICATION_SETTINGS_KEY = 'notifications';
export const POS_SETTINGS_KEY = 'pos_settings';
export const RECEIPT_DESIGN_KEY = 'receipt_design';
export const LOYALTY_SETTINGS_KEY = 'loyalty_settings';

// Loyalty program: earn points per $ spent, redeem points for a discount.
export interface LoyaltySettings {
  enabled: boolean;
  earnPointsPerDollar: number; // points earned per $1 paid (e.g. 1)
  redeemCentsPerPoint: number; // value of 1 point when redeemed, in cents (e.g. 5 → 100 pts = $5)
  minRedeemPoints: number; // minimum points required to redeem (e.g. 100)
}

export const DEFAULT_LOYALTY_SETTINGS: LoyaltySettings = {
  enabled: false,
  earnPointsPerDollar: 1,
  redeemCentsPerPoint: 5,
  minRedeemPoints: 100,
};

// Weekday auto-discounts: encourage bookings on quieter days. Each rule applies
// a % off services in a category (or all categories) on a given weekday. Shown
// prominently on the booking page and applied to the price the customer pays.
export const WEEKDAY_DISCOUNTS_KEY = 'weekday_discounts';

/** Who a promotion is for: the whole salon, online bookings only, or walk-ins only (settings/promo-channel.ts). */
export type PromoAudience = 'all' | 'online' | 'walkin';

export interface WeekdayDiscountRule {
  day: number; // 0 = Sunday … 6 = Saturday (salon-local weekday)
  categoryId: string | null; // null = all categories
  percent: number; // 1–90
}

export interface WeekdayDiscounts {
  enabled: boolean;
  message: string; // optional headline shown on the booking page
  rules: WeekdayDiscountRule[];
  /** Optional run dates (salon-local YYYY-MM-DD, inclusive). Empty = open-ended. */
  startDate?: string | null;
  endDate?: string | null;
  /** Where it applies; missing = the whole salon. */
  appliesTo?: PromoAudience;
}

export const DEFAULT_WEEKDAY_DISCOUNTS: WeekdayDiscounts = {
  enabled: false,
  message: 'Book on a quieter day and save!',
  rules: [],
};

// First-visit discount: automatic % off for NEW customers (no prior visit).
// Verified server-side by phone/email at booking time — never stacks with other
// promos (the single best % wins).
export const FIRST_VISIT_DISCOUNT_KEY = 'first_visit_discount';

export interface VisitDiscountRule {
  visit: number; // exact visit number the discount applies to (1 = first visit)
  percent: number; // 1-90
}

export interface FirstVisitDiscount {
  enabled: boolean;
  percent: number; // legacy single % (kept in sync with the visit-1 rule)
  message: string; // headline shown on the booking page
  // Visit-based tiers: e.g. visit 1 → 10%, visit 5 → 15% (returning-customer
  // thank-you). Older saved settings without rules are normalized on read.
  rules?: VisitDiscountRule[];
  /** Optional run dates (salon-local YYYY-MM-DD, inclusive). Empty = open-ended. */
  startDate?: string | null;
  endDate?: string | null;
  /** Where it applies; missing = the whole salon. */
  appliesTo?: PromoAudience;
}

export const DEFAULT_FIRST_VISIT_DISCOUNT: FirstVisitDiscount = {
  enabled: false,
  percent: 10,
  message: '10% off your first visit!',
  rules: [{ visit: 1, percent: 10 }],
};

// Group ("bring your friends") discount: % off by party size, tiered
// (e.g. 2+ people 10%, 3+ people 15%). Applied automatically from the
// "People" field on the booking page; best tier wins, never stacks.
export const GROUP_DISCOUNT_KEY = 'group_discount';

export interface GroupDiscountTier {
  minSize: number; // party size at which the tier kicks in (2-20)
  percent: number; // 1-90
}

export interface GroupDiscount {
  enabled: boolean;
  message: string;
  tiers: GroupDiscountTier[];
  /** Optional run dates (salon-local YYYY-MM-DD, inclusive). Empty = open-ended. */
  startDate?: string | null;
  endDate?: string | null;
  /** Where it applies; missing = the whole salon. */
  appliesTo?: PromoAudience;
}

export const DEFAULT_GROUP_DISCOUNT: GroupDiscount = {
  enabled: false,
  message: 'Bring your friends and save!',
  tiers: [
    { minSize: 2, percent: 10 },
    { minSize: 3, percent: 15 },
  ],
};

// Special-date discounts: run a sale on specific calendar dates or date ranges
// (holidays, a grand-opening week) — NOT recurring by weekday. Each rule applies
// a % off in a category (or all) from startDate to endDate inclusive. Dates are
// salon-local YYYY-MM-DD strings; a blank endDate means a single day. When a date
// is covered by BOTH a weekday rule and a date rule, the higher % wins.
export const DATE_DISCOUNTS_KEY = 'date_discounts';

export interface DateDiscountRule {
  startDate: string; // YYYY-MM-DD (salon local)
  endDate: string | null; // YYYY-MM-DD inclusive; blank/null = one day (= startDate)
  categoryId: string | null; // null = all categories
  percent: number; // 1–90
  label?: string; // optional promo name, e.g. "Grand opening"
  /** Where this sale applies; missing = the whole salon. */
  appliesTo?: PromoAudience;
}

export interface DateDiscounts {
  enabled: boolean;
  rules: DateDiscountRule[];
}

export const DEFAULT_DATE_DISCOUNTS: DateDiscounts = {
  enabled: false,
  rules: [],
};

// Deposit-to-hold-the-slot (no-show deterrent). OFF by default. The deposit is
// taken as a partial online payment at booking time, kept on no-show, refunded
// on cancel, and credited toward the final bill at checkout. It runs on the
// PaymentProvider abstraction, so adding a real gateway later "just works".
export const DEPOSIT_SETTINGS_KEY = 'deposit_settings';

export interface DepositSettings {
  enabled: boolean;
  type: 'percent' | 'fixed';
  percent: number; // when type=percent (1–100)
  fixedCents: number; // when type=fixed
  // Who must pay a deposit:
  //  'all'           = every online booking
  //  'new'           = customers with no prior completed visit
  //  'repeat_noshow' = customers at/above the no-show threshold
  scope: 'all' | 'new' | 'repeat_noshow';
  noShowThreshold: number; // used when scope = repeat_noshow
  // Cancel at least this many hours before the appointment and the deposit is
  // refunded to the card (for real, by the provider that took it); later — or
  // not showing up — and the salon keeps it. bookings/deposit-policy.ts.
  refundHours: number;
  // Minutes the slot is held while the customer pays the deposit online; not
  // paid by then → the booking is cancelled and the time freed. 0 = never.
  // payments/deposit-hold.ts.
  holdMinutes?: number;
  // Which connected online provider takes deposits when the salon has several
  // (payment hub). null = the first one connected.
  provider: string | null;
}

export const DEFAULT_DEPOSIT_SETTINGS: DepositSettings = {
  enabled: false,
  type: 'percent',
  percent: 30,
  fixedCents: 1000,
  scope: 'all',
  noShowThreshold: 2,
  refundHours: 24,
  holdMinutes: 30,
  provider: null,
};

// Automated appointment reminders (no-show reduction). OFF by default so a salon
// must opt in before any message is sent.
export const REMINDER_SETTINGS_KEY = 'reminder_settings';

export interface ReminderSettings {
  enabled: boolean;
  hoursBefore1: number; // earlier reminder, in hours: 72 = 3 days, 24 (0 = off)
  hoursBefore2: number; // later reminder, in hours: 3, 0.5 = 30 minutes (0 = off)
  channelEmail: boolean;
  channelSms: boolean;
}

export const DEFAULT_REMINDER_SETTINGS: ReminderSettings = {
  enabled: false,
  hoursBefore1: 24,
  hoursBefore2: 3,
  channelEmail: true,
  channelSms: true,
};

export const REVIEW_SETTINGS_KEY = 'review_settings';
export const ANALYTICS_SETTINGS_KEY = 'analytics_settings';

/**
 * What the business is, written by the business.
 *
 * The content, ads and SEO engines used to reason from `businessType` — four
 * values for every company on the platform. A marketing agency serving
 * Vietnamese families is "SERVICE" under that scheme, which is true and tells
 * you nothing, so the advice came out plausible and wrong. These fields are
 * where a business says what a four-value enum cannot, and the engines read
 * them ahead of the enum.
 *
 * `whoWeServe` in particular is a fact only the business has. Nothing in this
 * codebase may infer it from a name, a postcode or the language of a chatbot.
 */
export interface BusinessProfileSettings {
  whatWeDo: string;
  whoWeServe: string;
  languages: string;
  serviceArea: string;
  edge: string;
  avoid: string;
  /**
   * The trade, one level finer than the businessType enum.
   *
   * NAIL | HAIR | LASH | BROW | SPA | MASSAGE | PMU, or '' for "whatever the
   * enum says". A lash studio and a nail bar are both SALON to the database
   * and want completely different feeds: asking a lash studio's trends board
   * about nail art fills it with work the shop does not sell.
   *
   * Declared, not inferred — the same rule as every other field here. Nothing
   * guesses a trade from a shop's name or its service list, because a shop
   * that does lashes AND nails is the one that most needs to say which it
   * wants the board pointed at. Empty is a valid, honest answer: the trends
   * engine falls back to the enum exactly as it did before this field existed.
   *
   * Stored as JSON, so adding a trade needs no migration and no enum change —
   * which is why this lives here and not on the tenants table.
   */
  trade: string;
  /**
   * Who set `trade`. 'manual' = a person chose it on the profile form and the
   * profile scan must never move it; 'auto' = the scan filled it from what the
   * business wrote about itself; '' = nobody yet. The scan only ever writes a
   * trade into an empty or auto slot — a pho restaurant that was left on the
   * salon default is corrected, a lash studio that chose NAIL on purpose is not.
   */
  tradeSource?: 'manual' | 'auto' | '';
}
/**
 * What this salon wants EVERY assistant to know — hotline, Messenger,
 * Instagram, web chat, Zalo — in the owner's own words: "ask gel or dip for
 * a full set", "we don't do kids under 8", "Kim only does pedicures". One
 * place, read by every channel, so a rule is not typed twice and forgotten
 * once.
 */
export const AI_NOTES_KEY = 'ai_notes';
export interface AiNotes { text: string }
export const DEFAULT_AI_NOTES: AiNotes = { text: '' };

export const BUSINESS_PROFILE_KEY = 'business_profile';
export const DEFAULT_BUSINESS_PROFILE: BusinessProfileSettings = {
  whatWeDo: '', whoWeServe: '', languages: '', serviceArea: '', edge: '', avoid: '', trade: '', tradeSource: '',
};
export const REBOOKING_SETTINGS_KEY = 'rebooking_settings';

/** Auto "time for a refill" reminder N days after a visit (retention). */
export interface RebookingSettings { enabled: boolean; daysAfter: number; email: boolean; sms: boolean }
export const DEFAULT_REBOOKING_SETTINGS: RebookingSettings = { enabled: false, daysAfter: 21, email: true, sms: true };

/** Per-tenant web analytics — a GA4 Measurement ID and/or a GTM container, injected
 *  ONLY on this salon's booking page so each shop measures in its own property. */
/** mode: which ONE tracking method runs on the booking page.
 *  '' (legacy/auto) = prefer GTM when set, else GA4 — never both, so a GTM
 *  container that already includes the Google Tag can never double-count. */
/** adsId + adsLabel: a Google Ads conversion (AW-… / label). Independent of mode —
 *  the booking page loads the Ads tag itself and sends ONE conversion per booking,
 *  so the salon needs no GTM or GA4 import to count bookings in Google Ads. */
export interface AnalyticsSettings { ga4Id: string; gtmId: string; mode: '' | 'none' | 'ga4' | 'gtm'; adsId: string; adsLabel: string }
export const DEFAULT_ANALYTICS_SETTINGS: AnalyticsSettings = { ga4Id: '', gtmId: '', mode: '', adsId: '', adsLabel: '' };

/** Google Ads conversion ID as shown in Google Ads ("AW-" + digits). */
export const ADS_ID_RE = /^AW-\d{6,15}$/;
/** Conversion label (letters, digits, - and _). */
export const ADS_LABEL_RE = /^[A-Za-z0-9_-]{4,64}$/;

// Review-reward program: customer rates on our page, then is invited to Google.
export interface ReviewSettings {
  enabled: boolean;
  // How the customer review page behaves:
  //  'direct'     = straight to Google (one tap), logs a "send" per staff (default)
  //  'rate_first' = rate in-house first, then invite happy customers to Google (filters bad reviews)
  reviewMode: 'direct' | 'rate_first';
  googlePlaceId: string; // the salon's Google Place ID — used to build a "write a review" link that opens the Google Maps app (where the customer is already signed in)
  googleReviewUrl: string; // optional fallback "write a review" URL (used only if no Place ID is set)
  staffPointsPerFeedback: number; // points the technician earns per feedback
  staffBonusFor5Star: number; // extra staff points when rating is 5
  customerPoints: number; // loyalty points the customer earns for giving feedback
  minRatingForGoogle: number; // show the Google button when rating >= this (1 = always)
  // Anti-abuse controls (rate-first mode).
  requireRealVisit: boolean; // only reward when feedback matches a real recent appointment
  visitWindowHours: number; // how recent the matching appointment must be
  dailyCapPerStaff: number; // max rewarded feedbacks per staff per day
  dedupDays: number; // same customer can reward the same staff once per N days
  // Direct mode — reward staff per "send to Google" (deduped per device + capped).
  staffPointsPerSend: number; // points the technician earns per counted send (0 = off)
  sendDailyCap: number; // hard cap: max counted (rewarded) sends per staff per day
  sendDedupHours: number; // same device counts at most once per staff per N hours
  // Direct-mode anti-fraud (anchor reward volume to real customers).
  anchorToVisits: boolean; // counted sends/day ≤ (completed appts + POS checkouts) + visitBuffer
  visitBuffer: number; // grace allowance over recorded visits for untracked walk-ins
  onlyBusinessHours: boolean; // only count sends during the salon's open hours
  // Post-visit AUTO review request — the shop no longer asks by hand. A thank-you
  // SMS + email with a one-tap Google review link is sent once, MID-service (while the
  // customer is still relaxing in the chair — the moment they're most willing).
  postVisitEnabled: boolean;
  postVisitDelayMinutes: number; // minutes after check-in to send (lands mid-service)
  postVisitEmail: boolean;
  postVisitSms: boolean;
  postVisitCooldownDays: number; // never re-ask the same customer within N days
}

export const DEFAULT_REVIEW_SETTINGS: ReviewSettings = {
  enabled: false,
  reviewMode: 'direct',
  googlePlaceId: '',
  googleReviewUrl: '',
  staffPointsPerFeedback: 10,
  staffBonusFor5Star: 5,
  customerPoints: 20,
  minRatingForGoogle: 4,
  requireRealVisit: true,
  visitWindowHours: 48,
  dailyCapPerStaff: 10,
  dedupDays: 7,
  staffPointsPerSend: 5,
  sendDailyCap: 20,
  sendDedupHours: 12,
  anchorToVisits: true,
  visitBuffer: 3,
  onlyBusinessHours: true,
  postVisitEnabled: false,
  postVisitDelayMinutes: 25,
  postVisitEmail: true,
  postVisitSms: true,
  postVisitCooldownDays: 45,
};

// POS (counter checkout) settings. Tax applies to retail products only
// (nail services are tax-exempt in many US states); receiptFooter prints at the
// bottom of every receipt.
export interface PosSettings {
  taxRatePercent: number; // e.g. 8.25 for 8.25% sales tax on retail
  receiptFooter: string;
  primaryCardGateway: string; // which enabled gateway the POS "Card" button uses ('' = none)
  // Dual pricing: menu prices are the CASH price; when the customer pays by
  // CARD the POS adds this surcharge % (US nail-salon "cash discount" model).
  // 0 = single price for both. Applies to services+tax, never to the tip.
  cardSurchargePercent: number;
  // Master switch — default OFF (not every salon passes card fees to customers).
  cardSurchargeEnabled: boolean;
  // Bank-transfer details shown to the customer when paying by Transfer
  // (cashier confirms receipt — no auto-confirmation).
  transferInstructions: string; // bank name / account / Zelle / Interac email, etc.
  transferQrUrl: string; // optional QR image URL the customer can scan
  /**
   * The same two things, PER PAYMENT METHOD.
   *
   * A Vietnamese till offers six buttons — cash, card, transfer, VietQR, MoMo,
   * ZaloPay — and the last three are different QR images from different apps.
   * One transferQrUrl cannot hold three of them, so a cashier who tapped MoMo
   * was shown the bank QR, or nothing.
   *
   * Keyed by PaymentMethod. Anything missing falls back to the single pair
   * above, which is what every US salon has been using for Zelle and must keep
   * working untouched.
   */
  paymentDetails?: Record<string, { instructions?: string; qrUrl?: string }>;
  /**
   * Whether a tip is asked for at all.
   *
   * Tipping a nail tech is normal in the United States and Canada and strange
   * almost everywhere else. In Vietnam the screen asking a customer to add 18%
   * does not read as generous, it reads as a foreign shop that does not know
   * the country — so a salon there needs to turn the whole thing off, not
   * set it to zero.
   *
   * Defaults to true, which is what every salon does today. Picking Vietnam in
   * Settings switches it off; the salon can switch it back on, because a shop
   * serving tourists may well want it.
   */
  tipsEnabled: boolean;
  /**
   * Cashier shifts: when true, a live sale cannot be rung up until someone
   * has opened the till ("vào ca") with a counted float. Off by default —
   * every salon keeps selling exactly as before until it turns this on.
   */
  requireShift?: boolean;
  /**
   * Which payment buttons this till shows, in order.
   *
   * Absent or empty means "use the market default" — which is what every salon
   * that has never opened this screen has, and why they are all unaffected. A
   * salon that does not take MoMo should not have a MoMo button to press by
   * mistake at the end of a long day.
   *
   * OPTIONAL on purpose. Settings rows written before this field existed do not
   * have it, and every place that rebuilds a whole PosSettings object would
   * otherwise have to remember to carry it — which is exactly what broke the
   * build: one such place did not, and the salon's choice would have been
   * silently wiped every time an unrelated POS setting was saved.
   */
  paymentMethods?: string[];
  /**
   * The one bank account money is transferred to (Vietnam: VietQR). The till,
   * the guest check and the receipt make a QR with the exact amount from it,
   * so the owner types three things once instead of pasting QR image links per
   * payment method. Absent = never set here (a restaurant may still have the
   * older till-settings account); null = removed on purpose.
   */
  bankAccount?: { bin: string; accountNo: string; accountName: string } | null;
  /** Print that QR on the guest check / bill. Default on. */
  printPayQr?: boolean;
}

export const DEFAULT_POS_SETTINGS: PosSettings = {
  taxRatePercent: 0,
  receiptFooter: '',
  primaryCardGateway: '',
  cardSurchargePercent: 0,
  cardSurchargeEnabled: false,
  transferInstructions: '',
  transferQrUrl: '',
  tipsEnabled: true,
  paymentMethods: [], // empty = follow the salon's market
  paymentDetails: {},
  requireShift: false,
};

/** When/where booking notifications go, plus the SMS (Twilio) connection. */
export interface NotificationSettings {
  // Which delivery method this salon uses for emails (Amelia-style explicit choice).
  //  'auto' = use the salon's own config if set, else the platform email (free) — default
  //  'off'  = don't send real emails (logged only)
  //  'smtp' = the salon's own SMTP server
  //  'brevo'= the salon's Brevo HTTPS API
  //  'gmail'= the salon's Gmail via Google OAuth2 (Gmail API over HTTPS)
  mailService: 'auto' | 'off' | 'smtp' | 'brevo' | 'gmail';
  senderName: string; // "From" name on emails
  senderEmail: string; // shared "From" address (used by every provider)
  replyTo: string; // optional Reply-To address
  adminEmail: string; // where the salon receives booking alerts
  adminPhone: string; // where the salon receives booking SMS
  emailCustomerOnBooking: boolean;
  emailAdminOnBooking: boolean;
  smsCustomerOnBooking: boolean;
  smsAdminOnBooking: boolean;
  // Message templates (support placeholders like {salon} {customer} {service}
  // {date} {time} {technician} {total} {duration} {addons}).
  emailSubjectCustomer: string;
  emailIntroCustomer: string;
  emailSubjectAdmin: string;
  emailIntroAdmin: string;
  emailFooter: string;
  smsCustomer: string;
  smsAdmin: string;
  // Email gateway (SMTP, e.g. Gmail). pass is private and never returned to UI.
  // `secure` mirrors Amelia: ssl (465), tls/STARTTLS (587), or none (25).
  smtp: { host: string; port: number; user: string; pass: string; fromEmail: string; secure: 'ssl' | 'tls' | 'none' };
  // Email via Brevo HTTPS API (recommended: reliable from the cloud, free tier).
  // apiKey is private and never returned to the UI.
  brevo: { apiKey: string; senderEmail: string; senderName: string };
  // Email via Gmail Google OAuth2 (Gmail API over HTTPS — free, no SMTP needed).
  // clientSecret + refreshToken are private and never returned to the UI.
  gmail: { clientId: string; clientSecret: string; refreshToken: string; senderEmail: string };
  // SMS gateway (Twilio). authToken is private and never returned to the UI.
  twilio: { accountSid: string; authToken: string; fromNumber: string };
  /**
   * SMS inside Vietnam, via eSMS.vn. secretKey is private and never returned.
   *
   * A separate provider rather than a second Twilio number, because Twilio to
   * Vietnam is a silent failure: Twilio accepts the message and returns an id,
   * and the carrier drops it. Their own docs say delivery over an unregistered
   * sender is "lower quality or disallowed", and carriers there allowlist
   * message templates AND urls — so a booking link that differs per salon is
   * exactly the shape that gets blocked, invisibly and permanently.
   *
   * brandname must be registered with the carriers before it will send;
   * an unregistered one is eSMS error 104 on every attempt.
   */
  esms: {
    apiKey: string; secretKey: string; brandname: string;
    /** Zalo Official Account id linked to eSMS. With a template id below, the
     *  matching notification goes out as Zalo ZNS first (cheaper, richer,
     *  lands in-app) and falls back to brandname SMS on any failure. */
    oaid: string;
    /** Zalo-approved ZNS template ids, registered through eSMS with Lumio's
     *  canonical params: customer_name, salon_name, service_name,
     *  appointment_date, appointment_time. Empty = that message stays SMS. */
    znsBookingTempId: string;
    znsReminderTempId: string;
  };
  /**
   * The tenant's market ('US' | 'CA' | 'VN'), attached AT READ TIME by
   * getNotificationSettings so every caller that already holds the settings
   * can branch per-market without a second tenant lookup. Runtime-only:
   * stripped before every save, never stored in the settings JSON.
   */
  market?: string;
}

export const DEFAULT_NOTIFICATION_SETTINGS: NotificationSettings = {
  mailService: 'auto',
  senderName: '',
  senderEmail: '',
  replyTo: '',
  adminEmail: '',
  adminPhone: '',
  emailCustomerOnBooking: true,
  emailAdminOnBooking: true,
  smsCustomerOnBooking: false,
  smsAdminOnBooking: false,
  emailSubjectCustomer: 'Your booking is confirmed — {salon}',
  emailIntroCustomer: 'Hi {customer}, thank you for booking with {salon}! Here are your appointment details:',
  emailSubjectAdmin: 'New booking — {service} for {customer}',
  emailIntroAdmin: 'A new booking has just come in. Details below:',
  emailFooter: 'We look forward to seeing you. If you need to make changes, just reply to this email.',
  smsCustomer: '{salon}: {service} on {date} at {time} with {technician}. Total {total}. See you soon! Reply STOP to opt out.',
  smsAdmin: 'New booking {reference}: {service} for {customer} {customerPhone} on {date} {time} — tech {technician}, {total}.',
  smtp: { host: 'smtp.gmail.com', port: 465, user: '', pass: '', fromEmail: '', secure: 'ssl' },
  brevo: { apiKey: '', senderEmail: '', senderName: '' },
  gmail: { clientId: '', clientSecret: '', refreshToken: '', senderEmail: '' },
  twilio: { accountSid: '', authToken: '', fromNumber: '' },
  // Empty = not configured. A VN salon with no eSMS keys falls back to the
  // existing path, which is what it does today — not to an error.
  esms: { apiKey: '', secretKey: '', brandname: '', oaid: '', znsBookingTempId: '', znsReminderTempId: '' },
};

/** Supported card/online gateways (most popular for US/Canada salons). */
export const GATEWAY_IDS = ['helcim', 'stripe', 'square', 'clover', 'authorizenet', 'paypal', 'sumup'] as const;
export type GatewayId = (typeof GATEWAY_IDS)[number];

/** Stored per gateway. apiKey is the public/identifier value; secret is private. */
export interface GatewayConfig {
  enabled: boolean;
  apiKey: string; // public/identifier value (publishable key / location id / client id…)
  secret: string; // private value (secret key / access token…)
}
export type PaymentGateways = Record<GatewayId, GatewayConfig>;

export const DEFAULT_GATEWAY: GatewayConfig = { enabled: false, apiKey: '', secret: '' };
export const DEFAULT_PAYMENT_GATEWAYS: PaymentGateways = {
  helcim: { ...DEFAULT_GATEWAY },
  stripe: { ...DEFAULT_GATEWAY },
  square: { ...DEFAULT_GATEWAY },
  clover: { ...DEFAULT_GATEWAY },
  authorizenet: { ...DEFAULT_GATEWAY },
  paypal: { ...DEFAULT_GATEWAY },
  sumup: { ...DEFAULT_GATEWAY },
};

/** Open/close for one weekday (index 0 = Sunday … 6 = Saturday). */
export interface DayHours {
  closed: boolean;
  // Overall span (min of opens .. max of closes) — kept for single-window
  // consumers and JSON-LD. When `intervals` is set it mirrors that span.
  openMinutes: number;
  closeMinutes: number;
  // Optional split shifts, e.g. a restaurant open 10:30-14:30 AND 16:30-20:30.
  // When present and non-empty it is the source of truth for open windows.
  intervals?: { open: number; close: number }[];
}

export interface BookingRules {
  slotStepMinutes: number; // gap between offered start times
  minLeadHours: number; // earliest a customer can book from now
  maxAdvanceDays: number; // how far ahead bookings are allowed
  allowCustomerChooseStaff: boolean; // customer may pick a preferred technician
  // What happens when a customer booking has no technician chosen:
  //  'none' = leave unassigned for the salon to handle manually
  //  'auto' = auto-assign via the engine (fair round-robin + history rules)
  assignmentMode: 'none' | 'auto';
  currency: string; // ISO 4217 code, e.g. USD / EUR / VND
  currencySymbol: string; // optional custom symbol; '' = derive from currency
  symbolPosition: 'before' | 'after'; // $10 vs 10$
  priceDecimals: number; // decimal places shown
  defaultPaymentMethod: 'online' | 'onsite'; // pre-selected at checkout
  onlinePaymentEnabled: boolean;
  payLaterEnabled: boolean;
  businessHours: DayHours[]; // length 7, indexed by JS getDay()
  daysOff: string[]; // ISO dates "YYYY-MM-DD" the salon is closed
  // Group bookings when the party is larger than the technicians who do the
  // chosen services: 'strict' = no time offered (Fresha-style), 'flexible' =
  // bookable as an arrival time, the salon serves the group in turns
  // (Vagaro-style). Strict by default — the salon opts INTO flexibility.
  groupPolicy: 'strict' | 'flexible';
  /**
   * Must a technician TAP "Accept" in the staff app to keep a booking?
   *
   * Off by default, and that is the trade's reality: technicians do not sit on
   * an app. With it on, a booking not accepted within 30 minutes is taken
   * from the technician and handed to the next free one (and back to the desk
   * when nobody is free). That ran for every salon from Oct 4 2026 and
   * stripped the engine's picks — and the desk's own picks — off the
   * calendar half an hour later, so every salon's book read "Chưa có thợ".
   * A salon whose team really does answer in the app turns it on.
   */
  staffMustAccept: boolean;
  /**
   * Bookings CUSTOMERS make — booking page, WordPress plugin, Messenger /
   * Instagram chat, AI hotline — are CONFIRMED the moment they are made.
   *
   * On for every salon by default (4 Nov 2026, the owner: "áp dụng tự động
   * confirm cho tất cả các tiệm"). Before, every one of them sat in the
   * header's "Cần xác nhận" until someone at the desk pressed Xác nhận — for
   * a booking the system had already checked against hours, technicians and
   * the calendar. It still shows under "Mới đặt", so the desk sees it.
   *
   * A salon that wants to look at each booking first turns it off; its
   * customer bookings then wait in "Cần xác nhận" as before. With
   * staffMustAccept on, a booking that has a technician still waits for that
   * technician's accept either way. Desk bookings are always confirmed
   * (deskConfirm) and a check-in always marks the visit Arrived — neither
   * depends on this switch.
   */
  autoConfirm: boolean;
  /**
   * The badge at the top of the booking page.
   *
   *  'hours'   — "Open today 9:00 AM – 5:00 PM". A fact the owner typed in, so
   *              it cannot be wrong, and it does not advertise a free slot.
   *  'soonest' — "Next opening today at 2:00 PM". Reads well for a walk-in
   *              trade, but see the warning below.
   *  'off'     — show nothing.
   *
   * WHY 'soonest' IS NOT THE DEFAULT ANY MORE
   *
   * That badge is computed from business hours ALONE. The component has no
   * appointments and no staff — it never did — so "next opening at 2:00 PM"
   * means only "the salon's hours say it is open at 2:00 and that is past the
   * lead time". A salon booked solid all day still advertises 2:00 PM, and the
   * customer discovers the lie one click later, on the first screen. It also
   * quotes the SHORTEST service on the menu, so the time can be unreachable for
   * anything longer.
   *
   * Owners also object to it on its own terms: announcing a free slot in ninety
   * minutes tells every visitor the shop is quiet.
   */
  soonestBar: 'hours' | 'soonest' | 'off';

  /**
   * Customer self-service rescheduling, from Messenger and the AI hotline.
   *
   * `selfRescheduleNoticeHours` is a POLICY, not a measurement, and it is
   * deliberately NOT the same number as minLeadHours. Booking into an empty
   * slot an hour from now costs the salon nothing; vacating a committed slot
   * an hour from now leaves a hole they cannot fill. 24 is the common
   * convention in the trade — stated as a convention, and one field to change.
   */
  selfRescheduleEnabled: boolean;
  selfRescheduleNoticeHours: number;
  /** One appointment moved five times is a no-show arriving slowly. */
  selfRescheduleMaxMoves: number;

  /**
   * Customer self-service CANCELLING, from the same two front doors.
   *
   * Kept apart from the reschedule numbers because the two are not the same
   * favour: a move hands the slot back and takes another, a cancellation hands
   * it back and keeps nothing. A salon may reasonably let the bot move an
   * appointment and insist a person handles every cancellation — that is what
   * turning this off means. An appointment with money already paid on it never
   * takes this path whatever these say; the refund is a human decision.
   */
  selfCancelEnabled: boolean;
  selfCancelNoticeHours: number;
  /**
   * Rest / clean-up time between a technician's appointments, in minutes
   * (0–60). What customers and bots are offered keeps this gap; the desk can
   * still book by hand. bookings/buffer.ts.
   */
  bufferMinutes: number;
}

const open9to6: DayHours = { closed: false, openMinutes: 9 * 60, closeMinutes: 18 * 60 };

export const DEFAULT_BOOKING_RULES: BookingRules = {
  slotStepMinutes: 30,
  minLeadHours: 1,
  maxAdvanceDays: 60,
  selfRescheduleEnabled: true,
  selfRescheduleNoticeHours: 24,
  selfRescheduleMaxMoves: 2,
  selfCancelEnabled: true,
  selfCancelNoticeHours: 24,
  bufferMinutes: 0,
  allowCustomerChooseStaff: true,
  assignmentMode: 'auto',
  currency: 'USD',
  currencySymbol: '',
  symbolPosition: 'before',
  priceDecimals: 2,
  defaultPaymentMethod: 'onsite',
  onlinePaymentEnabled: true,
  payLaterEnabled: true,
  groupPolicy: 'strict',
  staffMustAccept: false,
  autoConfirm: true,
  // Stating the opening hours rather than promising a slot the page cannot
  // verify. A salon that wants the old badge back can pick 'soonest'.
  soonestBar: 'hours',
  // Sun closed by default, Mon–Sat open 09:00–18:00.
  businessHours: [
    { closed: true, openMinutes: 9 * 60, closeMinutes: 18 * 60 },
    open9to6, open9to6, open9to6, open9to6, open9to6, open9to6,
  ],
  daysOff: [],
};

export interface CompanyExtra {
  address: string;
  website: string;
  /**
   * ISO 3166-1 alpha-2, e.g. 'US', 'CA', 'VN'. Decides how a local phone number
   * is read, which currency and date order a salon starts from, and whether
   * tipping is shown at the till.
   *
   * Empty means "not stated", and everything then falls back to the timezone —
   * which is how every salon behaved before this field existed, so nobody has
   * to go and fill it in.
   */
  country: string;
}

export const DEFAULT_COMPANY_EXTRA: CompanyExtra = { address: '', website: '', country: '' };

export interface Branding {
  accentColor: string;
  logoUrl: string;
  /** Optional seasonal accent overlay for the public booking page. 'off' keeps the
   *  salon's own accent (the default — white-label first). 'auto' picks a festive
   *  hue by the calendar date; a fixed value (holiday/valentine/fall/spring/winter)
   *  pins one. It never touches the admin UI, only the customer-facing page. */
  seasonalTheme: string;
  /** Rating badge source. 'auto' = aggregate of in-app reviews, 'manual' = the values
   *  below (a salon showing its own Google rating), 'off' = no badge. */
  ratingMode: string;
  ratingValue: number;
  ratingCount: number;
  /** Logo zoom inside its display frame, percent (100 = fit). Lets a logo with
   *  its own background bleed to the frame edges instead of showing a border. */
  logoScale: number;
  /** Custom hero image for the customer-facing display's Welcome screen. */
  welcomeImageUrl: string;
  /**
   * Two pictures the CHATBOT may send a customer: the price list as an image
   * ("có bảng giá không?") and the storefront ("tiệm ở đâu?"). Public https
   * URLs only — Messenger, Instagram and Zalo fetch them from their side —
   * so they come from the platform's file storage, never inline base64.
   */
  priceListImageUrl: string;
  storefrontImageUrl: string;
  /** Empty cart on the booking page (web lib/cart-art.ts): a template key, 'auto' = the first of the salon's trade. */
  cartArt: string;
  /** The salon's own headline / line for it; blank = the template's. */
  cartTitle: string;
  cartHint: string;
  /** Check-in kiosk side panel QR: 'checkin' (scan to check in on your phone),
   *  'review' (Google review) or 'both' (alternating). */
  checkinQr: string;
}

export const DEFAULT_BRANDING: Branding = {
  accentColor: '#6366f1',
  logoUrl: '',
  seasonalTheme: 'off',
  ratingMode: 'auto',
  ratingValue: 0,
  ratingCount: 0,
  logoScale: 100,
  welcomeImageUrl: '',
  priceListImageUrl: '',
  storefrontImageUrl: '',
  cartArt: 'auto',
  cartTitle: '',
  cartHint: '',
  checkinQr: 'checkin',
};

// ===========================================================================
// Notification template catalog (Amelia-style). Each tenant gets a map of
// per-event templates they can edit. Stored as JSON under
// NOTIFICATION_TEMPLATES_KEY — no schema migration. Placeholders use the
// %name% syntax and are filled at send time. The *delivery connection*
// (sender, admin contacts, SMTP, Twilio) stays in NotificationSettings.
// ===========================================================================
export const NOTIFICATION_TEMPLATES_KEY = 'notification_templates';

/** One editable message (one event). `offsetHours` only matters for scheduled events. */
export interface NotifTemplate {
  enabled: boolean; // master on/off for this event
  email: boolean; // send via email
  sms: boolean; // send via SMS
  subject: string; // email subject
  body: string; // email body (plain text, \n line breaks, %placeholders%)
  smsBody: string; // SMS text
  offsetHours: number; // scheduled events: how many hours before/after (0 = immediate)
}

export type NotificationTemplates = Record<string, NotifTemplate>;

// Email bodies are stored as lightweight HTML (the editor is now WYSIWYG). The
// readable plain-text defaults are converted to <p>/<br> markup at module load.
function toHtmlBody(text: string): string {
  return text
    .split(/\n{2,}/)
    .map((par) => `<p>${par.replace(/\n/g, '<br>')}</p>`)
    .join('');
}

const t = (p: Partial<NotifTemplate> & Pick<NotifTemplate, 'subject' | 'body' | 'smsBody'>): NotifTemplate => ({
  enabled: true,
  email: true,
  sms: false,
  offsetHours: 0,
  ...p,
  body: toHtmlBody(p.body),
});

/**
 * Default, salon-appropriate content for every supported event. Ids are the
 * stable contract shared with the frontend catalog.
 */
export const DEFAULT_NOTIFICATION_TEMPLATES: NotificationTemplates = {
  // --- Customer · booking lifecycle ---
  customer_booking_confirmed: t({
    subject: 'Your %service_name% booking is confirmed — %salon_name%',
    body:
      'Hi %customer_name%,\n\n' +
      'Thank you for booking with %salon_name%! Your appointment is confirmed.\n\n' +
      'Booking reference: %booking_ref%\n' +
      'Service: %service_name%\n' +
      'Services & technicians: %service_lineup%\n' +
      'Add-ons: %add_ons_only%\n' +
      'Technician: %staff_name%\n' +
      'Date: %appointment_date%\n' +
      'Time: %appointment_time%\n' +
      'Duration: %duration%\n' +
      'Total: %total_price%\n' +
      'Your note: %booking_notes%\n' +
      'Address: %salon_address%\n\n' +
      'We look forward to seeing you. Need to make a change? Just reply to this message.\n' +
      '%salon_name% — %salon_contact%',
    smsBody: '%salon_name%: %service_name% on %appointment_date% at %appointment_time%. Tech: %staff_name%. Total: %total_price%. Reply STOP to opt out.',
  }),
  // A booking confirmed with "to be assigned", and given a technician later
  // (by the desk, or by the "auto-assign" button): tell the customer who it is.
  // Goes out on the channels the confirmation itself uses.
  customer_staff_assigned: t({
    sms: true,
    subject: 'Your technician for %appointment_date% — %salon_name%',
    body:
      'Hi %customer_name%,\n\n' +
      'Good news — %staff_name% will take care of your %service_name% on %appointment_date% at %appointment_time%.\n\n' +
      'Booking reference: %booking_ref%\n' +
      'Services & technicians: %service_lineup%\n\n' +
      'See you soon!\n%salon_name% — %salon_contact%',
    smsBody: '%salon_name%: your technician for %service_name% on %appointment_date% at %appointment_time% is %staff_name%. Reply STOP to opt out.',
  }),
  customer_booking_pending: t({
    enabled: false,
    subject: 'We received your booking — %salon_name%',
    body:
      'Hi %customer_name%,\n\n' +
      "We've received your request for %service_name% on %appointment_date% at %appointment_time%. " +
      "We'll confirm it shortly.\n\n%salon_name%",
    smsBody: "%salon_name%: we received your booking for %appointment_date% %appointment_time%. We'll confirm soon. Reply STOP to opt out.",
  }),
  customer_booking_cancelled: t({
    subject: 'Your booking has been cancelled — %salon_name%',
    body:
      'Hi %customer_name%,\n\n' +
      'Your appointment for %service_name% on %appointment_date% at %appointment_time% has been cancelled. ' +
      'We hope to see you again soon — book anytime.\n\n%salon_name%',
    smsBody: '%salon_name%: your booking on %appointment_date% %appointment_time% has been cancelled. Reply STOP to opt out.',
  }),
  customer_booking_rescheduled: t({
    subject: 'Your appointment has been rescheduled — %salon_name%',
    body:
      'Hi %customer_name%,\n\n' +
      'Your appointment for %service_name% has been moved to %appointment_date% at %appointment_time% ' +
      'with %staff_name%. See you then!\n\n%salon_name%',
    smsBody: '%salon_name%: your appointment is now %appointment_date% at %appointment_time%. Reply STOP to opt out.',
  }),

  // --- Customer · reminders & care (scheduled) ---
  customer_reminder: t({
    offsetHours: 24,
    subject: 'Reminder: your appointment at %salon_name% is coming up',
    body:
      'Hi %customer_name%,\n\n' +
      'This is a friendly reminder of your %service_name% appointment on %appointment_date% ' +
      'at %appointment_time% with %staff_name%.\n\nSee you soon!\n%salon_name% — %salon_contact%',
    smsBody: 'Reminder: %service_name% at %salon_name% on %appointment_date% %appointment_time%. See you soon! Reply STOP to opt out.',
  }),
  customer_followup: t({
    enabled: false,
    offsetHours: 24,
    subject: 'Thank you for visiting %salon_name%!',
    body:
      'Hi %customer_name%,\n\n' +
      'Thank you for visiting %salon_name%! We hope you enjoyed your visit. ' +
      "We'd love your feedback, and we can't wait to see you again.\n\n%salon_name%",
    smsBody: 'Thanks for visiting %salon_name%! We hope you enjoyed your visit. Come back soon! Reply STOP to unsubscribe.',
  }),
  customer_birthday: t({
    enabled: false,
    subject: 'Happy birthday from %salon_name%!',
    body:
      'Hi %customer_name%,\n\n' +
      'Happy birthday from all of us at %salon_name%! Treat yourself — book your next ' +
      'appointment and enjoy a special birthday touch on us.\n\n%salon_name%',
    smsBody: 'Happy birthday from %salon_name%! Treat yourself to a visit on us. Reply STOP to unsubscribe.',
  }),

  // --- Customer · payment ---
  customer_payment_receipt: t({
    enabled: false,
    subject: 'Your receipt from %salon_name%',
    body:
      'Hi %customer_name%,\n\n' +
      'Thank you for your payment of %total_price% for %service_name% on %appointment_date%.\n\n' +
      'Booking reference: %booking_id%\n%salon_name%',
    smsBody: '%salon_name%: payment of %total_price% received. Thank you! Reply STOP to opt out.',
  }),

  // --- Staff alerts ---
  staff_new_booking: t({
    subject: 'New booking assigned: %service_name% on %appointment_date%',
    body:
      'Hi %staff_name%,\n\n' +
      'You have a new appointment:\n\n' +
      'Booking reference: %booking_ref%\n' +
      'Client: %customer_full_name%\n' +
      'Phone: %customer_phone%\n' +
      'Service: %service_name%\n' +
      'Services & technicians: %service_lineup%\n' +
      'Add-ons: %add_ons_only%\n' +
      'Date: %appointment_date%\n' +
      'Time: %appointment_time%\n' +
      'Duration: %duration%\n' +
      'Total: %total_price%\n' +
      'Client note: %booking_notes%\n\n%salon_name%',
    smsBody: 'New booking %booking_ref%: %service_name% for %customer_full_name% %customer_phone% on %appointment_date% %appointment_time%.',
  }),
  staff_booking_cancelled: t({
    subject: 'Booking cancelled: %appointment_date% %appointment_time%',
    body:
      'Hi %staff_name%,\n\n' +
      'The following appointment was cancelled:\n\n' +
      'Client: %customer_name%\n' +
      'Service: %service_name%\n' +
      'Date: %appointment_date%\n' +
      'Time: %appointment_time%\n\n%salon_name%',
    smsBody: 'Cancelled: %service_name% for %customer_name% on %appointment_date% %appointment_time%.',
  }),
  staff_daily_agenda: t({
    enabled: false,
    offsetHours: 24,
    subject: 'Your schedule for tomorrow — %salon_name%',
    body:
      'Hi %staff_name%,\n\n' +
      "Here's your schedule summary for %appointment_date%. Log in to your staff portal " +
      'for full details.\n\n%salon_name%',
    smsBody: '%salon_name%: your schedule for tomorrow is ready. Check your staff portal.',
  }),
};

// ===========================================================================
// Vietnamese default copy.
//
// Applied as an OVERLAY at read time, and only onto fields the salon has not
// customised (i.e. fields still equal to the English default): a VN salon gets
// Vietnamese out of the box, a US salon is untouched, and nobody's edits are
// ever overwritten. SMS bodies are deliberately khong dau (unaccented):
// accented Vietnamese forces unicode SMS (70 chars/segment instead of 160),
// and the CSKH template the salon registers with eSMS/carriers is usually
// registered unaccented too — the sent text must match the registered mau tin.
// No "Reply STOP" tail: opt-out language is appended per-market by sms-policy
// (NĐ91 requires it on ADVERTISING only; these are transactional).
// ===========================================================================

/**
 * Copy that USED to be the English default.
 *
 * A salon that pressed Save on its notification settings before the wording
 * changed has the old default stored verbatim. That is still an untouched
 * default — the salon never wrote it — so the Vietnamese overlay below has to
 * keep recognising it. Without this table, editing an English default silently
 * un-translates every VN salon that had ever saved its settings, which is a
 * regression caused by improving the English copy.
 *
 * Append here whenever a default string below is changed. Never remove a line.
 */
export const LEGACY_NOTIFICATION_DEFAULTS: Partial<Record<keyof NotificationSettings, string[]>> = {
  smsCustomer: ['{salon}: your {service} on {date} at {time} is booked. See you soon! Reply STOP to opt out.'],
  smsAdmin: ['New booking: {service} for {customer} on {date} at {time}.'],
};

/** Same idea for the per-event catalog. Bodies are stored as HTML, so the old
 *  text goes through the same converter the defaults do. */
export const LEGACY_TEMPLATE_DEFAULTS: Record<string, Partial<Record<'subject' | 'body' | 'smsBody', string[]>>> = {
  customer_booking_confirmed: {
    body: [
      toHtmlBody(
        'Hi %customer_name%,\n\n' +
        'Thank you for booking with %salon_name%! Your appointment is confirmed.\n\n' +
        'Service: %service_name%\n' +
        'Add-ons: %add_ons%\n' +
        'Technician: %staff_name%\n' +
        'Date: %appointment_date%\n' +
        'Time: %appointment_time%\n' +
        'Duration: %duration%\n' +
        'Total: %total_price%\n\n' +
        'We look forward to seeing you. Need to make a change? Just reply to this message.\n' +
        '%salon_name% — %salon_contact%',
      ),
    ],
    smsBody: ['%salon_name%: your %service_name% on %appointment_date% at %appointment_time% is confirmed. See you soon! Reply STOP to opt out.'],
  },
  staff_new_booking: {
    body: [
      toHtmlBody(
        'Hi %staff_name%,\n\n' +
        'You have a new appointment:\n\n' +
        'Client: %customer_name%\n' +
        'Service: %service_name%\n' +
        'Date: %appointment_date%\n' +
        'Time: %appointment_time%\n' +
        'Duration: %duration%\n\n%salon_name%',
      ),
    ],
    smsBody: ['New booking: %service_name% for %customer_name% on %appointment_date% %appointment_time%.'],
  },
  // Until 29/10/2026 the thank-you assumed a nail salon ("We hope you love your nails").
  // Lash studios, spas and restaurants send it too, so it now speaks of the visit.
  customer_followup: {
    body: [
      toHtmlBody(
        'Hi %customer_name%,\n\n' +
        'Thank you for visiting %salon_name%! We hope you love your nails. ' +
        "We'd love your feedback, and we can't wait to see you again.\n\n%salon_name%",
      ),
      toHtmlBody(
        'Chào %customer_name%,\n\n' +
        'Cảm ơn bạn đã ghé %salon_name%! Mong bạn hài lòng với bộ nail của mình. ' +
        'Tiệm rất mong nhận được góp ý của bạn, và sớm được gặp lại bạn.\n\n%salon_name%',
      ),
    ],
    smsBody: ['Thanks for visiting %salon_name%! We hope you love your nails. Come back soon! Reply STOP to unsubscribe.'],
  },
};

export const VN_NOTIFICATION_TEXTS: Partial<NotificationSettings> = {
  emailSubjectCustomer: 'Lịch hẹn của bạn đã được xác nhận — {salon}',
  emailIntroCustomer: 'Chào {customer}, cảm ơn bạn đã đặt lịch tại {salon}! Chi tiết lịch hẹn của bạn:',
  emailSubjectAdmin: 'Lịch đặt mới — {service} cho {customer}',
  emailIntroAdmin: 'Vừa có lịch đặt mới. Chi tiết bên dưới:',
  emailFooter: 'Hẹn gặp bạn tại tiệm! Cần thay đổi lịch, bạn chỉ cần trả lời email này.',
  smsCustomer: '{salon}: Lich hen {service} ngay {date} luc {time} da duoc xac nhan. Hen gap ban!',
  smsAdmin: 'Lich moi: {service} cho {customer} ngay {date} luc {time}.',
};

/** Same overlay for the per-event template catalog (customer-facing events;
 *  staff alerts stay English — the target reader is the salon's own team). */
export const VN_TEMPLATE_TEXTS: Record<string, Partial<Pick<NotifTemplate, 'subject' | 'body' | 'smsBody'>>> = {
  customer_staff_assigned: {
    subject: 'Thợ phụ trách lịch hẹn ngày %appointment_date% — %salon_name%',
    body: toHtmlBody(
      'Chào %customer_name%,\n\n' +
      '%staff_name% sẽ phục vụ bạn dịch vụ %service_name% ngày %appointment_date% lúc %appointment_time%.\n\n' +
      'Mã lịch: %booking_ref%\n' +
      'Dịch vụ & thợ: %service_lineup%\n\n' +
      'Hẹn gặp bạn!\n%salon_name% — %salon_contact%',
    ),
  },
  customer_booking_confirmed: {
    subject: 'Lịch hẹn %service_name% đã được xác nhận — %salon_name%',
    body: toHtmlBody(
      'Chào %customer_name%,\n\n' +
      'Cảm ơn bạn đã đặt lịch tại %salon_name%! Lịch hẹn của bạn đã được xác nhận.\n\n' +
      'Dịch vụ: %service_name%\n' +
      'Dịch vụ thêm: %add_ons%\n' +
      'Kỹ thuật viên: %staff_name%\n' +
      'Ngày: %appointment_date%\n' +
      'Giờ: %appointment_time%\n' +
      'Thời lượng: %duration%\n' +
      'Tổng tiền: %total_price%\n\n' +
      'Hẹn gặp bạn tại tiệm. Cần thay đổi? Bạn chỉ cần trả lời tin này.\n' +
      '%salon_name% — %salon_contact%',
    ),
    smsBody: '%salon_name%: Lich hen %service_name% ngay %appointment_date% luc %appointment_time% da duoc xac nhan. Hen gap ban!',
  },
  customer_booking_pending: {
    subject: 'Đã nhận yêu cầu đặt lịch — %salon_name%',
    body: toHtmlBody(
      'Chào %customer_name%,\n\n' +
      'Chúng tôi đã nhận yêu cầu đặt %service_name% ngày %appointment_date% lúc %appointment_time%. ' +
      'Tiệm sẽ xác nhận với bạn sớm.\n\n%salon_name%',
    ),
    smsBody: '%salon_name%: Da nhan yeu cau dat lich ngay %appointment_date% %appointment_time%. Tiem se xac nhan som.',
  },
  customer_booking_cancelled: {
    subject: 'Lịch hẹn của bạn đã được hủy — %salon_name%',
    body: toHtmlBody(
      'Chào %customer_name%,\n\n' +
      'Lịch hẹn %service_name% ngày %appointment_date% lúc %appointment_time% đã được hủy. ' +
      'Hẹn gặp lại bạn — đặt lịch lại bất cứ lúc nào nhé.\n\n%salon_name%',
    ),
    smsBody: '%salon_name%: Lich hen ngay %appointment_date% %appointment_time% da duoc huy.',
  },
  customer_booking_rescheduled: {
    subject: 'Lịch hẹn của bạn đã được dời — %salon_name%',
    body: toHtmlBody(
      'Chào %customer_name%,\n\n' +
      'Lịch hẹn %service_name% của bạn được dời sang ngày %appointment_date% lúc %appointment_time% ' +
      'với %staff_name%. Hẹn gặp bạn!\n\n%salon_name%',
    ),
    smsBody: '%salon_name%: Lich hen doi sang ngay %appointment_date% luc %appointment_time%.',
  },
  customer_reminder: {
    subject: 'Nhắc lịch: hẹn của bạn tại %salon_name% sắp đến',
    body: toHtmlBody(
      'Chào %customer_name%,\n\n' +
      'Nhắc bạn lịch hẹn %service_name% ngày %appointment_date% ' +
      'lúc %appointment_time% với %staff_name%.\n\nHẹn gặp bạn!\n%salon_name% — %salon_contact%',
    ),
    smsBody: '%salon_name%: Nhac ban lich hen %service_name% ngay %appointment_date% luc %appointment_time%. Hen gap ban!',
  },
  customer_followup: {
    subject: 'Cảm ơn bạn đã ghé %salon_name%!',
    body: toHtmlBody(
      'Chào %customer_name%,\n\n' +
      'Cảm ơn bạn đã ghé %salon_name%! Mong bạn hài lòng với dịch vụ hôm nay. ' +
      'Chúng tôi rất mong nhận được góp ý của bạn, và sớm được gặp lại bạn.\n\n%salon_name%',
    ),
    smsBody: '%salon_name%: Cam on ban da ghe tiem! Mong ban hai long va som gap lai ban.',
  },
  customer_birthday: {
    subject: 'Chúc mừng sinh nhật từ %salon_name%!',
    body: toHtmlBody(
      'Chào %customer_name%,\n\n' +
      'Cả nhà %salon_name% chúc bạn sinh nhật thật vui! Tự thưởng cho mình nhé — ' +
      'đặt lịch hẹn tiếp theo để nhận một món quà sinh nhật nhỏ từ tiệm.\n\n%salon_name%',
    ),
    smsBody: '%salon_name%: Chuc mung sinh nhat! Ghe tiem trong thang nay de nhan uu dai sinh nhat nhe.',
  },
  customer_payment_receipt: {
    subject: 'Biên nhận thanh toán từ %salon_name%',
    body: toHtmlBody(
      'Chào %customer_name%,\n\n' +
      'Cảm ơn bạn đã thanh toán %total_price% cho %service_name% ngày %appointment_date%.\n\n' +
      'Mã đặt lịch: %booking_id%\n%salon_name%',
    ),
    smsBody: '%salon_name%: Da nhan thanh toan %total_price%. Cam on ban!',
  },
};



/**
 * How the salon's printed bill looks — the owner's own choices.
 *
 * What it can NOT switch off: the salon's name, address and phone number at
 * the top. A receipt without them is not a receipt (a customer disputing a
 * charge, a card company, an accountant all need to know who issued it), so
 * those three are always printed. The owner may write them differently for
 * the paper (a shorter name, the address on two lines) — empty means "take it
 * from the salon profile".
 *
 * The footer text is NOT stored here: it is `PosSettings.receiptFooter`, which
 * the products screen already edits, so there is one footer, not two.
 */
export interface ReceiptDesign {
  /** '' = "RECEIPT" / "HOÁ ĐƠN" in the receipt's language. */
  title: string;
  /** Language of the printed labels (Subtotal / Tạm tính …). */
  language: 'en' | 'vi';
  /** Thermal paper width: 58mm (32 characters) or 80mm (48 characters). */
  paper: '58' | '80';
  fontSize: 'normal' | 'large';
  showLogo: boolean;
  // Mandatory header, optionally rewritten for paper ('' = salon profile).
  nameOverride: string;
  addressOverride: string;
  phoneOverride: string;
  /** Extra lines under the header: website, Instagram, tax ID, Wi-Fi… */
  headerNote: string;
  showWebsite: boolean;
  showOrderNumber: boolean;
  showDateTime: boolean;
  showCustomer: boolean;
  showTechnician: boolean;
  showLineTips: boolean;
  showSavings: boolean;
  showPayments: boolean;
  /** QR to the salon's booking page — "book your next visit". */
  showBookingQr: boolean;
  /** Copies printed at the counter: '2' = liên 1 for the customer, liên 2 kept by the shop. */
  copies: '1' | '2';
}

export const DEFAULT_RECEIPT_DESIGN: ReceiptDesign = {
  title: '',
  language: 'en',
  paper: '80',
  fontSize: 'normal',
  showLogo: true,
  nameOverride: '',
  addressOverride: '',
  phoneOverride: '',
  headerNote: '',
  showWebsite: true,
  showOrderNumber: true,
  showDateTime: true,
  showCustomer: true,
  showTechnician: true,
  showLineTips: true,
  showSavings: true,
  showPayments: true,
  showBookingQr: false,
  copies: '1',
};

const RD_BOOL_KEYS = ['showLogo', 'showWebsite', 'showOrderNumber', 'showDateTime', 'showCustomer', 'showTechnician', 'showLineTips', 'showSavings', 'showPayments', 'showBookingQr'] as const;

/** Keep only what a receipt design may hold, trimmed to sane sizes. */
export function cleanReceiptDesign(input: unknown, base: ReceiptDesign = DEFAULT_RECEIPT_DESIGN): ReceiptDesign {
  const v = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  const str = (k: keyof ReceiptDesign, max: number) =>
    typeof v[k] === 'string' ? String(v[k]).replace(/\r/g, '').trim().slice(0, max) : (base[k] as string);
  const out: ReceiptDesign = {
    ...base,
    title: str('title', 40),
    language: v.language === 'vi' || v.language === 'en' ? v.language : base.language,
    paper: v.paper === '58' || v.paper === '80' ? v.paper : base.paper,
    fontSize: v.fontSize === 'large' || v.fontSize === 'normal' ? v.fontSize : base.fontSize,
    copies: v.copies === '1' || v.copies === '2' ? v.copies : base.copies,
    nameOverride: str('nameOverride', 80),
    addressOverride: str('addressOverride', 200),
    phoneOverride: str('phoneOverride', 40),
    headerNote: str('headerNote', 300),
  };
  for (const k of RD_BOOL_KEYS) if (typeof v[k] === 'boolean') (out as unknown as Record<string, unknown>)[k] = v[k];
  return out;
}

/** Everything a till needs to print the salon's bill. */
export interface ReceiptProfile {
  shop: { name: string; address: string; phone: string; website: string; logoUrl: string; bookingSlug: string };
  design: ReceiptDesign & { footer: string };
}
