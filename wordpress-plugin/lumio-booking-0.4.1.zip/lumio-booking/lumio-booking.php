<?php
/**
 * Plugin Name:       Lumio Booking
 * Plugin URI:        https://lumiobooking.com
 * Description:        Embed your salon's Lumio booking form on WordPress AND manage everything (dashboard, calendar, bookings) right inside wp-admin. Configure the booking URL + salon slug under Lumio Booking → Settings, then add the [lumio_booking] shortcode to any page.
 * Version:           0.4.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Lumio
 * License:           GPL-2.0-or-later
 * Text Domain:       lumio-booking
 */

if (!defined('ABSPATH')) {
    exit; // No direct access.
}

define('LUMIO_BOOKING_OPT_SITE_URL', 'lumio_booking_site_url'); // hosted web base, e.g. https://lumiobooking.com
define('LUMIO_BOOKING_OPT_SLUG', 'lumio_booking_slug');         // salon slug, e.g. lux-nail-spa

/** Base URL of the hosted Lumio app (defaults to the public domain). */
function lumio_booking_base()
{
    $u = get_option(LUMIO_BOOKING_OPT_SITE_URL, '');
    return $u ? rtrim($u, '/') : 'https://lumiobooking.com';
}

/* ===========================================================================
 * Admin menu — the salon-admin dashboard embedded INSIDE wp-admin so the owner
 * manages bookings without leaving WordPress.
 * ======================================================================== */

add_action('admin_menu', function () {
    add_menu_page('Lumio Booking', 'Lumio Booking', 'manage_options', 'lumio-booking', 'lumio_booking_page_dashboard', 'dashicons-calendar-alt', 26);
    add_submenu_page('lumio-booking', 'Dashboard', 'Dashboard', 'manage_options', 'lumio-booking', 'lumio_booking_page_dashboard');
    add_submenu_page('lumio-booking', 'Calendar', 'Calendar', 'manage_options', 'lumio-booking-calendar', 'lumio_booking_page_calendar');
    add_submenu_page('lumio-booking', 'Bookings', 'Bookings', 'manage_options', 'lumio-booking-bookings', 'lumio_booking_page_bookings');
    add_submenu_page('lumio-booking', 'Settings', 'Settings', 'manage_options', 'lumio-booking-settings', 'lumio_booking_render_settings_page');
});

/** Render one embedded salon-admin page (an iframe into the hosted app). */
function lumio_booking_embed($path, $title)
{
    if (!current_user_can('manage_options')) {
        return;
    }
    $src = esc_url(lumio_booking_base() . $path);
    echo '<div class="wrap">';
    echo '<h1>' . esc_html($title) . '</h1>';
    echo '<p style="color:#646970;margin:4px 0 12px">Your salon overview. If prompted, sign in with your Lumio salon admin account.</p>';
    echo '<iframe src="' . $src . '" title="' . esc_attr($title) . '" allow="payment; clipboard-write" ';
    echo 'style="width:100%;height:calc(100vh - 170px);min-height:600px;border:1px solid #c3c4c7;border-radius:10px;background:#0b1120;"></iframe>';
    echo '</div>';
}

function lumio_booking_page_dashboard() { lumio_booking_embed('/salon', 'Lumio Dashboard'); }
function lumio_booking_page_calendar()  { lumio_booking_embed('/salon/calendar', 'Calendar'); }
function lumio_booking_page_bookings()  { lumio_booking_embed('/salon/bookings', 'Bookings'); }

/* ===========================================================================
 * Settings page (Lumio Booking -> Settings): connect URL + slug for the
 * customer-facing [lumio_booking] shortcode.
 * ======================================================================== */

add_action('admin_init', function () {
    register_setting('lumio_booking_settings', LUMIO_BOOKING_OPT_SITE_URL, array(
        'type' => 'string', 'sanitize_callback' => 'esc_url_raw', 'default' => '',
    ));
    register_setting('lumio_booking_settings', LUMIO_BOOKING_OPT_SLUG, array(
        'type' => 'string', 'sanitize_callback' => 'sanitize_title', 'default' => '',
    ));
});

function lumio_booking_render_settings_page()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    $site_url = get_option(LUMIO_BOOKING_OPT_SITE_URL, '');
    $slug     = get_option(LUMIO_BOOKING_OPT_SLUG, '');
    $base     = lumio_booking_base();
    $preview  = $slug ? $base . '/book/' . $slug : '';

    $opt_url  = esc_attr(LUMIO_BOOKING_OPT_SITE_URL);
    $opt_slug = esc_attr(LUMIO_BOOKING_OPT_SLUG);

    echo '<div class="wrap">';
    echo '<h1>Lumio Booking — Settings</h1>';
    echo '<p>Connect this site to your salon, then add the shortcode <code>[lumio_booking]</code> to any page to show the booking form to customers.</p>';

    echo '<form method="post" action="options.php">';
    settings_fields('lumio_booking_settings');
    echo '<table class="form-table" role="presentation">';

    echo '<tr><th scope="row"><label for="lumio_site_url">Booking site URL</label></th><td>';
    echo '<input name="' . $opt_url . '" id="lumio_site_url" type="url" class="regular-text" value="' . esc_attr($site_url) . '" placeholder="https://lumiobooking.com" />';
    echo '<p class="description">Your Lumio web address (no trailing slash). Leave blank to use https://lumiobooking.com.</p>';
    echo '</td></tr>';

    echo '<tr><th scope="row"><label for="lumio_slug">Salon slug</label></th><td>';
    echo '<input name="' . $opt_slug .