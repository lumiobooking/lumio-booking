import { dialCodeFor } from '../common/phone';
import { PARTY_DEPOSIT_KEY, PartyDeposit, cleanPartyDeposit } from '../payments/party-deposit';
import { CHAT_FOLLOWUP_KEY, followUpSettingsFrom, type FollowUpSettings } from '../messenger/followup';
import { BadRequestException, Injectable, Logger, NotFoundException, OnApplicationBootstrap } from '@nestjs/common';
import { cleanPaymentDetails, nextBankAccount, resolvePayAccount, RESTAURANT_SETTINGS_KEY } from './pay-account';
import { brandsOnly, holdsKeys } from './legacy-gateways';
import { holdMinutesOf } from '../payments/deposit-hold';
import { contactModeOf, STAFF_PRIVACY_KEY, type ContactMode } from '../common/contact-privacy';
import * as crypto from 'crypto';
import { Prisma } from '@prisma/client';
import { INDUSTRIES, INDUSTRY_KEY, isIndustry, resolveIndustry, writeIndustry } from '../common/industry';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser, resolveTenantScope } from '../common/tenant/tenant-context';
import { methodsForSalon } from '../pos/payment-methods';
import { knownTrades } from '../content/trends/trend-feed';
import { signingSecret } from '../common/secret.util';
import { cleanPromoWindow } from './promo-window';
import { channelOf, cleanChannel } from './promo-channel';
import {
  RECEIPT_DESIGN_KEY,
  ReceiptDesign,
  ReceiptProfile,
  DEFAULT_RECEIPT_DESIGN,
  cleanReceiptDesign,
  BOOKING_RULES_KEY,
  BookingRules,
  Branding,
  COMPANY_EXTRA_KEY,
  CompanyExtra,
  DayHours,
  DEFAULT_BOOKING_RULES,
  DEFAULT_BRANDING,
  DEFAULT_COMPANY_EXTRA,
  DEFAULT_NOTIFICATION_SETTINGS,
  DEFAULT_NOTIFICATION_TEMPLATES,
  DEFAULT_PAYMENT_GATEWAYS,
  GATEWAY_IDS,
  GatewayConfig,
  GatewayId,
  NOTIFICATION_SETTINGS_KEY,
  NOTIFICATION_TEMPLATES_KEY,
  VN_NOTIFICATION_TEXTS,
  VN_TEMPLATE_TEXTS,
  LEGACY_NOTIFICATION_DEFAULTS,
  LEGACY_TEMPLATE_DEFAULTS,
  NotificationSettings,
  NotificationTemplates,
  NotifTemplate,
  PAYMENT_GATEWAYS_KEY,
  PaymentGateways,
  POS_SETTINGS_KEY,
  PosSettings,
  DEFAULT_POS_SETTINGS,
  LOYALTY_SETTINGS_KEY,
  LoyaltySettings,
  DEFAULT_LOYALTY_SETTINGS,
  REVIEW_SETTINGS_KEY,
  ANALYTICS_SETTINGS_KEY,
  REBOOKING_SETTINGS_KEY,
  RebookingSettings,
  DEFAULT_REBOOKING_SETTINGS,
  AnalyticsSettings,
  ADS_ID_RE,
  ADS_LABEL_RE,
  DEFAULT_ANALYTICS_SETTINGS,
  ReviewSettings,
  DEFAULT_REVIEW_SETTINGS,
  WEEKDAY_DISCOUNTS_KEY,
  WeekdayDiscounts,
  WeekdayDiscountRule,
  DEFAULT_WEEKDAY_DISCOUNTS,
  DATE_DISCOUNTS_KEY,
  DateDiscounts,
  DateDiscountRule,
  DEFAULT_DATE_DISCOUNTS,
  REMINDER_SETTINGS_KEY,
  ReminderSettings,
  DEFAULT_REMINDER_SETTINGS,
  DEPOSIT_SETTINGS_KEY,
  DepositSettings,
  DEFAULT_DEPOSIT_SETTINGS,
  FIRST_VISIT_DISCOUNT_KEY,
  DEFAULT_FIRST_VISIT_DISCOUNT,
  FirstVisitDiscount,
  GROUP_DISCOUNT_KEY,
  DEFAULT_GROUP_DISCOUNT,
  GroupDiscount,
  BUSINESS_PROFILE_KEY, DEFAULT_BUSINESS_PROFILE, BusinessProfileSettings,
  AI_NOTES_KEY, DEFAULT_AI_NOTES, AiNotes,
} from './settings.constants';
import { ONLINE_PROVIDERS, hubEnabled, isOnlineProvider } from '../payments-hub/online-providers';
import { SmtpEmailProvider } from '../notifications/providers/smtp.provider';
import { BrevoEmailProvider } from '../notifications/providers/brevo.provider';
import { GmailOAuthProvider } from '../notifications/providers/gmail-oauth.provider';
import { TwilioSmsProvider } from '../notifications/providers/twilio.provider';
import { createSmsProvider } from '../notifications/providers/notification-provider.factory';
import { twilioSenderFor, vnEsmsFor, platformEsmsFromEnv } from '../notifications/providers/sms-routing';
import {
  UpdateBookingRulesDto,
  UpdateBrandingDto,
  UpdateCompanyDto,
  UpdateNotificationsDto,
  UpdatePaymentsDto,
} from './dto/update-settings.dto';

/**
 * Returns a usable secret (trimmed) from incoming input, or null when the field
 * is blank or just the masked UI placeholder (•••• / **** / dots). Used so that
 * re-saving settings never overwrites a stored secret with the mask, and so
 * pasted whitespace can't corrupt it (a common cause of Google "invalid_client").
 */
// A secret made ONLY of these characters (bullets of every kind, dots, stars,
// dashes, underscores, spaces) is the UI mask — never a real key.
const MASK_ONLY = /^[\s•●○◦∙⋅·*.\-_—–]+$/;
function stripInvisible(v: string): string {
  return v.replace(/[\u200B-\u200D\uFEFF\u00A0]/g, '').trim();
}
function isMaskOnly(v: string): boolean {
  const t = stripInvisible(v);
  return !t || MASK_ONLY.test(t);
}
function cleanSecret(v: unknown): string | null {
  if (typeof v !== 'string') return null;
  const t = stripInvisible(v);
  if (!t || isMaskOnly(t)) return null;
  return t;
}
// Sanitize a secret READ from storage: a value that is blank or only mask
// characters (e.g. corrupted by an old save) is treated as unset, so a stale
// "••••" can never be sent to a provider and the UI stops showing a false
// "saved" state — the salon is prompted to paste a fresh key instead.
function usableSecret(v: unknown): string {
  if (typeof v !== 'string') return '';
  const t = stripInvisible(v);
  if (!t || isMaskOnly(t)) return '';
  return t;
}

@Injectable()
export class SettingsService implements OnApplicationBootstrap {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  private tenantId(user: AuthenticatedUser): string {
    const id = resolveTenantScope(user);
    if (!id) throw new NotFoundException('No tenant context');
    return id;
  }

  private async readKey<T>(tenantId: string, key: string, fallback: T): Promise<T> {
    const row = await this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key } } });
    return { ...fallback, ...((row?.value as Partial<T>) ?? {}) };
  }

  private async writeKey(tenantId: string, key: string, value: unknown) {
    await this.prisma.setting.upsert({
      where: { tenantId_key: { tenantId, key } },
      update: { value: value as unknown as Prisma.InputJsonValue },
      create: { tenantId, key, value: value as unknown as Prisma.InputJsonValue },
    });
  }

  /** POS settings (tax rate on retail + receipt footer), merged over defaults. */
  async getPosSettings(tenantId: string): Promise<PosSettings> {
    return this.readKey<PosSettings>(tenantId, POS_SETTINGS_KEY, DEFAULT_POS_SETTINGS);
  }

  /**
   * POS settings plus the buttons this till should actually show.
   *
   * Resolved here rather than in the page so the rule — the salon's own choice,
   * else the default for its market — lives in one place. `paymentMethods`
   * stays alongside as the raw choice, where empty means "follow the market";
   * that is what every salon that has never opened this screen has, which is
   * why none of them change.
   */
  private async posWithTillButtons(tenantId: string, market: string | null | undefined) {
    const [pos, legacy] = await Promise.all([
      this.getPosSettings(tenantId),
      // A restaurant that set its account in the till's own settings before
      // this screen had one: shown here so the owner sees it, not an empty form.
      this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: RESTAURANT_SETTINGS_KEY } } }).catch(() => null),
    ]);
    const pay = resolvePayAccount(pos, (legacy?.value as { bank?: unknown } | null)?.bank);
    return { ...pos, bankAccount: pay.bank, printPayQr: pay.printPayQr, resolvedPaymentMethods: methodsForSalon(market, pos.paymentMethods) };
  }

  /** Loyalty program settings, merged over defaults. */
  async getLoyaltySettings(tenantId: string): Promise<LoyaltySettings> {
    return this.readKey<LoyaltySettings>(tenantId, LOYALTY_SETTINGS_KEY, DEFAULT_LOYALTY_SETTINGS);
  }

  async updateLoyalty(
    user: AuthenticatedUser,
    dto: { enabled?: boolean; earnPointsPerDollar?: number; redeemCentsPerPoint?: number; minRedeemPoints?: number },
  ) {
    const tenantId = this.tenantId(user);
    const cur = await this.getLoyaltySettings(tenantId);
    const num = (v: unknown, d: number) => (typeof v === 'number' && v >= 0 ? v : d);
    const next: LoyaltySettings = {
      enabled: typeof dto.enabled === 'boolean' ? dto.enabled : cur.enabled,
      earnPointsPerDollar: num(dto.earnPointsPerDollar, cur.earnPointsPerDollar),
      redeemCentsPerPoint: num(dto.redeemCentsPerPoint, cur.redeemCentsPerPoint),
      minRedeemPoints: num(dto.minRedeemPoints, cur.minRedeemPoints),
    };
    await this.writeKey(tenantId, LOYALTY_SETTINGS_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.loyalty_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  /** Review-reward program settings, merged over defaults. */
  async getReviewSettings(tenantId: string): Promise<ReviewSettings> {
    return this.readKey<ReviewSettings>(tenantId, REVIEW_SETTINGS_KEY, DEFAULT_REVIEW_SETTINGS);
  }

  /**
   * The "write a Google review" link the connected Business Profile gave us —
   * or null when no profile is connected / no location chosen yet.
   *
   * Read straight from the connection's own settings row so this module does
   * not depend on the Google Reviews module (which depends on this one).
   */
  async googleProfileReviewLink(tenantId: string): Promise<{ url: string; placeId: string; locationTitle: string } | null> {
    const g = await this.readKey<{ connected?: boolean; locationId?: string; locationTitle?: string; placeId?: string; newReviewUri?: string }>(tenantId, 'googleReviews', {});
    if (!g.connected || !g.locationId) return null;
    const placeId = (g.placeId ?? '').trim();
    const url = (g.newReviewUri ?? '').trim() || (placeId ? `https://search.google.com/local/writereview?placeid=${encodeURIComponent(placeId)}` : '');
    return url ? { url, placeId, locationTitle: (g.locationTitle ?? '').trim() } : null;
  }

  /**
   * Build the customer-facing "write a Google review" link.
   *
   * Prefers the salon's Google Place ID, which produces the official
   * `search.google.com/local/writereview` link. On a phone this hands off to
   * the Google Maps app — where the customer is almost always already signed in —
   * instead of a browser that may demand a login they don't remember. Falls back
   * to a manually-pasted URL when no Place ID is configured.
   */
  googleReviewUrlFrom(settings: { googlePlaceId?: string; googleReviewUrl?: string }): string | null {
    const raw = (settings.googlePlaceId ?? '').trim();
    if (raw) {
      // If a full URL was pasted (e.g. g.page/r/…/review, maps.google, search.google),
      // use it as-is — it already opens the right review sheet or Maps listing.
      if (/^https?:\/\//i.test(raw)) return raw;
      // Otherwise treat it as a real Place ID (ChIJ… / 0x… / numeric CID) and build
      // the official write-review link, which opens the Maps app where the customer
      // is already signed in instead of a browser that may demand a login.
      return `https://search.google.com/local/writereview?placeid=${encodeURIComponent(raw)}`;
    }
    const url = (settings.googleReviewUrl ?? '').trim();
    return url || null;
  }

  /**
   * The link the review program actually uses: what the owner typed, else what
   * the connected Google Business Profile knows. Connecting Google once is
   * enough — nobody should have to go and find their Place ID a second time.
   */
  async effectiveGoogleReviewUrl(tenantId: string, settings?: { googlePlaceId?: string; googleReviewUrl?: string }): Promise<string | null> {
    const s = settings ?? (await this.getReviewSettings(tenantId));
    return this.googleReviewUrlFrom(s) ?? (await this.googleProfileReviewLink(tenantId))?.url ?? null;
  }

  async getAnalyticsSettings(tenantId: string): Promise<AnalyticsSettings> {
    return this.readKey<AnalyticsSettings>(tenantId, ANALYTICS_SETTINGS_KEY, DEFAULT_ANALYTICS_SETTINGS);
  }

  /** The salon's own rules for every AI assistant. Empty text = none. */
  async getAiNotes(tenantId: string): Promise<AiNotes> {
    const v = await this.readKey<AiNotes>(tenantId, AI_NOTES_KEY, DEFAULT_AI_NOTES);
    return { text: typeof v?.text === 'string' ? v.text : '' };
  }

  getAiNotesFor(user: AuthenticatedUser): Promise<AiNotes> {
    return this.getAiNotes(this.tenantId(user));
  }

  async updateAiNotes(user: AuthenticatedUser, dto: { text?: unknown }) {
    const tenantId = this.tenantId(user);
    const text = typeof dto.text === 'string' ? dto.text.trim().slice(0, 4000) : '';
    await this.writeKey(tenantId, AI_NOTES_KEY, { text });
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.ai_notes_updated', resourceType: 'tenant', resourceId: tenantId, metadata: { length: text.length } });
    return { text };
  }

  /** The salon's follow-up for quiet chats (see messenger/followup). Off until the salon turns it on. */
  async getChatFollowUp(user: AuthenticatedUser): Promise<FollowUpSettings> {
    const tenantId = this.tenantId(user);
    const row = await this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: CHAT_FOLLOWUP_KEY } } });
    return followUpSettingsFrom(row?.value);
  }

  async updateChatFollowUp(user: AuthenticatedUser, dto: Record<string, unknown>): Promise<FollowUpSettings> {
    const tenantId = this.tenantId(user);
    const current = await this.getChatFollowUp(user);
    const pick = (k: keyof FollowUpSettings) => (dto && Object.prototype.hasOwnProperty.call(dto, k) ? { [k]: dto[k] } : {});
    const next = followUpSettingsFrom({
      ...current,
      ...pick('enabled'), ...pick('firstAfterMin'), ...pick('secondAfterMin'), ...pick('hourFrom'), ...pick('hourTo'),
      // The salon's own reminder wording (cleaned + capped in cleanFollowUp).
      ...pick('messageVi'), ...pick('messageEn'),
    });
    // A second nudge only counts when there is a delay for it.
    next.maxPerWindow = next.secondAfterMin > 0 ? 2 : 1;
    await this.writeKey(tenantId, CHAT_FOLLOWUP_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.chat_followup_updated', resourceType: 'tenant', resourceId: tenantId, metadata: { enabled: next.enabled, firstAfterMin: next.firstAfterMin, secondAfterMin: next.secondAfterMin, hourFrom: next.hourFrom, hourTo: next.hourTo, customVi: next.messageVi.length > 0, customEn: next.messageEn.length > 0 } });
    return next;
  }

  /** The salon's industry (Nail, Nha khoa, Nhà hàng…), resolved against its businessType. */
  async getIndustry(tenantId: string): Promise<string> {
    const [t, row] = await Promise.all([
      this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { businessType: true } }),
      this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: INDUSTRY_KEY } } }),
    ]);
    return resolveIndustry(row?.value ?? null, (t as { businessType?: string } | null)?.businessType ?? null);
  }

  async getIndustryFor(user: AuthenticatedUser) {
    const tenantId = this.tenantId(user);
    return { industry: await this.getIndustry(tenantId), options: INDUSTRIES.map(({ key, vi, en, group }) => ({ key, vi, en, group })) };
  }

  /** The owner puts THEIR salon in an industry: words, menu, businessType and marketing trade move together. */
  async updateIndustry(user: AuthenticatedUser, industry: unknown) {
    const tenantId = this.tenantId(user);
    if (!isIndustry(industry)) throw new BadRequestException('Unknown industry.');
    const def = await writeIndustry(this.prisma as never, tenantId, String(industry).toUpperCase());
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.industry_updated', resourceType: 'tenant', resourceId: tenantId, metadata: { industry: def.key, businessType: def.businessType } });
    return this.getIndustryFor(user);
  }

  async getBusinessProfile(tenantId: string): Promise<BusinessProfileSettings> {
    return this.readKey<BusinessProfileSettings>(tenantId, BUSINESS_PROFILE_KEY, DEFAULT_BUSINESS_PROFILE);
  }

  /**
   * Save what the business says it is.
   *
   * Free text, trimmed and capped, with no validation beyond length — the whole
   * point of these fields is to hold what a four-value enum could not, so
   * constraining their shape would recreate the problem in a new form.
   */
  async updateBusinessProfile(user: AuthenticatedUser, dto: Partial<BusinessProfileSettings>) {
    const tenantId = this.tenantId(user);
    const cur = await this.getBusinessProfile(tenantId);
    const take = (v: unknown, fallback: string, max = 600) =>
      typeof v === 'string' ? v.trim().slice(0, max) : fallback;
    const next: BusinessProfileSettings = {
      whatWeDo: take(dto.whatWeDo, cur.whatWeDo),
      whoWeServe: take(dto.whoWeServe, cur.whoWeServe),
      languages: take(dto.languages, cur.languages, 120),
      serviceArea: take(dto.serviceArea, cur.serviceArea, 200),
      edge: take(dto.edge, cur.edge),
      avoid: take(dto.avoid, cur.avoid),
      // Validated against the engine's own table rather than trimmed like the
      // prose fields: this one is a lookup key, and an unrecognised value
      // would send the trends board to a trade that does not exist — which
      // reads on screen as an empty board with nothing explaining why.
      // Anything unknown resolves to '', i.e. "use the general category".
      trade: knownTrades().includes(String(dto.trade ?? '').toUpperCase())
        ? String(dto.trade).toUpperCase()
        : (dto.trade === '' ? '' : cur.trade),
      // A person touched the trade field (even to blank it) — that is a
      // decision, and the profile scan keeps its hands off from now on.
      tradeSource: dto.trade !== undefined ? 'manual' : (cur.tradeSource ?? ''),
    };
    await this.writeKey(tenantId, BUSINESS_PROFILE_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.business_profile_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  async getRebookingSettings(tenantId: string): Promise<RebookingSettings> {
    return this.readKey<RebookingSettings>(tenantId, REBOOKING_SETTINGS_KEY, DEFAULT_REBOOKING_SETTINGS);
  }

  async updateRebooking(user: AuthenticatedUser, dto: { enabled?: boolean; daysAfter?: number; email?: boolean; sms?: boolean }) {
    const tenantId = this.tenantId(user);
    const cur = await this.getRebookingSettings(tenantId);
    const next: RebookingSettings = {
      enabled: typeof dto.enabled === 'boolean' ? dto.enabled : cur.enabled,
      daysAfter: Math.min(120, Math.max(1, typeof dto.daysAfter === 'number' && dto.daysAfter > 0 ? Math.round(dto.daysAfter) : cur.daysAfter)),
      email: typeof dto.email === 'boolean' ? dto.email : cur.email,
      sms: typeof dto.sms === 'boolean' ? dto.sms : cur.sms,
    };
    await this.writeKey(tenantId, REBOOKING_SETTINGS_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.rebooking_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  /** Save the salon's GA4 / GTM IDs. Both are public front-end IDs (not secrets);
   *  we still validate the shape so a typo can't inject arbitrary script. */
  async updateAnalytics(user: AuthenticatedUser, dto: { ga4Id?: string; gtmId?: string; mode?: string; adsId?: string; adsLabel?: string }) {
    const tenantId = this.tenantId(user);
    const cur = await this.getAnalyticsSettings(tenantId);
    const ga = typeof dto.ga4Id === 'string' ? dto.ga4Id.trim().toUpperCase() : cur.ga4Id;
    const gtm = typeof dto.gtmId === 'string' ? dto.gtmId.trim().toUpperCase() : cur.gtmId;
    // People paste "AW-123456789/AbC-xyz" (the send_to) into one box — split it.
    const adsRaw = typeof dto.adsId === 'string' ? dto.adsId.trim().replace(/\s+/g, '') : null;
    const [adsPart, labelFromId] = adsRaw !== null ? adsRaw.split('/') : [null, undefined];
    const ads = adsPart !== null ? adsPart.toUpperCase() : (cur.adsId ?? '');
    const adsLabel = typeof dto.adsLabel === 'string' && dto.adsLabel.trim() !== ''
      ? dto.adsLabel.trim()
      : labelFromId ? labelFromId.trim()
      : typeof dto.adsLabel === 'string' ? '' : (cur.adsLabel ?? '');
    const mode = typeof dto.mode === 'string' && ['', 'none', 'ga4', 'gtm'].includes(dto.mode) ? (dto.mode as AnalyticsSettings['mode']) : (cur.mode ?? '');
    const next: AnalyticsSettings = {
      ga4Id: ga === '' || /^G-[A-Z0-9]{4,20}$/.test(ga) ? ga : cur.ga4Id,
      gtmId: gtm === '' || /^GTM-[A-Z0-9]{4,12}$/.test(gtm) ? gtm : cur.gtmId,
      mode,
      adsId: ads === '' || ADS_ID_RE.test(ads) ? ads : (cur.adsId ?? ''),
      adsLabel: adsLabel === '' || ADS_LABEL_RE.test(adsLabel) ? adsLabel : (cur.adsLabel ?? ''),
    };
    await this.writeKey(tenantId, ANALYTICS_SETTINGS_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.analytics_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  async updateReview(
    user: AuthenticatedUser,
    dto: { enabled?: boolean; reviewMode?: string; googlePlaceId?: string; googleReviewUrl?: string; staffPointsPerFeedback?: number; staffBonusFor5Star?: number; customerPoints?: number; minRatingForGoogle?: number; requireRealVisit?: boolean; visitWindowHours?: number; dailyCapPerStaff?: number; dedupDays?: number; staffPointsPerSend?: number; sendDailyCap?: number; sendDedupHours?: number; anchorToVisits?: boolean; visitBuffer?: number; onlyBusinessHours?: boolean ; postVisitEnabled?: boolean; postVisitDelayMinutes?: number; postVisitEmail?: boolean; postVisitSms?: boolean; postVisitCooldownDays?: number },
  ) {
    const tenantId = this.tenantId(user);
    const cur = await this.getReviewSettings(tenantId);
    const num = (v: unknown, d: number) => (typeof v === 'number' && v >= 0 ? v : d);
    const next: ReviewSettings = {
      enabled: typeof dto.enabled === 'boolean' ? dto.enabled : cur.enabled,
      reviewMode: dto.reviewMode === 'rate_first' || dto.reviewMode === 'direct' ? dto.reviewMode : (cur.reviewMode ?? 'direct'),
      googlePlaceId: typeof dto.googlePlaceId === 'string' ? dto.googlePlaceId.trim() : (cur.googlePlaceId ?? ''),
      googleReviewUrl: typeof dto.googleReviewUrl === 'string' ? dto.googleReviewUrl.trim() : cur.googleReviewUrl,
      staffPointsPerFeedback: num(dto.staffPointsPerFeedback, cur.staffPointsPerFeedback),
      staffBonusFor5Star: num(dto.staffBonusFor5Star, cur.staffBonusFor5Star),
      customerPoints: num(dto.customerPoints, cur.customerPoints),
      minRatingForGoogle: Math.min(5, Math.max(1, num(dto.minRatingForGoogle, cur.minRatingForGoogle))),
      requireRealVisit: typeof dto.requireRealVisit === 'boolean' ? dto.requireRealVisit : (cur.requireRealVisit ?? true),
      visitWindowHours: num(dto.visitWindowHours, cur.visitWindowHours ?? 48),
      dailyCapPerStaff: num(dto.dailyCapPerStaff, cur.dailyCapPerStaff ?? 10),
      dedupDays: num(dto.dedupDays, cur.dedupDays ?? 7),
      staffPointsPerSend: num(dto.staffPointsPerSend, cur.staffPointsPerSend ?? 5),
      sendDailyCap: num(dto.sendDailyCap, cur.sendDailyCap ?? 20),
      sendDedupHours: num(dto.sendDedupHours, cur.sendDedupHours ?? 12),
      anchorToVisits: typeof dto.anchorToVisits === 'boolean' ? dto.anchorToVisits : (cur.anchorToVisits ?? true),
      visitBuffer: num(dto.visitBuffer, cur.visitBuffer ?? 3),
      onlyBusinessHours: typeof dto.onlyBusinessHours === 'boolean' ? dto.onlyBusinessHours : (cur.onlyBusinessHours ?? true),
      postVisitEnabled: typeof dto.postVisitEnabled === 'boolean' ? dto.postVisitEnabled : (cur.postVisitEnabled ?? false),
      postVisitDelayMinutes: Math.min(180, num(dto.postVisitDelayMinutes, cur.postVisitDelayMinutes ?? 25)),
      postVisitEmail: typeof dto.postVisitEmail === 'boolean' ? dto.postVisitEmail : (cur.postVisitEmail ?? true),
      postVisitSms: typeof dto.postVisitSms === 'boolean' ? dto.postVisitSms : (cur.postVisitSms ?? true),
      postVisitCooldownDays: num(dto.postVisitCooldownDays, cur.postVisitCooldownDays ?? 45),
    };
    await this.writeKey(tenantId, REVIEW_SETTINGS_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.review_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  async updatePos(
    user: AuthenticatedUser,
    dto: {
      taxRatePercent?: number;
      receiptFooter?: string;
      primaryCardGateway?: string;
      cardSurchargePercent?: number;
      cardSurchargeEnabled?: boolean;
      transferInstructions?: string;
      transferQrUrl?: string;
      tipsEnabled?: boolean;
      requireShift?: boolean;
      paymentMethods?: string[];
      paymentDetails?: Record<string, { instructions?: string; qrUrl?: string }>;
      bankAccount?: { bin?: string; accountNo?: string; accountName?: string } | null;
      printPayQr?: boolean;
    },
  ) {
    const tenantId = this.tenantId(user);
    const cur = await this.getPosSettings(tenantId);
    const next: PosSettings = {
      // Carried forward explicitly. This object is rebuilt from scratch on every
      // save, so anything not named here is destroyed — a salon that had chosen
      // its till buttons would have lost them the next time someone edited the
      // tax rate on an unrelated screen.
      paymentMethods: dto.paymentMethods ?? cur.paymentMethods,
      // Merged, not replaced: the settings screen saves one method at a time,
      // and a whole-object write would wipe the other five.
      paymentDetails: dto.paymentDetails
        ? { ...(cur.paymentDetails ?? {}), ...cleanPaymentDetails(dto.paymentDetails) }
        : cur.paymentDetails,
      taxRatePercent:
        typeof dto.taxRatePercent === 'number' && dto.taxRatePercent >= 0 ? dto.taxRatePercent : cur.taxRatePercent,
      receiptFooter: typeof dto.receiptFooter === 'string' ? dto.receiptFooter : cur.receiptFooter,
      primaryCardGateway:
        typeof dto.primaryCardGateway === 'string' ? dto.primaryCardGateway : cur.primaryCardGateway,
      cardSurchargePercent:
        typeof dto.cardSurchargePercent === 'number' && dto.cardSurchargePercent >= 0 && dto.cardSurchargePercent <= 20
          ? dto.cardSurchargePercent : cur.cardSurchargePercent,
      cardSurchargeEnabled:
        typeof dto.cardSurchargeEnabled === 'boolean' ? dto.cardSurchargeEnabled : (cur.cardSurchargeEnabled ?? false),
      transferInstructions:
        typeof dto.transferInstructions === 'string' ? dto.transferInstructions : cur.transferInstructions,
      transferQrUrl: typeof dto.transferQrUrl === 'string' ? dto.transferQrUrl : cur.transferQrUrl,
      // A salon that has never seen this setting keeps tipping on, which is
      // what it has always done.
      tipsEnabled: typeof dto.tipsEnabled === 'boolean' ? dto.tipsEnabled : (cur.tipsEnabled ?? true),
      requireShift: typeof dto.requireShift === 'boolean' ? dto.requireShift : (cur.requireShift ?? false),
      // Only touched when sent: null (or junk) removes it, an object is cleaned
      // to a 6-digit BIN + account number; never set stays absent.
      ...nextBankAccount(dto, cur),
      printPayQr: typeof dto.printPayQr === 'boolean' ? dto.printPayQr : (cur.printPayQr ?? true),
    };
    await this.writeKey(tenantId, POS_SETTINGS_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.pos_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  // ---- Printed bill ---------------------------------------------------------

  /** The salon's receipt design, with the one footer (kept in POS settings). */
  async getReceiptDesign(tenantId: string): Promise<ReceiptDesign & { footer: string }> {
    const [design, pos] = await Promise.all([
      this.readKey<ReceiptDesign>(tenantId, RECEIPT_DESIGN_KEY, DEFAULT_RECEIPT_DESIGN),
      this.getPosSettings(tenantId),
    ]);
    return { ...cleanReceiptDesign(design), footer: pos.receiptFooter ?? '' };
  }

  /**
   * What the till prints at the top, plus the design. Served to the POS (any
   * cashier), so it carries only what a receipt shows — never settings that
   * are the owner's alone.
   */
  async receiptProfile(tenantId: string): Promise<ReceiptProfile> {
    const [tenant, extra, design] = await Promise.all([
      this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { name: true, slug: true, contactPhone: true, branding: true } }),
      this.readKey<CompanyExtra>(tenantId, COMPANY_EXTRA_KEY, DEFAULT_COMPANY_EXTRA),
      this.getReceiptDesign(tenantId),
    ]);
    if (!tenant) throw new NotFoundException('Tenant not found');
    return {
      shop: {
        name: tenant.name,
        address: extra.address ?? '',
        phone: tenant.contactPhone ?? '',
        website: extra.website ?? '',
        logoUrl: this.brandingFrom(tenant.branding).logoUrl ?? '',
        bookingSlug: tenant.slug,
      },
      design,
    };
  }

  /** The owner edits the bill. The footer goes to the one footer the till already prints. */
  async updateReceipt(user: AuthenticatedUser, dto: Partial<ReceiptDesign> & { footer?: string }) {
    const tenantId = this.tenantId(user);
    const cur = await this.readKey<ReceiptDesign>(tenantId, RECEIPT_DESIGN_KEY, DEFAULT_RECEIPT_DESIGN);
    const next = cleanReceiptDesign(dto, cleanReceiptDesign(cur));
    await this.writeKey(tenantId, RECEIPT_DESIGN_KEY, next);
    if (typeof dto.footer === 'string') {
      const pos = await this.getPosSettings(tenantId);
      await this.writeKey(tenantId, POS_SETTINGS_KEY, { ...pos, receiptFooter: dto.footer.replace(/\r/g, '').trim().slice(0, 500) });
    }
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.receipt_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  /** Booking rules merged over defaults, with a guaranteed 7-day hours array. */
  async getBookingRules(tenantId: string): Promise<BookingRules> {
    const merged = await this.readKey<BookingRules>(tenantId, BOOKING_RULES_KEY, DEFAULT_BOOKING_RULES);
    // Online payment is only truly available when a gateway is enabled AND has a
    // secret saved. Derive it live so a stale stored flag can never offer "Pay
    // online" to customers when no gateway is actually connected.
    // The keys typed into Settings → Payments never took a card (they were
    // stored, nothing read them), so "Pay online" offered on those alone was
    // a promise nobody kept — recorded as paid while no money moved. The only
    // thing that can take a customer's card online is a LIVE connection on the
    // payment hub to a provider with a hosted checkout.
    const onlinePaymentEnabled = await this.hasOnlineProvider(tenantId);
    return { ...merged, onlinePaymentEnabled, businessHours: normalizeHours(merged.businessHours), daysOff: merged.daysOff ?? [] };
  }

  // ---- Messenger OAuth stash (multi-page pick) ---------------------------
  // An agency Facebook account manages MANY clients' pages, so one OAuth can
  // return a pile of pages. The candidates wait here (15 min) while the staff
  // picks ONE in the UI. Page tokens never leave the server.
  async setMessengerOauthStash(tenantId: string, pages: unknown[]): Promise<void> {
    await this.writeKey(tenantId, 'messenger_oauth_stash', { at: new Date().toISOString(), pages });
  }

  async getMessengerOauthStash(tenantId: string): Promise<{ id: string; name?: string; access_token?: string; igId?: string | null }[]> {
    const raw = await this.readKey<{ at?: string; pages?: unknown[] }>(tenantId, 'messenger_oauth_stash', {});
    if (!raw?.at || Date.now() - Date.parse(raw.at) > 15 * 60 * 1000) return [];
    return (raw.pages || []) as { id: string; name?: string; access_token?: string; igId?: string | null }[];
  }

  async clearMessengerOauthStash(tenantId: string): Promise<void> {
    await this.writeKey(tenantId, 'messenger_oauth_stash', {});
  }

  /** Last Facebook-connect attempt, step by step — shown to Support in the UI
   *  so a failed OAuth can be diagnosed from a screenshot, no log digging. */
  async setMessengerConnectTrace(tenantId: string, steps: string[]): Promise<void> {
    // Keep the head of the story AND its last line ("done in …"): a grant with
    // many Pages used to push the timing off the end.
    const kept = steps.length > 60 ? [...steps.slice(0, 59), steps[steps.length - 1]] : steps;
    await this.writeKey(tenantId, 'messenger_connect_trace', { at: new Date().toISOString(), steps: kept });
  }

  /** The Facebook account whose grant the Page token came from (name for screens). */
  async setMessengerConnectedBy(tenantId: string, by: { name: string | null; fbUserId: string | null; at: string }): Promise<void> {
    await this.writeKey(tenantId, 'messenger_connected_by', by);
  }

  async getMessengerConnectedBy(tenantId: string): Promise<{ name: string | null; fbUserId: string | null; at: string } | null> {
    const raw = await this.readKey<{ name?: string | null; fbUserId?: string | null; at?: string }>(tenantId, 'messenger_connected_by', {});
    if (!raw?.at || (!raw.name && !raw.fbUserId)) return null;
    return { name: raw.name ?? null, fbUserId: raw.fbUserId ?? null, at: raw.at };
  }

  /** What the last connect did with the publishing scopes. See messenger/publish-grant. */
  async setMessengerPublishGrant(tenantId: string, grant: { at: string; scopes: Record<string, string> }): Promise<void> {
    await this.writeKey(tenantId, 'messenger_publish_grant', grant);
  }

  async getMessengerPublishGrant(tenantId: string): Promise<{ at: string; scopes: Record<string, string> } | null> {
    const raw = await this.readKey<{ at?: string; scopes?: Record<string, string> }>(tenantId, 'messenger_publish_grant', {});
    if (!raw?.at || !raw.scopes || typeof raw.scopes !== 'object') return null;
    return { at: raw.at, scopes: raw.scopes };
  }

  /** Whether the Page token still works, and why not. See messenger/page-health. */
  async setMessengerHealth(tenantId: string, health: { state: string; at: string; raw: string | null; lost: boolean }): Promise<void> {
    await this.writeKey(tenantId, 'messenger_health', health);
  }

  async getMessengerHealth(tenantId: string): Promise<{ state: string; at: string; raw: string | null; lost: boolean } | null> {
    const raw = await this.readKey<{ state?: string; at?: string; raw?: string | null; lost?: boolean }>(tenantId, 'messenger_health', {});
    if (!raw?.at || !raw.state) return null;
    return { state: raw.state, at: raw.at, raw: raw.raw ?? null, lost: raw.lost === true };
  }

  async getMessengerConnectTrace(tenantId: string): Promise<{ at: string; steps: string[] } | null> {
    const raw = await this.readKey<{ at?: string; steps?: string[] }>(tenantId, 'messenger_connect_trace', {});
    if (!raw?.at || !Array.isArray(raw.steps)) return null;
    return { at: raw.at, steps: raw.steps };
  }

  brandingFrom(branding: unknown): Branding {
    return { ...DEFAULT_BRANDING, ...((branding as Partial<Branding>) ?? {}) };
  }

  /** Which card brands the salon uses at the counter (legacy-gateways.ts: no keys, ever). */
  async getGateways(tenantId: string): Promise<PaymentGateways> {
    return brandsOnly(await this.readKey<PaymentGateways>(tenantId, PAYMENT_GATEWAYS_KEY, DEFAULT_PAYMENT_GATEWAYS));
  }

  /**
   * Once per boot (idempotent): wipe the API keys and secrets the old
   * "card brand" form stored in plain settings — they connected nothing, and
   * some are an owner's login that a browser filled in. Each row stays in its
   * own salon; only the on/off is kept.
   */
  onApplicationBootstrap() {
    const on = (process.env.HOUSEKEEPING_ENABLED ?? (process.env.NODE_ENV === 'production' ? 'true' : 'false')) === 'true';
    if (!on) return;
    setTimeout(() => {
      this.wipeLegacyGatewayKeys()
        .then((n) => { if (n) new Logger('Settings').log(`Card-brand settings: removed stored keys from ${n} salon(s).`); })
        .catch((e) => new Logger('Settings').warn(`Card-brand key wipe failed: ${(e as Error).message}`));
    }, 75 * 1000);
  }

  async wipeLegacyGatewayKeys(): Promise<number> {
    const rows = await this.prisma.setting.findMany({ where: { key: PAYMENT_GATEWAYS_KEY }, select: { tenantId: true, value: true } });
    let n = 0;
    for (const r of rows) {
      if (!holdsKeys(r.value)) continue;
      const res = await this.prisma.setting.updateMany({
        where: { tenantId: r.tenantId, key: PAYMENT_GATEWAYS_KEY },
        data: { value: brandsOnly(r.value as never) as unknown as Prisma.InputJsonValue },
      });
      n += res.count ? 1 : 0;
    }
    return n;
  }

  /** Full notification settings (incl. secrets) — server-side use. */
  /** The tenant's market, defaulting to 'US' on any failure — which makes
   *  every market branch below a no-op, i.e. exactly today's behaviour. */
  private async marketOf(tenantId: string): Promise<string> {
    try {
      const t = await this.prisma.tenant.findUnique({
        where: { id: tenantId },
        select: { market: true } as never,
      });
      return String((t as unknown as { market?: string } | null)?.market ?? 'US').toUpperCase();
    } catch {
      return 'US';
    }
  }

  /** Lumio's shared Zalo OA / brandname is configured on the server — every
   *  VN salon then sends through it without touching a setting. */
  private sharedVnChannel(): { active: boolean; zns: boolean; sms: boolean } {
    const c = vnEsmsFor({ market: 'VN', platform: platformEsmsFromEnv() });
    return { active: !!c, zns: !!(c && c.oaid && (c.znsBookingTempId || c.znsReminderTempId)), sms: !!(c && c.brandname) };
  }

  /** The raw stored object for a key, without defaults — to tell "never set"
   *  from "set to the default value". */
  private async rawKey(tenantId: string, key: string): Promise<Record<string, unknown>> {
    try {
      const row = await this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key } } });
      return ((row?.value as Record<string, unknown> | null) ?? {});
    } catch { return {}; }
  }

  async getNotificationSettings(tenantId: string): Promise<NotificationSettings> {
    const merged = await this.readKey<NotificationSettings>(tenantId, NOTIFICATION_SETTINGS_KEY, DEFAULT_NOTIFICATION_SETTINGS);
    const smtp = { ...DEFAULT_NOTIFICATION_SETTINGS.smtp, ...(merged.smtp ?? {}) };
    const brevo = { ...DEFAULT_NOTIFICATION_SETTINGS.brevo, ...(merged.brevo ?? {}) };
    const gmail = { ...DEFAULT_NOTIFICATION_SETTINGS.gmail, ...(merged.gmail ?? {}) };
    const twilio = { ...DEFAULT_NOTIFICATION_SETTINGS.twilio, ...(merged.twilio ?? {}) };
    // Self-heal secrets that an old save corrupted to the UI mask, so a stale
    // "••••" is never sent to a provider (the cause of Brevo 401 "Key not found"
    // that appeared to persist across deploys). A real key is never all-mask.
    brevo.apiKey = usableSecret(brevo.apiKey);
    twilio.authToken = usableSecret(twilio.authToken);
    const esms = { ...DEFAULT_NOTIFICATION_SETTINGS.esms, ...(merged.esms ?? {}) };
    esms.secretKey = usableSecret(esms.secretKey);
    smtp.pass = usableSecret(smtp.pass);
    gmail.clientSecret = usableSecret(gmail.clientSecret);
    const out: NotificationSettings = { ...merged, smtp, brevo, gmail, twilio, esms };

    // Vietnamese copy, as an overlay: only onto fields the salon has NOT
    // customised (still equal to the English default). A VN salon reads
    // Vietnamese out of the box; a customised field — any market — is never
    // touched; US/CA salons take the (market !== 'VN') early exit unchanged.
    out.market = await this.marketOf(tenantId);
    // Set up once for the whole of Vietnam: with Lumio's shared Zalo/SMS
    // channel live, a VN salon that never touched the switch confirms
    // bookings to customers by default. An explicit "off" is kept.
    if (out.market === 'VN' && this.sharedVnChannel().active) {
      const raw = await this.rawKey(tenantId, NOTIFICATION_SETTINGS_KEY);
      if (raw.smsCustomerOnBooking === undefined) out.smsCustomerOnBooking = true;
    }
    // Any market: a field still holding an OLDER default verbatim (saved as-is,
    // never edited) follows the current default — which names the technician.
    for (const [k, olds] of Object.entries(LEGACY_NOTIFICATION_DEFAULTS)) {
      const key = k as keyof NotificationSettings;
      if ((olds ?? []).includes(out[key] as string)) (out as unknown as Record<string, unknown>)[key] = DEFAULT_NOTIFICATION_SETTINGS[key];
    }
    if (out.market === 'VN') {
      for (const [k, vnText] of Object.entries(VN_NOTIFICATION_TEXTS)) {
        const key = k as keyof NotificationSettings;
        // "Untouched" means the salon never wrote this field — which includes a
        // salon still carrying an OLDER English default it saved verbatim.
        const legacy = LEGACY_NOTIFICATION_DEFAULTS[key] ?? [];
        const untouched = out[key] === DEFAULT_NOTIFICATION_SETTINGS[key] || legacy.includes(out[key] as string);
        if (untouched) (out as unknown as Record<string, unknown>)[key] = vnText;
      }
    }
    return out;
  }

  /** Notification view for the frontend — hides the SMTP pass + Twilio token. */
  private sanitizeNotifications(n: NotificationSettings) {
    return {
      mailService: n.mailService,
      replyTo: n.replyTo,
      senderName: n.senderName,
      senderEmail: n.senderEmail,
      adminEmail: n.adminEmail,
      adminPhone: n.adminPhone,
      emailCustomerOnBooking: n.emailCustomerOnBooking,
      emailAdminOnBooking: n.emailAdminOnBooking,
      smsCustomerOnBooking: n.smsCustomerOnBooking,
      smsAdminOnBooking: n.smsAdminOnBooking,
      emailSubjectCustomer: n.emailSubjectCustomer,
      emailIntroCustomer: n.emailIntroCustomer,
      emailSubjectAdmin: n.emailSubjectAdmin,
      emailIntroAdmin: n.emailIntroAdmin,
      emailFooter: n.emailFooter,
      smsCustomer: n.smsCustomer,
      smsAdmin: n.smsAdmin,
      smtp: {
        host: n.smtp.host,
        port: n.smtp.port,
        user: n.smtp.user,
        fromEmail: n.smtp.fromEmail,
        secure: n.smtp.secure,
        connected: n.smtp.pass.length > 0,
      },
      brevo: {
        senderEmail: n.brevo.senderEmail,
        senderName: n.brevo.senderName,
        connected: n.brevo.apiKey.length > 0,
      },
      gmail: {
        clientId: n.gmail.clientId,
        senderEmail: n.gmail.senderEmail,
        // "connected" only when OAuth has produced a refresh token.
        connected: n.gmail.refreshToken.length > 0,
      },
      twilio: {
        accountSid: n.twilio.accountSid,
        fromNumber: n.twilio.fromNumber,
        connected: n.twilio.authToken.length > 0,
      },
      // secretKey never leaves the server; `connected` is all the UI needs to
      // know, and is the same shape every other provider here uses.
      esms: {
        apiKey: n.esms?.apiKey ?? '',
        brandname: n.esms?.brandname ?? '',
        oaid: n.esms?.oaid ?? '',
        znsBookingTempId: n.esms?.znsBookingTempId ?? '',
        znsReminderTempId: n.esms?.znsReminderTempId ?? '',
        connected: (n.esms?.secretKey ?? '').length > 0,
      },
      // Whether Lumio's shared VN channel is live — no keys, just the fact,
      // so a VN salon is told it has nothing to set up.
      sharedVn: n.market === 'VN' ? this.sharedVnChannel() : null,
    };
  }

  async updateNotifications(user: AuthenticatedUser, dto: UpdateNotificationsDto) {
    const tenantId = this.tenantId(user);
    const cur = await this.getNotificationSettings(tenantId);
    const incSmtp = (dto.smtp ?? {}) as Record<string, unknown>;
    const incBrevo = (dto.brevo ?? {}) as Record<string, unknown>;
    const incGmail = (dto.gmail ?? {}) as Record<string, unknown>;
    const incTwilio = (dto.twilio ?? {}) as Record<string, unknown>;
    const incEsms = (dto.esms ?? {}) as Record<string, unknown>;

    // ---- Gmail credentials: guard the #1 cause of recurring "invalid_client" ----
    // A new Client ID must come with the matching new Client secret. If the admin
    // changes the Client ID but leaves the secret box blank (it shows "saved"),
    // the new ID would pair with the OLD secret → Google rejects it as
    // invalid_client. We refuse that save and tell them exactly what to do.
    const gmailClientId =
      typeof incGmail.clientId === 'string' && incGmail.clientId.trim() ? incGmail.clientId.trim() : cur.gmail.clientId;
    const gmailNewSecret = cleanSecret(incGmail.clientSecret);
    const gmailClientIdChanged = gmailClientId !== cur.gmail.clientId;
    if (gmailClientIdChanged && cur.gmail.clientId && !gmailNewSecret) {
      throw new BadRequestException(
        'Bạn vừa đổi Client ID — hãy dán lại Client secret của đúng OAuth client đó rồi Lưu. ' +
          '(You changed the Client ID — paste the matching Client secret from the same OAuth client.)',
      );
    }
    const mergedGmail = {
      clientId: gmailClientId,
      // Blank/masked secret keeps the stored one (so re-saving never wipes it);
      // a real new secret replaces it.
      clientSecret: gmailNewSecret ?? cur.gmail.clientSecret,
      // The refresh token + sender belong to the OAuth client that minted them.
      // When the Client ID changes, the old refresh token can't work with the new
      // client, so we drop it and require a fresh "Connect with Google".
      refreshToken: gmailClientIdChanged ? '' : cur.gmail.refreshToken,
      senderEmail: gmailClientIdChanged ? '' : cur.gmail.senderEmail,
    };

    // A freshly-entered Brevo key must look like a real Brevo API key (they all
    // start with "xkeysib-"). Blocks a wrong/mangled paste from being stored and
    // then failing later with Brevo 401 "Key not found".
    const newBrevoKey = cleanSecret(incBrevo.apiKey);
    if (newBrevoKey && !/^xkeysib-/i.test(newBrevoKey)) {
      throw new BadRequestException(
        'Brevo API key không đúng định dạng — key phải bắt đầu bằng "xkeysib-". ' +
          'Vào Brevo → SMTP & API → API Keys tạo key mới rồi dán lại toàn bộ. ' +
          '(Brevo API keys start with "xkeysib-"; paste the full key from SMTP & API → API Keys.)',
      );
    }

    const merged: NotificationSettings = {
      ...cur,
      ...stripUndefined(dto as Record<string, unknown>),
      smtp: {
        host: typeof incSmtp.host === 'string' && incSmtp.host ? incSmtp.host : cur.smtp.host,
        port: typeof incSmtp.port === 'number' ? incSmtp.port : cur.smtp.port,
        user: typeof incSmtp.user === 'string' ? incSmtp.user : cur.smtp.user,
        fromEmail: typeof incSmtp.fromEmail === 'string' ? incSmtp.fromEmail : cur.smtp.fromEmail,
        secure: incSmtp.secure === 'ssl' || incSmtp.secure === 'tls' || incSmtp.secure === 'none' ? incSmtp.secure : cur.smtp.secure,
        // Blank password keeps the stored one.
        // Blank OR masked (••••) password keeps the stored one — never overwrite a
        // real secret with the UI mask (the bug that silently corrupted saved keys).
        pass: cleanSecret(incSmtp.pass) ?? cur.smtp.pass,
      },
      brevo: {
        senderEmail: typeof incBrevo.senderEmail === 'string' ? incBrevo.senderEmail : cur.brevo.senderEmail,
        senderName: typeof incBrevo.senderName === 'string' ? incBrevo.senderName : cur.brevo.senderName,
        // Blank/masked API key keeps the stored one; a valid new key replaces it.
        apiKey: newBrevoKey ?? cur.brevo.apiKey,
      },
      gmail: mergedGmail,
      twilio: {
        accountSid: typeof incTwilio.accountSid === 'string' ? incTwilio.accountSid : cur.twilio.accountSid,
        fromNumber: typeof incTwilio.fromNumber === 'string' ? incTwilio.fromNumber : cur.twilio.fromNumber,
        // Blank/masked auth token keeps the stored one.
        authToken: cleanSecret(incTwilio.authToken) ?? cur.twilio.authToken,
      },
      esms: {
        apiKey: typeof incEsms.apiKey === 'string' ? incEsms.apiKey : (cur.esms?.apiKey ?? ''),
        brandname: typeof incEsms.brandname === 'string' ? incEsms.brandname : (cur.esms?.brandname ?? ''),
        oaid: typeof incEsms.oaid === 'string' ? incEsms.oaid.trim() : (cur.esms?.oaid ?? ''),
        znsBookingTempId: typeof incEsms.znsBookingTempId === 'string' ? incEsms.znsBookingTempId.trim() : (cur.esms?.znsBookingTempId ?? ''),
        znsReminderTempId: typeof incEsms.znsReminderTempId === 'string' ? incEsms.znsReminderTempId.trim() : (cur.esms?.znsReminderTempId ?? ''),
        // cleanSecret returns undefined for the UI's mask, so re-saving the
        // form without retyping the key keeps the stored one instead of
        // overwriting it with bullet characters — the bug that made Brevo
        // return "Key not found" for weeks.
        secretKey: cleanSecret(incEsms.secretKey) ?? (cur.esms?.secretKey ?? ''),
      },
    } as NotificationSettings;
    delete merged.market; // runtime-only — attached at read time, never stored
    await this.writeKey(tenantId, NOTIFICATION_SETTINGS_KEY, merged);
    // Keep the "Booking confirmed" template's Email / SMS boxes in step with
    // these switches — two places for one choice is how owners ended up
    // believing customers were texted when they were not.
    const d = dto as { emailCustomerOnBooking?: unknown; smsCustomerOnBooking?: unknown };
    if (typeof d.emailCustomerOnBooking === 'boolean' || typeof d.smsCustomerOnBooking === 'boolean') {
      const tpls = await this.readKey<NotificationTemplates>(tenantId, NOTIFICATION_TEMPLATES_KEY, {});
      const conf = { ...(tpls.customer_booking_confirmed ?? {}) } as Partial<NotifTemplate>;
      if (typeof d.emailCustomerOnBooking === 'boolean') conf.email = d.emailCustomerOnBooking;
      if (typeof d.smsCustomerOnBooking === 'boolean') conf.sms = d.smsCustomerOnBooking;
      await this.writeKey(tenantId, NOTIFICATION_TEMPLATES_KEY, { ...tpls, customer_booking_confirmed: conf } as NotificationTemplates);
    }
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.notifications_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  /** Per-event notification templates, merged over the default catalog. */
  async getNotificationTemplates(tenantId: string): Promise<NotificationTemplates> {
    const stored = await this.readKey<NotificationTemplates>(tenantId, NOTIFICATION_TEMPLATES_KEY, {});
    // Merge each default event with any stored override so newly-added events
    // always appear, and an event's defaults fill missing fields.
    const out: NotificationTemplates = {};
    for (const [id, def] of Object.entries(DEFAULT_NOTIFICATION_TEMPLATES)) {
      out[id] = { ...def, ...(stored[id] ?? {}) };
    }
    // Any market: a template field still holding an OLDER default verbatim
    // follows the current default (which names the technician). Edited text is kept.
    for (const [id, legacy] of Object.entries(LEGACY_TEMPLATE_DEFAULTS)) {
      const def = DEFAULT_NOTIFICATION_TEMPLATES[id];
      if (!def || !out[id]) continue;
      for (const [f, olds] of Object.entries(legacy)) {
        const field = f as 'subject' | 'body' | 'smsBody';
        if ((olds ?? []).includes(out[id][field])) out[id][field] = def[field];
      }
    }
    // Vietnamese catalog overlay — same rule as getNotificationSettings: only
    // fields still equal to the English default are translated, so a salon's
    // edits always win and non-VN salons are untouched.
    if ((await this.marketOf(tenantId)) === 'VN') {
      // Same default as getNotificationSettings: the confirmation goes out
      // over the shared Zalo/SMS channel unless the salon switched it off.
      const conf = out['customer_booking_confirmed'];
      const storedConf = (stored as Record<string, Partial<NotifTemplate> | undefined>)['customer_booking_confirmed'];
      if (conf && storedConf?.sms === undefined && this.sharedVnChannel().active) conf.sms = true;
      for (const [id, vn] of Object.entries(VN_TEMPLATE_TEXTS)) {
        const def = DEFAULT_NOTIFICATION_TEMPLATES[id];
        if (!def || !out[id]) continue;
        const legacy = LEGACY_TEMPLATE_DEFAULTS[id] ?? {};
        for (const [f, vnText] of Object.entries(vn)) {
          const field = f as 'subject' | 'body' | 'smsBody';
          const untouched = out[id][field] === def[field] || (legacy[field] ?? []).includes(out[id][field]);
          if (untouched) out[id][field] = vnText as string;
        }
      }
    }
    return out;
  }

  async updateNotificationTemplates(user: AuthenticatedUser, dto: { templates?: NotificationTemplates }) {
    const tenantId = this.tenantId(user);
    const cur = await this.getNotificationTemplates(tenantId);
    const incoming = dto.templates ?? {};
    const merged: NotificationTemplates = { ...cur };
    // Only persist known event ids; ignore anything unexpected.
    for (const id of Object.keys(DEFAULT_NOTIFICATION_TEMPLATES)) {
      if (incoming[id]) merged[id] = { ...cur[id], ...incoming[id] };
    }
    await this.writeKey(tenantId, NOTIFICATION_TEMPLATES_KEY, merged);
    // …and the other way: the template's boxes are the Settings switches too.
    const inc = incoming['customer_booking_confirmed'] as Partial<NotifTemplate> | undefined;
    if (inc && (typeof inc.email === 'boolean' || typeof inc.sms === 'boolean')) {
      // Only the two fields change; everything else is written back exactly as
      // stored (a failed read throws here rather than saving over the rest).
      const row = await this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: NOTIFICATION_SETTINGS_KEY } } });
      const next = { ...((row?.value as Record<string, unknown> | null) ?? {}) };
      if (typeof inc.email === 'boolean') next.emailCustomerOnBooking = inc.email;
      if (typeof inc.sms === 'boolean') next.smsCustomerOnBooking = inc.sms;
      delete next.market;
      await this.writeKey(tenantId, NOTIFICATION_SETTINGS_KEY, next);
    }
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.notification_templates_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  // ---- Gmail OAuth2 connect (Google API — like WP Mail SMTP's Google mailer) ----

  private apiBase(): string {
    return (process.env.PUBLIC_API_URL || process.env.RENDER_EXTERNAL_URL || 'https://lumio-api-uqm6.onrender.com').replace(/\/$/, '');
  }
  private webBase(): string {
    const cors = (process.env.CORS_ORIGINS || '').split(',')[0].trim();
    return (process.env.PUBLIC_WEB_URL || cors || 'https://lumiobooking.com').replace(/\/$/, '');
  }
  /** Redirect URI the salon must add to their Google OAuth client. */
  gmailRedirectUri(): string {
    return `${this.apiBase()}/api/settings/gmail/callback`;
  }
  private signState(tenantId: string): string {
    const payload = Buffer.from(JSON.stringify({ t: tenantId, exp: Date.now() + 600_000 })).toString('base64url');
    const sig = crypto.createHmac('sha256', signingSecret()).update(payload).digest('base64url');
    return `${payload}.${sig}`;
  }
  private verifyState(state: string): string | null {
    const [payload, sig] = (state || '').split('.');
    if (!payload || !sig) return null;
    const expect = crypto.createHmac('sha256', signingSecret()).update(payload).digest('base64url');
    if (sig !== expect) return null;
    try {
      const data = JSON.parse(Buffer.from(payload, 'base64url').toString()) as { t: string; exp: number };
      if (!data.exp || Date.now() > data.exp) return null;
      return data.t;
    } catch {
      return null;
    }
  }

  /** Build the Google consent URL the salon admin is sent to. */
  async gmailAuthUrl(user: AuthenticatedUser) {
    const tenantId = this.tenantId(user);
    const n = await this.getNotificationSettings(tenantId);
    if (!n.gmail.clientId || !n.gmail.clientSecret) {
      throw new BadRequestException('Enter your Google Client ID and Client secret and Save before connecting.');
    }
    const params = new URLSearchParams({
      client_id: n.gmail.clientId,
      redirect_uri: this.gmailRedirectUri(),
      response_type: 'code',
      scope: 'https://www.googleapis.com/auth/gmail.send https://www.googleapis.com/auth/userinfo.email',
      access_type: 'offline',
      prompt: 'consent',
      state: this.signState(tenantId),
    });
    return { url: `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}` };
  }

  /** Google redirects here with ?code&state. Exchange for a refresh token + email,
   *  store them, switch the salon to Gmail, then bounce back to the web settings. */
  async gmailCallback(code: string, state: string): Promise<string> {
    const web = this.webBase();
    const back = (q: string) => `${web}/salon/settings?${q}`;
    const tenantId = this.verifyState(state);
    if (!tenantId || !code) return back('gmail=error&msg=invalid_state');
    const n = await this.getNotificationSettings(tenantId);
    if (!n.gmail.clientId || !n.gmail.clientSecret) return back('gmail=error&msg=missing_client');
    try {
      const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          code,
          client_id: n.gmail.clientId,
          client_secret: n.gmail.clientSecret,
          redirect_uri: this.gmailRedirectUri(),
          grant_type: 'authorization_code',
        }).toString(),
      });
      const tokenData = (await tokenRes.json().catch(() => ({}))) as { refresh_token?: string; access_token?: string; error?: string };
      if (!tokenRes.ok || !tokenData.refresh_token) {
        // Surface Google's real reason (e.g. invalid_client = wrong secret) instead
        // of a generic message, so the salon knows exactly what to fix.
        const why = tokenData.error ? tokenData.error : 'no_refresh_token';
        return back(`gmail=error&msg=${encodeURIComponent(why)}`);
      }
      let senderEmail = n.gmail.senderEmail;
      if (tokenData.access_token) {
        const ui = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
          headers: { authorization: `Bearer ${tokenData.access_token}` },
        });
        const uiData = (await ui.json().catch(() => ({}))) as { email?: string };
        if (uiData.email) senderEmail = uiData.email;
      }
      await this.writeKey(tenantId, NOTIFICATION_SETTINGS_KEY, {
        ...n,
        mailService: 'gmail',
        senderEmail: n.senderEmail || senderEmail,
        gmail: { ...n.gmail, refreshToken: tokenData.refresh_token, senderEmail },
      });
      await this.audit.log({ tenantId, userId: null, action: 'settings.gmail_connected', resourceType: 'tenant', resourceId: tenantId });
      return back('gmail=connected');
    } catch {
      return back('gmail=error&msg=exchange_failed');
    }
  }

  /**
   * Sends a real test email using the saved SMTP credentials, to the admin email
   * (or the SMTP user). Returns the exact error message so the admin can fix it.
   */
  /**
   * Sends a real test SMS using the salon's own Twilio creds (or the platform
   * default if the salon hasn't entered its own). Diagnostics for the SMS setup.
   */
  async sendTestSms(user: AuthenticatedUser, to?: string) {
    const tenantId = this.tenantId(user);
    const n = await this.getNotificationSettings(tenantId);
    const target = (to || '').trim() || n.adminPhone || '';
    if (!target) return { ok: false, error: 'Enter a phone number to send the test to (or set an Admin phone first).' };
    const t = n.twilio;
    const hasTenant = !!(t.accountSid && t.authToken && t.fromNumber);
    const hasEnv = !!(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && (process.env.TWILIO_MESSAGING_SERVICE_SID || process.env.TWILIO_FROM_NUMBER));
    if (!hasTenant && !hasEnv) {
      return { ok: false, error: 'Enter your Twilio Account SID, Auth token and From number, then Save before testing.' };
    }
    const tenant = await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { name: true, market: true } as never }) as { name?: string; market?: string | null } | null;
    // The test must go out the way the real messages will — for an Australian
    // salon that is its +61 number, never the platform's US one.
    let provider = hasTenant
      ? new TwilioSmsProvider({ accountSid: t.accountSid, authToken: t.authToken, fromNumber: t.fromNumber })
      : createSmsProvider();
    if (!hasTenant) {
      const market = String(tenant?.market ?? 'US').toUpperCase();
      if (market === 'AU') {
        const line = await (this.prisma as unknown as { voiceLine?: { findUnique: (a: unknown) => Promise<{ lumioNumber?: string | null } | null> } })
          .voiceLine?.findUnique({ where: { tenantId }, select: { lumioNumber: true } }).catch(() => null);
        const sender = twilioSenderFor({ market, lineNumber: line?.lumioNumber ?? null, auFallback: process.env.TWILIO_FROM_NUMBER_AU ?? null });
        if (sender.kind === 'refuse') return { ok: false, error: sender.error };
        if (sender.kind === 'from') {
          provider = new TwilioSmsProvider({ accountSid: String(process.env.TWILIO_ACCOUNT_SID), authToken: String(process.env.TWILIO_AUTH_TOKEN), fromNumber: sender.from });
        }
      }
    }
    const salon = n.senderName || tenant?.name || 'Lumio Booking';
    // A local number ("0412 345 678") means the salon's own country, the same
    // way the real booking texts read it — not the US.
    const tz = await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }).catch(() => null);
    const defaultDialCode = dialCodeFor(tenant?.market ?? null, tz?.timezone ?? null);
    const res = await provider.sendSms({ to: target, defaultDialCode, body: `[TEST] ${salon}: your SMS is working. Reply STOP to opt out.` });
    return res.success ? { ok: true } : { ok: false, error: res.error || 'Send failed' };
  }

  async sendTestEmail(user: AuthenticatedUser) {
    const tenantId = this.tenantId(user);
    const n = await this.getNotificationSettings(tenantId);

    const reply = n.replyTo || undefined;
    const senderName = n.senderName || 'Lumio Booking';
    const brevoReady = !!(n.brevo.apiKey && n.senderEmail);
    const smtpReady = !!(n.smtp.user && n.smtp.pass);
    const gmailReady = !!(n.gmail.clientId && n.gmail.clientSecret && n.gmail.refreshToken && n.gmail.senderEmail);
    const envBrevoKey = process.env.BREVO_API_KEY;
    const envBrevoSender = process.env.BREVO_SENDER_EMAIL;
    const mkBrevo = (apiKey: string, senderEmail: string) =>
      new BrevoEmailProvider({ apiKey, senderEmail, senderName, replyTo: reply });
    const mkGmail = () =>
      new GmailOAuthProvider({
        clientId: n.gmail.clientId, clientSecret: n.gmail.clientSecret, refreshToken: n.gmail.refreshToken,
        senderEmail: n.gmail.senderEmail, senderName, replyTo: reply,
      });
    const mkSmtp = () =>
      new SmtpEmailProvider({
        host: n.smtp.host, port: n.smtp.port, user: n.smtp.user, pass: n.smtp.pass, secure: n.smtp.secure, replyTo: reply,
        from: `${senderName} <${n.senderEmail || n.smtp.user}>`,
      });

    // The salon's explicit Mail service choice wins; otherwise auto-detect.
    let provider: SmtpEmailProvider | BrevoEmailProvider | GmailOAuthProvider;
    let to: string;
    if (n.mailService === 'off') {
      return { ok: false, error: 'Email sending is set to Off. Choose SMTP or Brevo as the Mail service, then Save before testing.' };
    } else if (n.mailService === 'brevo') {
      if (!n.brevo.apiKey) return { ok: false, error: 'Brevo is selected but the API key is missing.' };
      if (!n.senderEmail) return { ok: false, error: 'Please set a Sender email (it must be verified in Brevo).' };
      provider = mkBrevo(n.brevo.apiKey, n.senderEmail);
      to = n.adminEmail || n.senderEmail;
    } else if (n.mailService === 'smtp') {
      if (!smtpReady) return { ok: false, error: 'SMTP is selected but missing the username or password.' };
      provider = mkSmtp();
      to = n.adminEmail || n.senderEmail || n.smtp.user;
    } else if (n.mailService === 'gmail') {
      if (!gmailReady) return { ok: false, error: 'Gmail is selected but not connected yet. Enter Client ID/secret, Save, then click “Connect with Google”.' };
      provider = mkGmail();
      to = n.adminEmail || n.senderEmail || n.gmail.senderEmail;
    } else if (gmailReady) {
      provider = mkGmail();
      to = n.adminEmail || n.senderEmail || n.gmail.senderEmail;
    } else if (brevoReady) {
      provider = mkBrevo(n.brevo.apiKey, n.senderEmail);
      to = n.adminEmail || n.senderEmail;
    } else if (smtpReady) {
      provider = mkSmtp();
      to = n.adminEmail || n.senderEmail || n.smtp.user;
    } else if (process.env.GMAIL_CLIENT_ID && process.env.GMAIL_CLIENT_SECRET && process.env.GMAIL_REFRESH_TOKEN && process.env.GMAIL_SENDER_EMAIL) {
      // Platform Gmail (OAuth2) — same mechanism as WP Mail SMTP's Google mailer.
      provider = new GmailOAuthProvider({
        clientId: process.env.GMAIL_CLIENT_ID,
        clientSecret: process.env.GMAIL_CLIENT_SECRET,
        refreshToken: process.env.GMAIL_REFRESH_TOKEN,
        senderEmail: process.env.GMAIL_SENDER_EMAIL,
        senderName,
        replyTo: reply,
      });
      to = n.adminEmail || n.senderEmail || process.env.GMAIL_SENDER_EMAIL;
    } else if (envBrevoKey && envBrevoSender) {
      provider = mkBrevo(envBrevoKey, envBrevoSender);
      to = n.adminEmail || envBrevoSender;
    } else {
      return { ok: false, error: 'No email provider configured. Pick a Mail service (SMTP or Brevo) and fill its fields, then Save before testing.' };
    }
    const sendPromise = provider.sendEmail({
      to,
      subject: 'Lumio Booking — test email',
      body: 'This is a test email from your Lumio Booking notification settings. If you received it, email sending works.',
      html: '<p>This is a <strong>test email</strong> from your Lumio Booking notification settings.</p><p>If you received it, your email sending is working correctly. ✅</p>',
    });
    // Hard ceiling so the request can never hang the UI, even if the network stalls.
    const timeout = new Promise<{ success: boolean; error?: string }>((resolve) =>
      setTimeout(
        () => resolve({ success: false, error: 'Timed out after 22s: the mail server did not respond. The host may be blocking outbound SMTP, or Gmail is refusing the connection from the cloud server.' }),
        22000,
      ),
    );
    const result = await Promise.race([sendPromise, timeout]);
    if (result.success) return { ok: true, to };
    let error = result.error || 'Send failed';
    // Brevo rejected the API key — the stored key is wrong or was regenerated.
    if (/brevo/i.test(error) && /(401|unauthorized|key not found|invalid[_ ]?key)/i.test(error)) {
      error =
        'Brevo từ chối API key (Key not found/unauthorized): key đã lưu không còn đúng hoặc đã bị tạo lại trên Brevo. ' +
        'Vào Brevo → SMTP & API → API Keys tạo key MỚI (bắt đầu bằng "xkeysib-"), dán vào ô “Brevo API key”, bấm Lưu rồi thử lại. ' +
        '(The saved Brevo key is invalid or was regenerated — create a fresh key, paste it, Save, then retest.)';
    }
    // Translate Google's cryptic OAuth errors into a clear next step.
    if (/invalid_client/i.test(error)) {
      error =
        'Google từ chối: Client ID và Client secret không khớp (invalid_client). ' +
        'Vào Google Cloud → Credentials lấy Client secret MỚI của đúng client, dán CẢ Client ID + Secret vào đây, bấm Lưu, rồi bấm “Reconnect with Google”. ' +
        '(Client ID and secret don’t match — paste a fresh matching pair, save, then reconnect.)';
    } else if (/invalid_grant/i.test(error)) {
      error =
        'Kết nối Google đã hết hạn/bị thu hồi (invalid_grant) — thường do OAuth consent screen còn ở chế độ Testing (token hết hạn sau 7 ngày). ' +
        'Trên Google bấm Publish app, rồi quay lại bấm “Reconnect with Google”. ' +
        '(Refresh token expired/revoked — publish the app, then reconnect.)';
    }
    return { ok: false, error };
  }

  /** Gateway view for the frontend — NEVER includes the secret value. */
  private sanitizeGateways(raw: PaymentGateways) {
    const out: Record<string, { enabled: boolean; connected: boolean; apiKey: string }> = {};
    for (const id of GATEWAY_IDS) {
      const g = raw[id];
      out[id] = { enabled: g.enabled, connected: false, apiKey: '' };
    }
    return out;
  }

  /** Company extra fields (address, website), merged over defaults. Used by the public SEO payload. */
  async getCompanyExtra(tenantId: string): Promise<CompanyExtra> {
    return this.readKey<CompanyExtra>(tenantId, COMPANY_EXTRA_KEY, DEFAULT_COMPANY_EXTRA);
  }

  async get(user: AuthenticatedUser) {
    const tenantId = this.tenantId(user);
    const tenant = await this.prisma.tenant.findUnique({
      where: { id: tenantId },
      select: { name: true, slug: true, contactEmail: true, contactPhone: true, timezone: true, branding: true, market: true },
    });
    if (!tenant) throw new NotFoundException('Tenant not found');
    // Nineteen independent reads, issued TOGETHER. They ran one after
    // another — nineteen round trips to Neon in series on every open of
    // any settings screen, and sixteen salon pages open this — so one
    // request took as long as the slowest twenty queries stacked end to end.
    const [
      extra, booking, gateways, notifications, notificationTemplates, pos, loyalty, review,
      weekdayDiscounts, googleReviewLink, firstVisitDiscount, groupDiscount, dateDiscounts, reminders, deposit,
      analytics, businessProfile, rebooking, receipt, staffPrivacy,
    ] = await Promise.all([
      this.readKey<CompanyExtra>(tenantId, COMPANY_EXTRA_KEY, DEFAULT_COMPANY_EXTRA),
      this.getBookingRules(tenantId),
      this.getGateways(tenantId),
      this.getNotificationSettings(tenantId),
      this.getNotificationTemplates(tenantId),
      this.posWithTillButtons(tenantId, tenant.market),
      this.getLoyaltySettings(tenantId),
      this.getReviewSettings(tenantId),
      this.getWeekdayDiscounts(tenantId),
      this.googleProfileReviewLink(tenantId),
      this.getFirstVisitDiscount(tenantId),
      this.getGroupDiscount(tenantId),
      this.getDateDiscounts(tenantId),
      this.getReminderSettings(tenantId),
      this.getDepositSettings(tenantId),
      this.getAnalyticsSettings(tenantId),
      this.getBusinessProfile(tenantId),
      this.getRebookingSettings(tenantId),
      this.getReceiptDesign(tenantId),
      this.getStaffPrivacy(tenantId),
    ]);
    return {
      // The salon's real market, straight from the tenant row.
      //
      // It is served here because the screen had no other way to ask. Every
      // market decision on the settings page was being made from
      // `company.country` — the dropdown an owner uses to set their currency
      // format — while SMS routing, feature policy and money all read
      // `tenant.market`. The two are synced when a salon is created and never
      // again, so a shop moved to Vietnam by support had its messages switched
      // to the Vietnamese carrier while the screen that configures that carrier
      // stayed hidden; and a US shop whose owner idly picked "Việt Nam" in the
      // country dropdown was shown the whole Vietnamese setup, which then did
      // nothing. One answer, from the side that owns it.
      market: tenant.market ?? 'US',
      company: {
        name: tenant.name,
        slug: tenant.slug,
        contactEmail: tenant.contactEmail,
        contactPhone: tenant.contactPhone,
        timezone: tenant.timezone,
        address: extra.address,
        website: extra.website,
        country: extra.country ?? '',
      },
      booking,
      branding: this.brandingFrom(tenant.branding),
      gateways: this.sanitizeGateways(gateways),
      notifications: this.sanitizeNotifications(notifications),
      notificationTemplates,
      // The till's buttons are RESOLVED here rather than in the page: the rule
      // (salon's own choice, else the market's default) lives in one place, and
      // the POS screen just renders what it is handed. `paymentMethods` stays on
      // the object as the salon's raw choice — empty means "follow the market".
      pos,
      loyalty,
      // `googleAuto`: the review link the connected Business Profile supplies, so
      // the screen can say "taken from your Google connection" instead of
      // asking for a Place ID the salon already gave Google.
      review: { ...review, googleAuto: googleReviewLink },
      weekdayDiscounts,
      firstVisitDiscount,
      groupDiscount,
      dateDiscounts,
      reminders,
      deposit,
      staffPrivacy,
      analytics,
      businessProfile,
      rebooking,
      receipt,
      gmailRedirectUri: this.gmailRedirectUri(),
    };
  }

  /**
   * THE DESK'S VIEW OF SETTINGS.
   *
   * The till, the calendar, the walk-in board and the bookings list all read
   * `/settings` for the currency, the timezone, the tax rate, the loyalty
   * rule and the salon's name — and `/settings` was owner-only, so every one
   * of those screens failed for a receptionist with "Insufficient role". A
   * staff account gets exactly the keys those screens read, and none of the
   * owner's: no gateways, no SMS and mail credentials, no reminder templates,
   * no analytics ids, no deposit policy, no Gmail redirect.
   */
  async getForDesk(user: AuthenticatedUser) {
    const full = await this.get(user) as Record<string, unknown>;
    const pick = (keys: string[]) => Object.fromEntries(keys.filter((k) => k in full).map((k) => [k, full[k]]));
    return pick(['company', 'booking', 'pos', 'loyalty', 'branding', 'receipt', 'review', 'weekdayDiscounts', 'dateDiscounts', 'firstVisitDiscount', 'groupDiscount']);
  }

  async getFirstVisitDiscount(tenantId: string): Promise<FirstVisitDiscount> {
    const v = await this.readKey<FirstVisitDiscount>(tenantId, FIRST_VISIT_DISCOUNT_KEY, DEFAULT_FIRST_VISIT_DISCOUNT);
    // Normalize: settings saved before visit-tiers existed become a visit-1 rule.
    const rules = Array.isArray(v.rules) && v.rules.length
      ? v.rules
      : (v.percent > 0 ? [{ visit: 1, percent: v.percent }] : []);
    return { ...v, rules };
  }

  async updateFirstVisitDiscount(
    user: AuthenticatedUser,
    dto: { enabled?: boolean; percent?: number; message?: string; rules?: Array<{ visit?: number; percent?: number }>; startDate?: string | null; endDate?: string | null; appliesTo?: string },
  ) {
    const tenantId = this.tenantId(user);
    const cur = await this.getFirstVisitDiscount(tenantId);
    // Sanitize tiers: visit 1-100, 1-90 %, unique visit numbers, max 10, sorted.
    const rules = Array.isArray(dto.rules)
      ? [...new Map(
          dto.rules
            .map((r) => ({
              visit: Math.min(100, Math.max(1, Math.round(Number(r?.visit) || 0))),
              percent: Math.min(90, Math.max(1, Math.round(Number(r?.percent) || 0))),
            }))
            .filter((r) => r.visit >= 1 && r.percent >= 1)
            .map((r) => [r.visit, r] as const),
        ).values()].sort((a, b) => a.visit - b.visit).slice(0, 10)
      : (cur.rules ?? []);
    const next: FirstVisitDiscount = {
      enabled: typeof dto.enabled === 'boolean' ? dto.enabled : cur.enabled,
      // Legacy field mirrors the visit-1 tier so older readers keep working.
      percent: rules.find((r) => r.visit === 1)?.percent
        ?? (typeof dto.percent === 'number' ? Math.min(90, Math.max(1, Math.round(dto.percent))) : cur.percent),
      message: typeof dto.message === 'string' ? dto.message.slice(0, 160) : cur.message,
      rules,
      ...cleanPromoWindow(dto, cur),
      appliesTo: cleanChannel(dto.appliesTo, channelOf(cur)),
    };
    await this.writeKey(tenantId, FIRST_VISIT_DISCOUNT_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.first_visit_discount_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  async getGroupDiscount(tenantId: string): Promise<GroupDiscount> {
    return this.readKey<GroupDiscount>(tenantId, GROUP_DISCOUNT_KEY, DEFAULT_GROUP_DISCOUNT);
  }

  async updateGroupDiscount(user: AuthenticatedUser, dto: { enabled?: boolean; message?: string; tiers?: Array<{ minSize?: number; percent?: number }>; startDate?: string | null; endDate?: string | null; appliesTo?: string }) {
    const tenantId = this.tenantId(user);
    const cur = await this.getGroupDiscount(tenantId);
    // Sanitize tiers: 2-20 people, 1-90 %, max 5 tiers, sorted by size.
    const tiers = Array.isArray(dto.tiers)
      ? dto.tiers
          .map((t) => ({
            minSize: Math.min(20, Math.max(2, Math.round(Number(t?.minSize) || 0))),
            percent: Math.min(90, Math.max(1, Math.round(Number(t?.percent) || 0))),
          }))
          .filter((t) => t.minSize >= 2 && t.percent >= 1)
          .slice(0, 5)
          .sort((a, b) => a.minSize - b.minSize)
      : cur.tiers;
    const next: GroupDiscount = {
      enabled: typeof dto.enabled === 'boolean' ? dto.enabled : cur.enabled,
      message: typeof dto.message === 'string' ? dto.message.slice(0, 160) : cur.message,
      tiers,
      ...cleanPromoWindow(dto, cur),
      appliesTo: cleanChannel(dto.appliesTo, channelOf(cur)),
    };
    await this.writeKey(tenantId, GROUP_DISCOUNT_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.group_discount_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  /** A live payment-hub connection that can take (and refund) a card online. */
  async hasOnlineProvider(tenantId: string): Promise<boolean> {
    if (!hubEnabled()) return false;
    const n = await (this.prisma as unknown as { paymentConnection?: { count: (a: unknown) => Promise<number> } }).paymentConnection
      ?.count({ where: { tenantId, status: 'ACTIVE', provider: { in: [...ONLINE_PROVIDERS] } } })
      .catch(() => 0) ?? 0;
    return n > 0;
  }

  async getDepositSettings(tenantId: string): Promise<DepositSettings> {
    return this.readKey<DepositSettings>(tenantId, DEPOSIT_SETTINGS_KEY, DEFAULT_DEPOSIT_SETTINGS);
  }

  async updateDepositSettings(user: AuthenticatedUser, dto: Partial<DepositSettings>) {
    const tenantId = this.tenantId(user);
    const cur = await this.getDepositSettings(tenantId);
    const num = (v: unknown, d: number) => (typeof v === 'number' && v >= 0 ? Math.round(v) : d);
    const next: DepositSettings = {
      enabled: typeof dto.enabled === 'boolean' ? dto.enabled : cur.enabled,
      type: dto.type === 'fixed' || dto.type === 'percent' ? dto.type : (cur.type ?? 'percent'),
      percent: Math.min(100, Math.max(1, num(dto.percent, cur.percent ?? 30))),
      fixedCents: num(dto.fixedCents, cur.fixedCents ?? 1000),
      scope: dto.scope === 'new' || dto.scope === 'repeat_noshow' || dto.scope === 'all' ? dto.scope : (cur.scope ?? 'all'),
      noShowThreshold: Math.max(1, num(dto.noShowThreshold, cur.noShowThreshold ?? 2)),
      refundHours: Math.min(168, num(dto.refundHours, cur.refundHours ?? 24)),
      holdMinutes: dto.holdMinutes === undefined ? holdMinutesOf(cur) : holdMinutesOf({ holdMinutes: dto.holdMinutes }),
      provider: dto.provider === null || dto.provider === '' ? null
        : isOnlineProvider(dto.provider) ? dto.provider : (cur.provider ?? null),
    };
    await this.writeKey(tenantId, DEPOSIT_SETTINGS_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.deposit_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  /** How a technician's app shows client phones / emails (common/contact-privacy.ts). Default: last 4 digits. */
  async getStaffPrivacy(tenantId: string): Promise<{ contact: ContactMode }> {
    const row = await this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: STAFF_PRIVACY_KEY } } }).catch(() => null);
    return { contact: contactModeOf(row?.value ?? null) };
  }

  async updateStaffPrivacy(user: AuthenticatedUser, dto: { contact?: unknown }) {
    const tenantId = this.tenantId(user);
    const contact = contactModeOf({ contact: dto.contact });
    if (dto.contact !== contact) throw new BadRequestException('contact must be hidden, last4 or full');
    await this.writeKey(tenantId, STAFF_PRIVACY_KEY, { contact });
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.staff_privacy_updated', resourceType: 'tenant', resourceId: tenantId, metadata: { contact } });
    return this.get(user);
  }

  /** Per-guest deposit for big parties (payments/party-deposit.ts). Off by default. */
  async getPartyDeposit(tenantId: string): Promise<PartyDeposit> {
    try {
      const row = await this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: PARTY_DEPOSIT_KEY } } });
      return cleanPartyDeposit(row?.value ?? {});
    } catch { return cleanPartyDeposit({}); }
  }

  getPartyDepositFor(user: AuthenticatedUser) {
    return this.getPartyDeposit(this.tenantId(user));
  }

  async updatePartyDeposit(user: AuthenticatedUser, dto: Partial<PartyDeposit>) {
    const tenantId = this.tenantId(user);
    const next = cleanPartyDeposit(dto, await this.getPartyDeposit(tenantId));
    await this.writeKey(tenantId, PARTY_DEPOSIT_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.party_deposit_updated', resourceType: 'tenant', resourceId: tenantId, metadata: { ...next } });
    return next;
  }

  async getReminderSettings(tenantId: string): Promise<ReminderSettings> {
    return this.readKey<ReminderSettings>(tenantId, REMINDER_SETTINGS_KEY, DEFAULT_REMINDER_SETTINGS);
  }

  async updateReminderSettings(user: AuthenticatedUser, dto: { enabled?: boolean; hoursBefore1?: number; hoursBefore2?: number; channelEmail?: boolean; channelSms?: boolean }) {
    const tenantId = this.tenantId(user);
    const cur = await this.getReminderSettings(tenantId);
    // Quarter hours: 72 = 3 days before, 0.5 = 30 minutes before.
    const clampH = (v: unknown, d: number) => (typeof v === 'number' && v >= 0 && v <= 168 ? Math.round(v * 4) / 4 : d);
    const next: ReminderSettings = {
      enabled: typeof dto.enabled === 'boolean' ? dto.enabled : cur.enabled,
      hoursBefore1: clampH(dto.hoursBefore1, cur.hoursBefore1 ?? 24),
      hoursBefore2: clampH(dto.hoursBefore2, cur.hoursBefore2 ?? 3),
      channelEmail: typeof dto.channelEmail === 'boolean' ? dto.channelEmail : (cur.channelEmail ?? true),
      channelSms: typeof dto.channelSms === 'boolean' ? dto.channelSms : (cur.channelSms ?? true),
    };
    await this.writeKey(tenantId, REMINDER_SETTINGS_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.reminders_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  async getWeekdayDiscounts(tenantId: string): Promise<WeekdayDiscounts> {
    return this.readKey<WeekdayDiscounts>(tenantId, WEEKDAY_DISCOUNTS_KEY, DEFAULT_WEEKDAY_DISCOUNTS);
  }

  async updateWeekdayDiscounts(user: AuthenticatedUser, dto: { enabled?: boolean; message?: string; rules?: WeekdayDiscountRule[]; startDate?: string | null; endDate?: string | null; appliesTo?: string }) {
    const tenantId = this.tenantId(user);
    const cur = await this.getWeekdayDiscounts(tenantId);
    const rules = Array.isArray(dto.rules)
      ? dto.rules
          .filter((r) => typeof r?.day === 'number' && r.day >= 0 && r.day <= 6 && typeof r.percent === 'number' && r.percent > 0)
          .map((r) => ({ day: Math.round(r.day), categoryId: r.categoryId || null, percent: Math.min(90, Math.max(1, Math.round(r.percent))) }))
          .slice(0, 100)
      : cur.rules;
    const next: WeekdayDiscounts = {
      enabled: typeof dto.enabled === 'boolean' ? dto.enabled : cur.enabled,
      message: typeof dto.message === 'string' ? dto.message.slice(0, 160) : cur.message,
      rules,
      ...cleanPromoWindow(dto, cur),
      appliesTo: cleanChannel(dto.appliesTo, channelOf(cur)),
    };
    await this.writeKey(tenantId, WEEKDAY_DISCOUNTS_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.weekday_discounts_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  async getDateDiscounts(tenantId: string): Promise<DateDiscounts> {
    return this.readKey<DateDiscounts>(tenantId, DATE_DISCOUNTS_KEY, DEFAULT_DATE_DISCOUNTS);
  }

  async updateDateDiscounts(user: AuthenticatedUser, dto: { enabled?: boolean; rules?: DateDiscountRule[] }) {
    const tenantId = this.tenantId(user);
    const cur = await this.getDateDiscounts(tenantId);
    const isDate = (s: unknown): s is string => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s);
    const rules: DateDiscountRule[] = Array.isArray(dto.rules)
      ? dto.rules
          .filter((r) => isDate(r?.startDate) && typeof r?.percent === 'number' && r.percent > 0)
          .map((r) => {
            const end = isDate(r.endDate) && (r.endDate as string) >= r.startDate ? (r.endDate as string) : null;
            return {
              startDate: r.startDate,
              endDate: end,
              categoryId: r.categoryId || null,
              percent: Math.min(90, Math.max(1, Math.round(r.percent))),
              label: typeof r.label === 'string' && r.label.trim() ? r.label.trim().slice(0, 60) : undefined,
              // Online only / walk-ins only / the whole salon (missing = the whole salon).
              appliesTo: cleanChannel((r as { appliesTo?: unknown }).appliesTo),
            };
          })
          .slice(0, 100)
      : cur.rules;
    const next: DateDiscounts = {
      enabled: typeof dto.enabled === 'boolean' ? dto.enabled : cur.enabled,
      rules,
    };
    await this.writeKey(tenantId, DATE_DISCOUNTS_KEY, next);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.date_discounts_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  /**
   * Update payments: currency + on-site method (in booking rules) and the online
   * gateways. A blank secret keeps the existing one (so the admin doesn't have to
   * re-type it). onlinePaymentEnabled is derived = any gateway enabled & connected.
   */
  async updatePayments(user: AuthenticatedUser, dto: UpdatePaymentsDto) {
    const tenantId = this.tenantId(user);
    const current = await this.getGateways(tenantId);
    const incoming = (dto.gateways ?? {}) as Record<string, Partial<GatewayConfig>>;

    // Only which brands are on; any key sent is dropped (legacy-gateways.ts).
    const merged = brandsOnly(Object.fromEntries(GATEWAY_IDS.map((id) => {
      const inc = incoming[id] ?? {};
      return [id, { enabled: typeof inc.enabled === 'boolean' ? inc.enabled : current[id].enabled }];
    })));
    await this.writeKey(tenantId, PAYMENT_GATEWAYS_KEY, merged);

    // "Pay online" is real only with a live payment-hub connection.
    const onlineEnabled = await this.hasOnlineProvider(tenantId);

    const rules = await this.getBookingRules(tenantId);
    await this.writeKey(tenantId, BOOKING_RULES_KEY, {
      ...rules,
      currency: dto.currency ?? rules.currency,
      currencySymbol: dto.currencySymbol ?? rules.currencySymbol,
      symbolPosition: dto.symbolPosition ?? rules.symbolPosition,
      priceDecimals: typeof dto.priceDecimals === 'number' ? dto.priceDecimals : rules.priceDecimals,
      defaultPaymentMethod: dto.defaultPaymentMethod ?? rules.defaultPaymentMethod,
      payLaterEnabled: typeof dto.onSiteEnabled === 'boolean' ? dto.onSiteEnabled : rules.payLaterEnabled,
      onlinePaymentEnabled: onlineEnabled,
    });

    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.payments_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  async updateCompany(user: AuthenticatedUser, dto: UpdateCompanyDto) {
    const tenantId = this.tenantId(user);
    await this.prisma.tenant.update({
      where: { id: tenantId },
      data: {
        name: dto.name,
        contactEmail: dto.contactEmail,
        contactPhone: dto.contactPhone,
        timezone: dto.timezone,
      },
    });
    if (dto.address !== undefined || dto.website !== undefined || dto.country !== undefined) {
      const current = await this.readKey<CompanyExtra>(tenantId, COMPANY_EXTRA_KEY, DEFAULT_COMPANY_EXTRA);
      await this.writeKey(tenantId, COMPANY_EXTRA_KEY, {
        address: dto.address ?? current.address,
        website: dto.website ?? current.website,
        country: (dto.country ?? current.country ?? '').trim().toUpperCase(),
      });
    }
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.company_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  async updateBooking(user: AuthenticatedUser, dto: UpdateBookingRulesDto) {
    const tenantId = this.tenantId(user);
    const current = await this.getBookingRules(tenantId);
    const merged: BookingRules = {
      ...current,
      ...stripUndefined(dto as Record<string, unknown>),
      businessHours: dto.businessHours ? normalizeHours(dto.businessHours) : current.businessHours,
      daysOff: dto.daysOff ?? current.daysOff,
    } as BookingRules;
    await this.writeKey(tenantId, BOOKING_RULES_KEY, merged);
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.booking_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }

  async updateBranding(user: AuthenticatedUser, dto: UpdateBrandingDto) {
    const tenantId = this.tenantId(user);
    const tenant = await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { branding: true } });
    const merged: Branding = { ...this.brandingFrom(tenant?.branding), ...stripUndefined(dto as Record<string, unknown>) };
    await this.prisma.tenant.update({
      where: { id: tenantId },
      data: { branding: merged as unknown as Prisma.InputJsonValue },
    });
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.branding_updated', resourceType: 'tenant', resourceId: tenantId });
    return this.get(user);
  }
}

/** Ensures a valid 7-entry business-hours array. */
function normalizeHours(input: unknown): DayHours[] {
  const arr = Array.isArray(input) ? input : [];
  // Parse a minute-of-day; -1 signals invalid/missing.
  const pm = (v: unknown): number => { const n = Math.round(Number(v)); return Number.isFinite(n) ? Math.max(0, Math.min(1440, n)) : -1; };
  const out: DayHours[] = [];
  for (let i = 0; i < 7; i++) {
    const d = (arr[i] ?? {}) as Partial<DayHours>;
    const closed = Boolean(d.closed);
    let intervals: { open: number; close: number }[] | undefined;
    if (Array.isArray(d.intervals)) {
      intervals = (d.intervals as unknown[])
        .map((iv) => ({ open: pm((iv as { open?: unknown })?.open), close: pm((iv as { close?: unknown })?.close) }))
        .filter((iv) => iv.open >= 0 && iv.close > iv.open)
        .sort((a, b) => a.open - b.open)
        .slice(0, 6);
      if (!intervals.length) intervals = undefined;
    }
    if (intervals && intervals.length) {
      // Keep the span in openMinutes/closeMinutes so any single-window reader still works.
      out.push({ closed, openMinutes: Math.min(...intervals.map((x) => x.open)), closeMinutes: Math.max(...intervals.map((x) => x.close)), intervals });
    } else {
      const om = pm(d.openMinutes), cm = pm(d.closeMinutes);
      out.push({ closed, openMinutes: om >= 0 ? om : 540, closeMinutes: cm >= 0 ? cm : 1080 });
    }
  }
  return out;
}

function stripUndefined<T extends Record<string, unknown>>(obj: T): Partial<T> {
  const out: Partial<T> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined && k !== 'businessHours' && k !== 'daysOff') (out as Record<string, unknown>)[k] = v;
  }
  return out;
}
