<?php
/**
 * Plugin Name:       Lumio Booking
 * Plugin URI:        https://lumiobooking.com
 * Description:        Embed your salon booking form on WordPress and manage bookings (dashboard, calendar) inside wp-admin. Set the URL + slug under Lumio Booking, then add the [lumio_booking] shortcode to a page.
 * Version:           0.4.3
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Lumio
 * License:           GPL-2.0-or-later
 */
if (!defined('ABSPATH')) { exit; }

if (!function_exists('lumio_booking_base')) {

    if (!defined('LUMIO_OPT_URL'))  { define('LUMIO_OPT_URL', 'lumio_booking_site_url'); }
    if (!defined('LUMIO_OPT_SLUG')) { define('LUMIO_OPT_SLUG', 'lumio_booking_slug'); }

    function lumio_booking_base() {
        $u = get_option(LUMIO_OPT_URL, '');
        return $u ? rtrim($u, '/') : 'https://lumiobooking.com';
    }

    add_action('admin_menu', 'lumio_booking_menu');
    function lumio_booking_menu() {
        add_menu_page('Lumio Booking', 'Lumio Booking', 'manage_options', 'lumio-booking', 'lumio_booking_dash', 'dashicons-calendar-alt', 26);
        add_submenu_page('lumio-booking', 'Dashboard', 'Dashboard', 'manage_options', 'lumio-booking', 'lumio_booking_dash');
        add_submenu_page('lumio-booking', 'Calendar', 'Calendar', 'manage_options', 'lumio-booking-cal', 'lumio_booking_cal');
        add_submenu_page('lumio-booking', 'Bookings', 'Bookings', 'manage_options', 'lumio-booking-list', 'lumio_booking_list');
        add_submenu_page('lumio-booking', 'Settings', 'Settings', 'manage_options', 'lumio-booking-set', 'lumio_booking_settings');
    }

    function lumio_booking_frame($path, $title) {
        if (!current_user_can('manage_options')) { return; }
        $src = esc_url(lumio_booking_base() . $path);
        echo '<div class="wrap"><h1>' . esc_html($title) . '</h1>';
        echo '<p style="color:#646970">If prompted, sign in with your Lumio salon admin account.</p>';
        echo '<iframe src="' . $src . '" allow="payment" style="width:100%;height:calc(100vh - 170px);min-height:600px;border:1px solid #c3c4c7;border-radius:10px;background:#0b1120"></iframe></div>';
    }
    function lumio_booking_dash() { lumio_booking_frame('/salon', 'Lumio Dashboard'); }
    function lumio_booking_cal()  { lumio_booking_frame('/salon/calendar', 'Calendar'); }
    function lumio_booking_list() { lumio_booking_frame('/salon/bookings', 'Bookings'); }

    add_action('admin_init', 'lumio_booking_reg');
    function lumio_booking_reg() {
        register_setting('lumio_booking_set', LUMIO_OPT_URL, array('type' => 'string', 'sanitize_callback' => 'esc_url_raw', 'default' => ''));
        register_setting('lumio_booking_set', LUMIO_OPT_SLUG, array('type' => 'string', 'sanitize_callback' => 'sanitize_title', 'default' => ''));
    }

    function lumio_booking_settings() {
        if (!current_user_can('manage_options')) { return; }
        $url = get_option(LUMIO_OPT_URL, '');
        $slug = get_option(LUMIO_OPT_SLUG, '');
        echo '<div class="wrap"><h1>Lumio Booking - Settings</h1>';
        echo '<form method="post" action="options.php">';
        settings_fields('lumio_booking_set');
        echo '<table class="form-table">';
        echo '<tr><th><label for="lu_url">Booking site URL</label></th><td>';
        echo '<input name="' . esc_attr(LUMIO_OPT_URL) . '" id="lu_url" type="url" class="regular-text" value="' . esc_attr($url) . '" placeholder="https://lumiobooking.com" />';
        echo '<p class="description">Leave blank to use https://lumiobooking.com</p></td></tr>';
        echo '<tr><th><label for="lu_slug">Salon slug</label></th><td>';
        echo '<input name="' . esc_attr(LUMIO_OPT_SLUG) . '" id="lu_slug" type="text" class="regular-text" value="' . esc_attr($slug) . '" placeholder="lux-nail-spa" />';
        echo '<p class="description">The part after /book/ in your booking link.</p></td></tr>';
        if ($slug) {
            $link = esc_url(lumio_booking_base() . '/book/' . $slug);
            echo '<tr><th>Your booking link</th><td><a href="' . $link . '" target="_blank" rel="noopener">' . esc_html($link) . '</a></td></tr>';
        }
        echo '</table>';
        submit_button('Save settings');
        echo '</form>';
        echo '<hr><p>Show the form to customers: add <code>[lumio_booking]</code> to any page. Manage bookings via the Dashboard / Calendar / Bookings menu on the left.</p></div>';
    }

    add_shortcode('lumio_booking', 'lumio_booking_sc');
    function lumio_booking_sc($atts) {
        $atts = shortcode_atts(array('slug' => '', 'url' => '', 'height' => '900'), $atts, 'lumio_booking');
        $site = ($atts['url'] !== '') ? rtrim($atts['url'], '/') : lumio_booking_base();
        $slug = ($atts['slug'] !== '') ? $atts['slug'] : get_option(LUMIO_OPT_SLUG, '');
        $slug = trim((string) $slug);
        if (!$slug) {
            return current_user_can('manage_options') ? '<p><em>Lumio Booking: set the Salon slug under Lumio Booking - Settings.</em></p>' : '';
        }
        $src = esc_url($site . '/book/' . rawurlencode($slug));
        $h = max(400, intval($atts['height']));
        return '<div style="width:100%;max-width:980px;margin:0 auto"><iframe src="' . $src . '" loading="lazy" title="Book an appointment" allow="payment" style="width:100%;min-height:' . $h . 'px;border:0;border-radius:16px;background:transparent"></iframe></div>';
    }
}
