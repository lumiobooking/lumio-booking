import { visitsAreTracked } from './visits-tracked';
import { lumioPostsOn } from './lumio-posts';
import { monthWindow } from './month-window';
import { Injectable, NotFoundException, BadRequestException, Logger, Optional } from '@nestjs/common';
import { AppointmentStatus, PaymentStatus, UserRole, TenantStatus, NotificationChannel } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthenticatedUser, resolveTenantScope } from '../common/tenant/tenant-context';
import { deriveAcquisition, AcquisitionSource } from './acquisition.util';
import { CANONICAL_SOURCES, CanonicalSource, normalizeSource } from '../common/source.util';
import { SocialRegistry } from './connectors/social-registry';
import { ChannelCreds } from './connectors/social-connector.interface';
import { encryptSecret, decryptSecret, maskHint, encConfigured } from '../payments-hub/crypto.util';
import { NotificationsService } from '../notifications/notifications.service';
import { addDaysToKey, dayKeyTz, startOfDayTz } from '../common/salon-time';
import { SettingsService } from '../settings/settings.service';
import { publicWebBase } from '../common/public-url.util';
import { jsonSafe } from '../common/json-safe';
import { linkedCredsFor, LinkedCreds, LINKABLE_PLATFORMS, credsSource, type SyncAllLine } from './linked-channels';
import { SocialPostsService, type StoredPost } from './social-posts.service';
import { bareLocation, namesMatch, takenLocations } from '../google-reviews/location-match';
import { monthFacts as computeMonthFacts, prevMonthKey, type MonthFacts } from './month-facts';
import { guardNarrative, correctionFor, type GuardReport } from './report-guard';
import { cleanReportPolicy, lifecycleOf, nextActionOf, autoSendDue, DEFAULT_REPORT_POLICY, REPORT_POLICY_KEY, type ReportPolicy } from './report-lifecycle';

/**
 * Marketing module — Phase 0 (read-only).
 *
 * Tells the "marketing → booking → showed up → revenue" story per channel using
 * ONLY data the system already captures. No new tables, no external APIs, and
 * crucially: nothing is fabricated. A channel with no bookings shows real zeros;
 * ratios that need cost data (CPL/CPA/ROI) are NOT computed here — they arrive in
 * Phase 1 once spend is entered, so the UI never shows a made-up number.
 *
 * Everything is strictly tenant-scoped via resolveTenantScope (a super admin may
 * target one salon; a salon admin is pinned to their own).
 */

// Statuses that mean the customer physically came and used the service.
const SHOWED_STATUSES: AppointmentStatus[] = [AppointmentStatus.ARRIVED, AppointmentStatus.COMPLETED];
const REVENUE_EXCLUDED = new Set<string>([AppointmentStatus.CANCELLED, AppointmentStatus.REJECTED]);

/** A stored report whose numbers were taken while its month was still running. */
export function reportIsPartial(snapshot: unknown): boolean {
  const s = (snapshot ?? null) as { running?: boolean; facts?: { state?: string } | null } | null;
  return !!s && (s.running === true || s.facts?.state === 'to-date');
}

type ChannelRow = { key: CanonicalSource; bookings: number; showed: number; revenueCents: number };

@Injectable()
export class MarketingService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly social: SocialRegistry,
    private readonly notifications: NotificationsService,
    private readonly settings: SettingsService,
    // Optional so the older specs that build the service bare still do; in
    // the app it is always there (same module).
    @Optional() private readonly socialPosts?: SocialPostsService,
  ) {}

  /**
   * THE MONTH'S CONTENT NUMBERS — posts, interactions, top 5 — from the
   * social_posts table (month-facts.ts). Months stored before that table
   * existed are written out of social_insights.raw the first time they are
   * asked for, so an old report keeps the numbers it showed.
   */
  async monthFacts(user: AuthenticatedUser, month: string, tenantParam?: string): Promise<MonthFacts | null> {
    const tenantId = this.tenantId(user, tenantParam);
    if (!/^\d{4}-\d{2}$/.test(month || '')) throw new BadRequestException('month must be YYYY-MM');
    if (!this.socialPosts) return null;
    const tz = await this.tenantTz(tenantId);
    const prev = prevMonthKey(month);
    let [cur, before] = await Promise.all([this.socialPosts.postsForMonth(tenantId, month), this.socialPosts.postsForMonth(tenantId, prev)]);
    if (!cur.length || !before.length) {
      const rows = (await this.prisma.socialInsight.findMany({ where: { tenantId, periodMonth: { in: [month, prev] }, platform: { in: ['facebook', 'instagram', 'tiktok'] } }, select: { platform: true, periodMonth: true, raw: true } })) as Array<{ platform: string; periodMonth: string; raw: unknown }>;
      let changed = 0;
      if (!cur.length) changed += await this.socialPosts.backfillFromInsights(tenantId, month, rows.filter((r) => r.periodMonth === month), tz);
      if (!before.length) changed += await this.socialPosts.backfillFromInsights(tenantId, prev, rows.filter((r) => r.periodMonth === prev), tz);
      if (changed) [cur, before] = await Promise.all([this.socialPosts.postsForMonth(tenantId, month), this.socialPosts.postsForMonth(tenantId, prev)]);
    }
    return computeMonthFacts(month, cur as StoredPost[], before as StoredPost[], dayKeyTz(new Date(), tz || 'UTC'));
  }

  /** The tenant a request acts on (salon admin: their own; super admin: ?tenantId). For sibling services. */
  resolveTenant(user: AuthenticatedUser, requested?: string): string {
    return this.tenantId(user, requested);
  }

  private tenantId(user: AuthenticatedUser, requested?: string): string {
    const id = resolveTenantScope(user, requested);
    if (!id) throw new NotFoundException('No tenant context');
    return id;
  }

  /** The tenant's own timezone — every month and day edge here is theirs. */
  private async tzOf(tenantId: string): Promise<string> {
    const t = await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }).catch(() => null);
    return t?.timezone || 'UTC';
  }

  /**
   * The report window, anchored to the SALON's days. Server-local parsing here
   * used to start every Austin month seven-plus hours early when the server or
   * the reader sat in another timezone — and every ROI figure with it.
   */
  private async range(tenantId: string, fromStr?: string, toStr?: string) {
    const tz = await this.tzOf(tenantId);
    const now = new Date();
    const todayKey = dayKeyTz(now, tz);
    const ok = (x?: string) => /^\d{4}-\d{2}-\d{2}$/.test(String(x ?? ''));
    const fromKey = ok(fromStr) ? String(fromStr) : `${todayKey.slice(0, 7)}-01`;
    const toKey = ok(toStr) ? String(toStr) : todayKey;
    const from = startOfDayTz(fromKey, tz);
    const to = ok(toStr) ? new Date(startOfDayTz(addDaysToKey(toKey, 1), tz).getTime() - 1) : now;
    return { from, to, fromKey, toKey };
  }

  /**
   * Per-channel funnel + owned-channel signals for a date range. Read-only.
   */
  async overview(user: AuthenticatedUser, fromStr?: string, toStr?: string, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    const { from, to, fromKey, toKey } = await this.range(tenantId, fromStr, toStr);

    const [appts, payments, reviews, reviewClicks, messengerThreads, voiceCalls, emailCampaigns, referredNew, newCustomers] = await Promise.all([
      this.prisma.appointment.findMany({
        where: { tenantId, startTime: { gte: from, lte: to } },
        select: { id: true, source: true, status: true, startTime: true, utmCampaign: true, utmSource: true, utmMedium: true, gclid: true, gbraid: true, wbraid: true, attrReferrer: true },
      }),
      // Revenue is read below, by the window's own appointments (see there).
      Promise.resolve([] as { amountCents: number; appointmentId: string | null }[]),
      // A review counts in the month Google says it was written — not when Lumio
      // first mirrored it (the first sync used to put every old review in "this month").
      this.prisma.googleReview.count({ where: { tenantId, OR: [{ reviewCreatedAt: { gte: from, lte: to } }, { reviewCreatedAt: null, createdAt: { gte: from, lte: to } }] } as never }),
      this.prisma.reviewClick.count({ where: { tenantId, createdAt: { gte: from, lte: to } } }),
      this.prisma.messengerThread.count({ where: { tenantId, createdAt: { gte: from, lte: to } } }),
      this.prisma.voiceCall.findMany({ where: { tenantId, createdAt: { gte: from, lte: to } }, select: { outcome: true } }),
      this.prisma.emailCampaign.findMany({ where: { tenantId, status: 'sent', createdAt: { gte: from, lte: to } }, select: { sent: true } }),
      // New = first seen in the window, not a past client loaded by a list import.
      this.prisma.customer.count({ where: { tenantId, createdAt: { gte: from, lte: to }, referredById: { not: null }, importedAt: null } as never }),
      this.prisma.customer.count({ where: { tenantId, createdAt: { gte: from, lte: to }, importedAt: null } as never }),
    ]);
    // Revenue for the window's visits, whenever it was paid: a deposit taken on
    // the 28th for a visit on the 3rd belongs to the visit's month. Filtering by
    // paidAt used to drop it from BOTH months (it was outside one window and its
    // visit outside the other).
    const apptIds = appts.map((a) => a.id);
    payments.push(...(apptIds.length ? await this.prisma.payment.findMany({
      where: { tenantId, status: PaymentStatus.PAID, appointmentId: { in: apptIds } },
      select: { amountCents: true, appointmentId: true },
    }) : []));

    // --- Per-channel bookings + showed -------------------------------------
    const rows = new Map<CanonicalSource, ChannelRow>(
      CANONICAL_SOURCES.map((k) => [k, { key: k, bookings: 0, showed: 0, revenueCents: 0 }]),
    );
    const sourceByAppt = new Map<string, CanonicalSource>();
    const excludedAppt = new Set<string>();
    // Campaign-level attribution (UTM). Keyed by campaign, falling back to the
    // utm_source when no campaign name is present. Only bookings that actually
    // carry a UTM are counted here — everything else stays channel-level.
    type CampRow = { key: string; source: string | null; bookings: number; showed: number; revenueCents: number };
    const camps = new Map<string, CampRow>();
    const campByAppt = new Map<string, string>();
    // First-party ACQUISITION classification (separate from booking surface):
    // google_ads (click id) > google_maps_organic (GBP link) > website (embed)
    // > referral > direct. `gbp` stays as the google_maps_organic alias so
    // existing consumers keep working.
    const ACQ_KEYS: AcquisitionSource[] = ['google_ads', 'google_maps_organic', 'website', 'referral', 'direct', 'unknown'];
    const acquisition = Object.fromEntries(ACQ_KEYS.map((k) => [k, { bookings: 0, showed: 0, revenueCents: 0 }])) as Record<AcquisitionSource, { bookings: number; showed: number; revenueCents: number }>;
    const acqByAppt = new Map<string, AcquisitionSource>();
    const gbp = acquisition.google_maps_organic;
    const gbpAppt = new Set<string>();
    let cancelled = 0;
    for (const a of appts) {
      // A cancelled appointment is not a booking the marketing brought in: it is
      // counted on its own line, never in bookings, show rate or cost per booking.
      if (a.status === AppointmentStatus.CANCELLED) { cancelled += 1; excludedAppt.add(a.id); continue; }
      const acq = deriveAcquisition(a as any);
      acqByAppt.set(a.id, acq);
      acquisition[acq].bookings += 1;
      if (SHOWED_STATUSES.includes(a.status)) acquisition[acq].showed += 1;
      if (acq === 'google_maps_organic') gbpAppt.add(a.id);
      const ch = normalizeSource(a.source);
      sourceByAppt.set(a.id, ch);
      if (REVENUE_EXCLUDED.has(a.status)) excludedAppt.add(a.id);
      const row = rows.get(ch)!;
      row.bookings += 1;
      if (SHOWED_STATUSES.includes(a.status)) row.showed += 1;
      const campKey = (a.utmCampaign || a.utmSource || '').trim();
      if (campKey) {
        campByAppt.set(a.id, campKey);
        const cr = camps.get(campKey) ?? { key: campKey, source: a.utmSource ?? null, bookings: 0, showed: 0, revenueCents: 0 };
        cr.bookings += 1;
        if (SHOWED_STATUSES.includes(a.status)) cr.showed += 1;
        camps.set(campKey, cr);
      }
    }
    // --- Revenue per channel (via appointment → source) --------------------
    for (const p of payments) {
      if (!p.appointmentId || excludedAppt.has(p.appointmentId)) continue;
      const ch = sourceByAppt.get(p.appointmentId);
      if (!ch) continue; // payment for an appointment outside the window
      rows.get(ch)!.revenueCents += p.amountCents;
      const acq = acqByAppt.get(p.appointmentId);
      if (acq) acquisition[acq].revenueCents += p.amountCents;
      const campKey = campByAppt.get(p.appointmentId);
      if (campKey) { const cr = camps.get(campKey); if (cr) cr.revenueCents += p.amountCents; }
    }

    const channels = CANONICAL_SOURCES.map((k) => rows.get(k)!);
    const totals = {
      ...channels.reduce(
        (acc, r) => ({ bookings: acc.bookings + r.bookings, showed: acc.showed + r.showed, revenueCents: acc.revenueCents + r.revenueCents }),
        { bookings: 0, showed: 0, revenueCents: 0 },
      ),
      cancelled,
    };

    const voiceBooked = voiceCalls.filter((c) => c.outcome === 'booked').length;
    const emailsSent = emailCampaigns.reduce((s, c) => s + (c.sent ?? 0), 0);

    // Does the salon close its visits in Lumio? (visits-tracked.ts) If not,
    // "showed" and revenue are not measured — the screens print "—", not 0.
    const nowMs = Date.now();
    const pastBookings = appts.filter((a) => a.status !== AppointmentStatus.CANCELLED && new Date(a.startTime).getTime() < nowMs).length;
    const walkIns = pastBookings >= 3 && totals.showed === 0 && totals.revenueCents === 0
      ? await this.prisma.walkIn.count({ where: { tenantId, createdAt: { gte: from, lte: to }, status: { not: 'CANCELLED' } } as never }).catch(() => 0)
      : 0;
    const visitsTracked = visitsAreTracked({ pastBookings, showed: totals.showed, revenueCents: totals.revenueCents, walkIns });

    return {
      range: { from: fromKey, to: toKey },
      channels,
      totals,
      // Owned-channel signals — real activity we already capture. No spend here.
      owned: {
        googleReviews: reviews,
        reviewClicks,
        messengerThreads,
        voiceCalls: voiceCalls.length,
        voiceBooked,
        emailsSent,
        referredNewCustomers: referredNew,
      },
      newCustomers,
      visitsTracked,
      // Bookings PROVEN to come from Google Maps via the salon's GBP link.
      gbp,
      // Full first-party acquisition breakdown (surface-independent).
      acquisition,
      // Campaign-level attribution (only bookings that carried a UTM).
      byCampaign: Array.from(camps.values()).sort((x, y) => y.revenueCents - x.revenueCents || y.bookings - x.bookings).slice(0, 20),
      // Explicit: paid-channel cost/reach come in Phase 1 (manual) / Phase 3 (API).
      hasCostData: false,
    };
  }

  // ======================= PHASE 1: spend / worklog / report ===============

  private readonly logger = new Logger('Marketing');

  /**
   * A month key's instants, in UTC — a stable convention instead of the
   * server's accidental one. Tenant-facing month REPORTS do not use these
   * instants any more: they hand overview() the month's day keys and let it
   * anchor them to the tenant's timezone.
   */
  private monthRange(month: string): { from: Date; to: Date } {
    if (!/^\d{4}-\d{2}$/.test(month || '')) throw new BadRequestException('month must be YYYY-MM');
    const [y, m] = month.split('-').map(Number);
    return { from: new Date(Date.UTC(y, m - 1, 1)), to: new Date(Date.UTC(y, m, 1) - 1) };
  }

  /** "2026-09" -> "2026-09-30" — pure calendar math, no timezone can shift it. */
  private lastDayKeyOf(month: string): string {
    const [y, m] = month.split('-').map(Number);
    return new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
  }

  // ---- Spend (one row per tenant+channel+month) ---------------------------
  async listSpend(user: AuthenticatedUser, month: string, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    return this.prisma.marketingSpend.findMany({ where: { tenantId, periodMonth: month }, orderBy: { channel: 'asc' } });
  }

  async upsertSpend(user: AuthenticatedUser, dto: { channel: string; periodMonth: string; amountCents?: number; currency?: string; reach?: number | null; clicks?: number | null; leads?: number | null; note?: string | null; tenantId?: string }) {
    const tenantId = this.tenantId(user, dto.tenantId);
    const channel = (dto.channel || '').trim().toLowerCase();
    if (!channel) throw new BadRequestException('channel is required');
    if (!/^\d{4}-\d{2}$/.test(dto.periodMonth || '')) throw new BadRequestException('periodMonth must be YYYY-MM');
    const data = {
      amountCents: Math.max(0, Math.round(Number(dto.amountCents) || 0)),
      currency: dto.currency || 'USD',
      reach: dto.reach == null ? null : Math.max(0, Math.round(Number(dto.reach))),
      clicks: dto.clicks == null ? null : Math.max(0, Math.round(Number(dto.clicks))),
      leads: dto.leads == null ? null : Math.max(0, Math.round(Number(dto.leads))),
      note: dto.note?.slice(0, 500) || null,
      source: 'manual',
      createdByUserId: user.userId,
    };
    return this.prisma.marketingSpend.upsert({
      where: { tenantId_channel_periodMonth: { tenantId, channel, periodMonth: dto.periodMonth } },
      create: { tenantId, channel, periodMonth: dto.periodMonth, ...data },
      update: data,
    });
  }

  async deleteSpend(user: AuthenticatedUser, id: string) {
    const tenantId = this.tenantId(user);
    const row = await this.prisma.marketingSpend.findFirst({ where: { id, tenantId } });
    if (!row) throw new NotFoundException('Spend row not found');
    await this.prisma.marketingSpend.delete({ where: { id: row.id } });
    return { ok: true };
  }

  // ---- Work log -----------------------------------------------------------
  async listWorkLog(user: AuthenticatedUser, month: string, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    return this.prisma.marketingWorkLog.findMany({ where: { tenantId, periodMonth: month }, orderBy: { createdAt: 'desc' } });
  }

  async addWorkLog(user: AuthenticatedUser, dto: { periodMonth: string; category?: string; title: string; note?: string; tenantId?: string }) {
    const tenantId = this.tenantId(user, dto.tenantId);
    const title = (dto.title || '').trim();
    if (!title) throw new BadRequestException('title is required');
    if (!/^\d{4}-\d{2}$/.test(dto.periodMonth || '')) throw new BadRequestException('periodMonth must be YYYY-MM');
    return this.prisma.marketingWorkLog.create({
      data: { tenantId, periodMonth: dto.periodMonth, category: (dto.category || 'other').slice(0, 30), title: title.slice(0, 200), note: dto.note?.slice(0, 500) || null, createdByUserId: user.userId },
    });
  }

  async deleteWorkLog(user: AuthenticatedUser, id: string) {
    const tenantId = this.tenantId(user);
    const row = await this.prisma.marketingWorkLog.findFirst({ where: { id, tenantId } });
    if (!row) throw new NotFoundException('Work log not found');
    await this.prisma.marketingWorkLog.delete({ where: { id: row.id } });
    return { ok: true };
  }

  // ---- Assembled month data (the single source the report is written from) --
  async monthlyData(user: AuthenticatedUser, month: string, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    if (!/^\d{4}-\d{2}$/.test(month || '')) throw new BadRequestException('month must be YYYY-MM');
    // Day keys, not instants: overview() anchors them to the tenant's timezone.
    // A month still running is read through TODAY (salon time), and compared
    // with the same days of last month — not a partial month against a full one
    // ("revenue ▼70%" on the 10th).
    const todayKey = dayKeyTz(new Date(), await this.tzOf(tenantId));
    const running = todayKey.slice(0, 7) === month;
    const fromStr = `${month}-01`;
    const toStr = running ? todayKey : this.lastDayKeyOf(month);

    const [ov, spend, workLog] = await Promise.all([
      this.overview(user, fromStr, toStr, tenantParam),
      this.prisma.marketingSpend.findMany({ where: { tenantId, periodMonth: month }, orderBy: { channel: 'asc' } }),
      this.prisma.marketingWorkLog.findMany({ where: { tenantId, periodMonth: month }, orderBy: { createdAt: 'desc' } }),
    ]);

    const totalSpendCents = spend.reduce((sVal, r) => sVal + r.amountCents, 0);
    const bookings = ov.totals.bookings;
    const showed = ov.totals.showed;
    const revenueCents = ov.totals.revenueCents;
    const newCustomers = ov.newCustomers;

    // BLENDED metrics only. Phase 1 has no per-ad attribution (that arrives with
    // UTM in Phase 2), so we deliberately do NOT split cost per channel-outcome.
    // Every ratio is null unless BOTH sides are real numbers — never a guess.
    const tracked = ov.visitsTracked !== false;
    const blended = {
      totalSpendCents,
      costPerBookingCents: totalSpendCents > 0 && bookings > 0 ? Math.round(totalSpendCents / bookings) : null,
      costPerShowedCents: tracked && totalSpendCents > 0 && showed > 0 ? Math.round(totalSpendCents / showed) : null,
      costPerNewCustomerCents: totalSpendCents > 0 && newCustomers > 0 ? Math.round(totalSpendCents / newCustomers) : null,
      // Revenue returned per $1 spent. Only booking-attributed revenue is counted —
      // and none when the salon checks out outside Lumio (it would read 0×).
      revenuePerSpend: tracked && totalSpendCents > 0 ? Math.round((revenueCents / totalSpendCents) * 100) / 100 : null,
    };

    // --- Month-over-month comparison (clients love "up X% vs last month") ---
    const [py, pm] = month.split('-').map(Number);
    const prev = pm === 1 ? `${py - 1}-12` : `${py}-${String(pm - 1).padStart(2, '0')}`;
    const prevLast = this.lastDayKeyOf(prev);
    const prevTo = running ? `${prev}-${String(Math.min(Number(todayKey.slice(8, 10)), Number(prevLast.slice(8, 10)))).padStart(2, '0')}` : prevLast;
    const [prevOv, prevSpend] = await Promise.all([
      this.overview(user, `${prev}-01`, prevTo, tenantParam),
      this.prisma.marketingSpend.findMany({ where: { tenantId, periodMonth: prev }, select: { channel: true, amountCents: true, reach: true, clicks: true, leads: true } }),
    ]);
    const prevSpendCents = prevSpend.reduce((a: number, r: { amountCents: number }) => a + r.amountCents, 0);
    // pct null = no arrow: nothing to compare against (0 last month), or 0 both months.
    const delta = (cur: number, prv: number) => ({ value: cur, prev: prv, pct: prv > 0 ? Math.round(((cur - prv) / prv) * 100) : null });
    const deltas = {
      bookings: delta(bookings, prevOv.totals.bookings),
      // Not measured in either month → no arrow (never "▼100%").
      showed: tracked && prevOv.visitsTracked !== false ? delta(showed, prevOv.totals.showed) : { value: showed, prev: prevOv.totals.showed, pct: null },
      revenueCents: tracked && prevOv.visitsTracked !== false ? delta(revenueCents, prevOv.totals.revenueCents) : { value: revenueCents, prev: prevOv.totals.revenueCents, pct: null },
      newCustomers: delta(newCustomers, prevOv.newCustomers),
      spendCents: delta(totalSpendCents, prevSpendCents),
    };

    // --- Per-channel month-over-month movement (spend / reach / clicks / leads).
    // This is what lets the report say "Facebook: reach up 24%, clicks down 8%"
    // instead of only judging totals. null = metric absent in both months.
    const prevByCh = new Map<string, any>((prevSpend as any[]).map((r: any) => [r.channel, r]));
    // A figure left blank in either month is unknown, not zero: no "reach ▼100%"
    // because nobody typed October's reach in.
    const chDelta = (cur?: number | null, prv?: number | null) => {
      if (cur == null || prv == null) return null;
      if (cur === 0 && prv === 0) return null;
      return { value: cur, prev: prv, pct: prv > 0 ? Math.round(((cur - prv) / prv) * 100) : null };
    };
    const chNames = Array.from(new Set([...(spend as any[]).map((r: any) => r.channel), ...(prevSpend as any[]).map((r: any) => r.channel)]));
    const channelTrends = chNames.map((ch: string) => {
      const cur = (spend as any[]).find((r: any) => r.channel === ch);
      const prv = prevByCh.get(ch);
      return {
        channel: ch,
        spend: chDelta(cur?.amountCents, prv?.amountCents),
        reach: chDelta(cur?.reach, prv?.reach),
        clicks: chDelta(cur?.clicks, prv?.clicks),
        leads: chDelta(cur?.leads, prv?.leads),
      };
    }).filter((t) => t.spend || t.reach || t.clicks || t.leads);

    // --- Simple effectiveness verdict (only when there is spend to judge) ---
    // good: >=3x return; ok: >=1x; low: <1x. No spend => "organic" (can't rate ROI).
    let effectiveness: 'good' | 'ok' | 'low' | 'organic' = 'organic';
    if (totalSpendCents > 0) {
      const r = revenueCents / totalSpendCents;
      effectiveness = r >= 3 ? 'good' : r >= 1 ? 'ok' : 'low';
    }

    // --- Organic social (Facebook/Instagram) with month-over-month movement ---
    // Concrete owned-channel numbers for the report: total + new followers,
    // reach, views, engagement. null = Meta no longer exposes that metric.
    const [socRows, prevSocRows] = await Promise.all([
      this.prisma.socialInsight.findMany({ where: { tenantId, periodMonth: month } }),
      this.prisma.socialInsight.findMany({ where: { tenantId, periodMonth: prev } }),
    ]);
    const prevSoc = new Map<string, any>((prevSocRows as any[]).map((r: any) => [r.platform, r]));

    // Monthly follower snapshots for a growth chart (esp. Facebook, which has no
    // live daily-follower metric) — built from our own stored months, not Meta.
    const seriesMonths: string[] = [];
    {
      const [yy, mm] = month.split('-').map(Number);
      for (let i = 5; i >= 0; i--) { const d = new Date(yy, mm - 1 - i, 1); seriesMonths.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`); }
    }
    const seriesRows = await this.prisma.socialInsight.findMany({ where: { tenantId, periodMonth: { in: seriesMonths } }, select: { platform: true, periodMonth: true, followers: true } });
    const monthlySeriesFor = (platform: string) => seriesMonths
      .map((mm) => { const row = (seriesRows as any[]).find((x: any) => x.platform === platform && x.periodMonth === mm); return row && row.followers != null ? { month: mm, followers: row.followers as number } : null; })
      .filter(Boolean) as Array<{ month: string; followers: number }>;
    const socDelta = (cur?: number | null, prv?: number | null) => {
      if (cur == null && prv == null) return null;
      const c = cur ?? 0; const pv = prv ?? 0;
      return { value: cur ?? null, prev: prv ?? null, pct: pv > 0 && cur != null ? Math.round(((c - pv) / pv) * 100) : null };
    };
    const socialInsights = (socRows as any[]).filter((r: any) => r.platform !== 'gbp').map((r: any) => ({
      platform: r.platform,
      followers: r.followers,
      // Fall back to month-over-month net new followers when Meta's direct metric is null (esp. Facebook).
      newFollowers: r.newFollowers ?? ((): number | null => { const pf = prevSoc.get(r.platform)?.followers; return (pf != null && r.followers != null) ? r.followers - pf : null; })(),
      monthlySeries: monthlySeriesFor(r.platform),
      reach: r.reach, views: r.views, engagement: r.engagement,
      profileViews: r.profileViews, postsCount: r.postsCount,
      posts: (r.raw && (r.raw as any).posts) ? (r.raw as any).posts : [],
      series: (r.raw && (r.raw as any).series) ? (r.raw as any).series : [],
      audience: (r.raw && (r.raw as any).audience) ? (r.raw as any).audience : null,
      fbDebug: (r.raw && (r.raw as any).fbDebug) ? (r.raw as any).fbDebug : null,
      igDebug: (r.raw && (r.raw as any).igDebug) ? (r.raw as any).igDebug : null,
      syncedAt: r.syncedAt,
      vsPrev: {
        followers: socDelta(r.followers, prevSoc.get(r.platform)?.followers),
        reach: socDelta(r.reach, prevSoc.get(r.platform)?.reach),
        views: socDelta(r.views, prevSoc.get(r.platform)?.views),
        engagement: socDelta(r.engagement, prevSoc.get(r.platform)?.engagement),
        newFollowers: socDelta(r.newFollowers, prevSoc.get(r.platform)?.newFollowers),
      },
    }));

    // TikTok posts, counted from Lumio's own publish log when TikTok itself
    // gave no count (the app has no video.list permission — see lumio-posts.ts).
    try {
      const w = monthWindow(month, await this.tenantTz(tenantId));
      const from = new Date(w.from), to = new Date(w.to);
      const published = await this.prisma.scheduledPost.findMany({
        where: { tenantId, status: 'posted', postedAt: { gte: from, lt: to } },
        select: { postedAt: true, results: true },
      });
      const tt = lumioPostsOn(published as never, 'tiktok', from, to);
      const row: any = socialInsights.find((x: any) => x.platform === 'tiktok');
      if (row && (row.postsCount == null || row.postsCount === 0) && tt.length) {
        row.postsCount = tt.length;
        row.postsSource = 'lumio';
        if (!row.posts?.length) row.posts = tt.map((p) => ({ id: p.id, type: 'video', timestamp: p.timestamp, permalink: p.url }));
      } else if (!row && tt.length) {
        socialInsights.push({
          platform: 'tiktok', followers: null, newFollowers: null, monthlySeries: [], reach: null, views: null, engagement: null,
          profileViews: null, postsCount: tt.length, postsSource: 'lumio',
          posts: tt.map((p) => ({ id: p.id, type: 'video', timestamp: p.timestamp, permalink: p.url })),
          series: [], audience: null, fbDebug: null, igDebug: null, syncedAt: null,
          vsPrev: { followers: null, reach: null, views: null, engagement: null, newFollowers: null },
        } as any);
      }
    } catch { /* the report never fails over a count */ }

    // --- Google Business Profile (Maps) monthly performance — its own deck ---
    const gbpRow = (socRows as any[]).find((r: any) => r.platform === 'gbp');
    let gbp: any = null;
    if (gbpRow) {
      const cur = ((gbpRow.raw as any)?.gbp) || {};
      const prv = ((prevSoc.get('gbp')?.raw as any)?.gbp) || {};
      const gbpSeriesRows = await this.prisma.socialInsight.findMany({ where: { tenantId, platform: 'gbp', periodMonth: { in: seriesMonths } }, select: { periodMonth: true, raw: true } });
      const gbpSeries = seriesMonths.map((mm) => {
        const row = (gbpSeriesRows as any[]).find((x: any) => x.periodMonth === mm);
        const g = (row?.raw as any)?.gbp;
        return g ? { month: mm, impressions: g.impressions ?? null, calls: g.calls ?? null, directions: g.directions ?? null, websiteClicks: g.websiteClicks ?? null, bookings: g.bookings ?? null } : null;
      }).filter(Boolean);
      gbp = {
        ...cur,
        vsPrev: {
          impressions: socDelta(cur.impressions, prv.impressions),
          calls: socDelta(cur.calls, prv.calls),
          directions: socDelta(cur.directions, prv.directions),
          websiteClicks: socDelta(cur.websiteClicks, prv.websiteClicks),
          bookings: socDelta(cur.bookings, prv.bookings),
          conversations: socDelta(cur.conversations, prv.conversations),
        },
        series: gbpSeries,
        syncedAt: gbpRow.syncedAt,
      };
      gbp.profileCheck = await this.gbpProfileCheck(tenantId, cur).catch(() => null);
      // Search keywords are the clearest tell of whose profile it is: printed
      // under the wrong salon they read as a fact about that salon. Left out
      // until the location is right; the screen says why.
      if (gbp.profileCheck && (gbp.profileCheck.shared || gbp.profileCheck.nameMismatch)) gbp.keywords = [];
    }

    // Posts / interactions / top 5 from the stored posts (never from raw).
    const facts = await this.monthFacts(user, month, tenantParam).catch(() => null);
    // The salon's money: every *Cents figure is in its minor unit (đồng have none).
    const rulesRow = await this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: 'booking_rules' } }, select: { value: true } }).catch(() => null);
    const curRaw = String((rulesRow?.value as { currency?: string } | null)?.currency ?? '').toUpperCase();
    const currency = /^[A-Z]{3}$/.test(curRaw) ? curRaw : 'USD';
    return { month, currency, range: { from: fromStr, to: toStr }, running, prevRange: { from: `${prev}-01`, to: prevTo }, outcome: ov, spend, workLog, blended, prevMonth: prev, deltas, channelTrends, socialInsights, gbp, effectiveness, facts };
  }

  /**
   * Is the Google profile behind this month's Maps numbers really THIS salon's?
   * Two ways it is not: the same location is linked to another salon, or the
   * profile's name shares no distinctive word with the salon's (trade words
   * like "nail", "spa", "salon" do not count). Either one, and the keywords,
   * views and calls are another business's — the report flags the block and
   * leaves the keywords out instead of printing "nail salon near me" for a
   * bonsai garden. Names of other salons are never returned.
   */
  private async gbpProfileCheck(tenantId: string, g: { location?: string; locationTitle?: string | null }): Promise<{ shared: boolean; nameMismatch: boolean; locationTitle: string | null }> {
    const [tenant, own, rows] = await Promise.all([
      this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { name: true } }),
      this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: 'googleReviews' } }, select: { value: true } }),
      this.prisma.setting.findMany({ where: { key: 'googleReviews' }, select: { tenantId: true, value: true } }),
    ]);
    const ownV = (own?.value ?? {}) as { locationId?: string; locationTitle?: string };
    const loc = bareLocation(g.location || ownV.locationId);
    const title = (g.locationTitle || ownV.locationTitle || '').trim() || null;
    const shared = !!loc && takenLocations(rows as Array<{ tenantId: string; value: unknown }>, tenantId).has(loc);
    const nameMismatch = !!title && !!tenant?.name && !namesMatch(title, tenant.name);
    return { shared, nameMismatch, locationTitle: title };
  }

  // ---- AI draft (Anthropic, same pattern as the voice/messenger agents) ----

  /**
   * Deterministic report writer — builds the SAME content shape as the AI purely
   * from the real numbers. Used to backfill sections the AI leaves empty, and as a
   * full fallback when ANTHROPIC_API_KEY is missing / the AI call fails, so the
   * monthly report is NEVER blank (true "100% automated" behaviour).
   */
  private ruleBasedDraft(data: any): any {
    const S: any[] = (data.socialInsights ?? []);
    const ig = S.find((x) => x.platform === 'instagram');
    const fb = S.find((x) => x.platform === 'facebook');
    const n = (x: any) => (x == null ? null : String(Math.round(Number(x))).replace(/\B(?=(\d{3})+(?!\d))/g, ','));
    const pctTxt = (d: any) => (d && d.pct != null ? (d.pct >= 0 ? `+${d.pct}%` : `${d.pct}%`) : null);
    const bi = (vi: string, en: string) => ({ vi, en });
    const platLabel = (pf: string) => (pf === 'facebook' ? 'Facebook' : 'Instagram');

    const totalReach = S.reduce((a, x) => a + (x.reach ?? 0), 0);
    const totalViews = S.reduce((a, x) => a + (x.views ?? 0), 0);
    const totalEng = S.reduce((a, x) => a + (x.engagement ?? 0), 0);
    const newFol = S.reduce((a, x) => a + (x.newFollowers ?? 0), 0);
    const postsAll = S.reduce((a, x) => a + (x.postsCount ?? (x.posts?.length ?? 0)), 0);
    const igER = (ig && ig.engagement != null && ig.reach) ? Math.round((ig.engagement / ig.reach) * 1000) / 10 : null;

    // ---- channels: one line per organic network, judged on momentum ----
    const channels: any[] = [];
    for (const sIns of S) {
      const rp = sIns.vsPrev?.reach, ep = sIns.vsPrev?.engagement, fp = sIns.vsPrev?.followers;
      const anyNum = sIns.reach != null || sIns.engagement != null || sIns.followers != null;
      const grew = [rp, ep, fp].some((d) => d && d.pct != null && d.pct > 0);
      const fell = [rp, ep, fp].some((d) => d && d.pct != null && d.pct < 0);
      let verdict: string = 'nodata';
      if (anyNum) verdict = grew && !fell ? 'good' : fell && !grew ? 'weak' : 'ok';
      const vp: string[] = [], ep2: string[] = [];
      if (sIns.reach != null) { vp.push(`reach ${n(sIns.reach)}${pctTxt(rp) ? ` (${pctTxt(rp)})` : ''}`); ep2.push(`reach ${n(sIns.reach)}${pctTxt(rp) ? ` (${pctTxt(rp)})` : ''}`); }
      if (sIns.engagement != null) { vp.push(`tương tác ${n(sIns.engagement)}${pctTxt(ep) ? ` (${pctTxt(ep)})` : ''}`); ep2.push(`${n(sIns.engagement)} engagements${pctTxt(ep) ? ` (${pctTxt(ep)})` : ''}`); }
      if (sIns.views != null) { vp.push(`${n(sIns.views)} lượt xem`); ep2.push(`${n(sIns.views)} views`); }
      if (sIns.followers != null) { vp.push(`${n(sIns.followers)} follower${sIns.newFollowers ? ` (+${sIns.newFollowers})` : ''}`); ep2.push(`${n(sIns.followers)} followers${sIns.newFollowers ? ` (+${sIns.newFollowers})` : ''}`); }
      const viStr = vp.length ? vp.join(', ') : 'Meta đã ngừng cung cấp phần lớn chỉ số của trang — chỉ còn follower & bài đăng.';
      const enStr = ep2.length ? ep2.join(', ') : 'Meta discontinued most Page metrics — only followers & posts remain.';
      channels.push({ name: `${platLabel(sIns.platform)} (organic)`, verdict, vi: viStr, en: enStr });
    }

    // ---- top post across all networks ----
    let top: any = null;
    for (const sIns of S) for (const pp of (sIns.posts ?? [])) {
      // Rank by VIEWS so the 'best post' matches the views-sorted Top list in the deck.
      const score = pp.views ?? pp.interactions ?? ((pp.likes ?? 0) + (pp.comments ?? 0));
      if (!top || score > top._score) top = { ...pp, _score: score, _pf: sIns.platform };
    }

    // ---- highlights (wins) ----
    const highlights: any[] = [];
    if (ig && ig.reach != null) highlights.push(bi(
      `Instagram tiếp cận ${n(ig.reach)} người${pctTxt(ig.vsPrev?.reach) ? ` (${pctTxt(ig.vsPrev?.reach)} so với tháng trước)` : ''}.`,
      `Instagram reached ${n(ig.reach)} people${pctTxt(ig.vsPrev?.reach) ? ` (${pctTxt(ig.vsPrev?.reach)} vs last month)` : ''}.`));
    if (newFol > 0) highlights.push(bi(`Có thêm ${newFol} người theo dõi mới trong tháng.`, `Gained ${newFol} new followers this month.`));
    if (totalViews > 0) highlights.push(bi(`Nội dung đạt tổng ${n(totalViews)} lượt xem.`, `Content reached ${n(totalViews)} total views.`));
    if (top && top._score > 0) highlights.push(bi(
      `Bài nổi bật (${top.type || 'post'}): ${n(top.likes ?? 0)} thích, ${n(top.comments ?? 0)} bình luận${top.views ? `, ${n(top.views)} lượt xem` : ''}.`,
      `Top post (${top.type || 'post'}): ${n(top.likes ?? 0)} likes, ${n(top.comments ?? 0)} comments${top.views ? `, ${n(top.views)} views` : ''}.`));
    if (!highlights.length) highlights.push(bi('Đã đăng bài đều đặn và duy trì hiện diện kênh trong tháng.', 'Posted consistently and maintained channel presence this month.'));

    // ---- issues (challenges + the fix) ----
    const issues: any[] = [];
    if (fb && fb.reach == null && fb.engagement == null) issues.push(bi(
      'Facebook: Meta đã ngừng cung cấp reach & tương tác của trang (2025-2026). Khắc phục: bật chia sẻ Reels từ Instagram sang Facebook Page để vẫn có số liệu và mở rộng phủ sóng.',
      'Facebook: Meta discontinued Page reach & engagement (2025-2026). Fix: enable sharing Instagram Reels to the Facebook Page to keep data flowing and widen reach.'));
    for (const sIns of S) {
      const rp = sIns.vsPrev?.reach;
      if (rp && rp.pct != null && rp.pct < -5) issues.push(bi(
        `${platLabel(sIns.platform)} reach giảm ${rp.pct}% — tăng tần suất đăng và thử thêm Reels để phục hồi hiển thị.`,
        `${platLabel(sIns.platform)} reach fell ${rp.pct}% — increase posting cadence and add more Reels to recover visibility.`));
    }
    if (postsAll > 0 && postsAll < 10) issues.push(bi(
      `Tần suất đăng còn thấp (${postsAll} bài) — nên tăng lên 12-16 bài/tháng để giữ nhịp hiển thị.`,
      `Posting cadence is low (${postsAll} posts) — raise to 12-16/month to sustain reach.`));
    if (!issues.length) issues.push(bi('Chưa có vấn đề nổi cộm; tiếp tục theo dõi nhịp tăng trưởng.', 'No major issues; keep monitoring the growth trend.'));

    // ---- insights (observations) ----
    const insights: any[] = [];
    const age = ig?.audience?.age;
    if (age) {
      const keys = Object.keys(age); const tot = keys.reduce((a, k) => a + (age[k] || 0), 0) || 1;
      const bestK = keys.sort((a, b) => (age[b] || 0) - (age[a] || 0))[0];
      if (bestK) insights.push(bi(
        `Nhóm tuổi ${bestK} chiếm ${Math.round((age[bestK] / tot) * 1000) / 10}% người theo dõi Instagram — nội dung nên nhắm vào nhóm này.`,
        `The ${bestK} age group is ${Math.round((age[bestK] / tot) * 1000) / 10}% of Instagram followers — aim content at this group.`));
    }
    const gd = ig?.audience?.gender;
    if (gd) {
      const tot = (gd.F || 0) + (gd.M || 0) + (gd.U || 0) || 1;
      if ((gd.F || 0) >= (gd.M || 0)) insights.push(bi(
        `Khách nữ chiếm ${Math.round((gd.F / tot) * 1000) / 10}% — ưu tiên mẫu nail nữ và xu hướng theo mùa.`,
        `Female audience is ${Math.round((gd.F / tot) * 1000) / 10}% — prioritise female nail designs and seasonal trends.`));
    }
    const posts = ig?.posts ?? [];
    const avgOf = (pred: (p: any) => boolean) => { const g = posts.filter(pred); if (!g.length) return null; return Math.round(g.reduce((a: number, p: any) => a + (p.interactions ?? ((p.likes ?? 0) + (p.comments ?? 0))), 0) / g.length); };
    const reelG = posts.filter((p: any) => /reel|video/i.test(p.type || ''));
    const imgG = posts.filter((p: any) => /image|photo|carousel/i.test(p.type || ''));
    const reelAvg = avgOf((p) => /reel|video/i.test(p.type || ''));
    const imgAvg = avgOf((p) => /image|photo|carousel/i.test(p.type || ''));
    // Only claim a winning format with a meaningful gap AND enough posts of each type.
    const enoughFmt = reelG.length >= 2 && imgG.length >= 2 && reelAvg != null && imgAvg != null;
    const gapPct = enoughFmt ? Math.abs(reelAvg - imgAvg) / Math.max(reelAvg, imgAvg, 1) : 0;
    if (enoughFmt && gapPct >= 0.15) insights.push(reelAvg > imgAvg
      ? bi(`Reels tạo tương tác cao hơn ảnh tĩnh (${reelAvg} vs ${imgAvg} trung bình/bài) — nên tăng tỷ trọng Reels.`, `Reels drive higher engagement than static photos (${reelAvg} vs ${imgAvg} avg/post) — shift toward Reels.`)
      : bi(`Ảnh tĩnh tương tác tốt hơn Reels (${imgAvg} vs ${reelAvg} trung bình/bài) — giữ tỷ trọng ảnh chất lượng cao.`, `Static photos out-engage Reels (${imgAvg} vs ${reelAvg} avg/post) — keep high-quality photos.`));
    else if (reelG.length + imgG.length > 0) insights.push(bi('Chưa đủ dữ liệu để kết luận Reels hay ảnh hiệu quả hơn — cần thêm bài mỗi định dạng.', 'Not enough data yet to say Reels vs photos win — need more posts of each format.'));
    if (igER != null) insights.push(bi(
      `Tỷ lệ tương tác Instagram ${igER}% trên lượng reach — ${igER >= 2 ? 'ở mức tốt' : 'còn dư địa cải thiện bằng CTA & câu hỏi'}.`,
      `Instagram engagement rate ${igER}% of reach — ${igER >= 2 ? 'a healthy level' : 'room to improve with CTAs & questions'}.`));
    if (!insights.length) insights.push(bi('Chưa đủ dữ liệu nhân khẩu/nội dung để rút ra insight — kết nối Instagram đầy đủ để có thêm phân tích.', 'Not enough audience/content data for insights yet — connect Instagram fully for deeper analysis.'));

    // ---- nextMonth (4 buckets) ----
    const ceil50 = (x: any, f = 1.12) => (x == null ? null : Math.ceil((Number(x) * f) / 50) * 50);
    const nextMonth = {
      content: [
        bi(`Duy trì nhịp đăng đều (~${Math.max(12, postsAll)} bài/tháng trên các kênh), cân bằng Reels và ảnh chất lượng cao.`,
           `Keep a steady cadence (~${Math.max(12, postsAll)} posts/month across channels), balancing Reels and quality photos.`),
        bi('Xoay vòng chủ đề: mẫu nail mới, review khách, ảnh trước/sau, ưu đãi trong tuần.', 'Rotate themes: new nail designs, client reviews, before/after, weekly offers.'),
      ],
      ads: [ (data.blended?.totalSpendCents ?? 0) > 0
        ? bi('Tối ưu ngân sách quảng cáo hiện có về kênh cho chi phí/khách thấp nhất.', 'Optimise the current ad budget toward the lowest cost-per-customer channel.')
        : bi('Chưa chạy quảng cáo — cân nhắc thử $50-100 boost cho Reels tốt nhất để mở rộng reach.', 'No ads yet — consider a $50-100 boost on the best Reel to expand reach.') ],
      growth: [
        bi('Bật chia sẻ Reels Instagram sang Facebook Page để lấp số liệu Facebook và tăng phủ sóng.', 'Enable sharing Instagram Reels to the Facebook Page to fill Facebook data and widen reach.'),
        bi('Trả lời bình luận & tin nhắn trong 1 giờ; chạy 1 mini-game tặng buổi làm nail để tăng tương tác.', 'Reply to comments & DMs within 1 hour; run one giveaway (a free nail session) to lift engagement.'),
      ],
      kpi: [
        ig?.reach != null ? bi(`Reach Instagram ≥ ${n(ceil50(ig.reach))} (hiện ${n(ig.reach)}).`, `Instagram reach ≥ ${n(ceil50(ig.reach))} (now ${n(ig.reach)}).`) : null,
        bi(`Follower mới +${Math.max(30, newFol)} trên các kênh.`, `New followers +${Math.max(30, newFol)} across channels.`),
        igER != null ? bi(`Tỷ lệ tương tác Instagram ≥ ${Math.round((igER + 0.5) * 10) / 10}%.`, `Instagram engagement rate ≥ ${Math.round((igER + 0.5) * 10) / 10}%.`) : null,
        bi(`Đăng ≥ ${Math.max(14, postsAll)} bài trong tháng.`, `Publish ≥ ${Math.max(14, postsAll)} posts in the month.`),
      ].filter(Boolean),
    };
    const plan = [...nextMonth.content, ...nextMonth.growth, ...nextMonth.ads]; // flat legacy fallback

    // ---- headline / tldr / summary ----
    let headline = bi('Kênh mạng xã hội duy trì hiện diện ổn định trong tháng.', 'Social channels held a steady presence this month.');
    if (ig?.vsPrev?.reach?.pct != null && ig.vsPrev.reach.pct > 0) headline = bi(`Reach Instagram tăng ${ig.vsPrev.reach.pct}% so với tháng trước.`, `Instagram reach grew ${ig.vsPrev.reach.pct}% vs last month.`);
    else if (newFol > 0) headline = bi(`Có thêm ${newFol} người theo dõi mới trong tháng.`, `Gained ${newFol} new followers this month.`);
    else if (totalReach > 0) headline = bi(`Tiếp cận tổng ${n(totalReach)} người qua các kênh.`, `Reached ${n(totalReach)} people across channels.`);

    const tldr = bi(
      `Tháng này các kênh organic tiếp cận ${n(totalReach)} người với ${n(totalEng)} lượt tương tác${newFol ? `, thêm ${newFol} follower mới` : ''}. ${ig ? `Instagram là kênh mạnh nhất${igER != null ? ` (tỷ lệ tương tác ${igER}%)` : ''}.` : ''} ${fb && fb.reach == null ? 'Facebook thiếu số liệu do Meta ngừng cung cấp — nên bật crosspost Reels từ Instagram.' : ''} Trọng tâm tháng tới: tăng tần suất Reels và mở rộng phủ sóng sang Facebook.`.replace(/\s+/g, ' ').trim(),
      `This month organic channels reached ${n(totalReach)} people with ${n(totalEng)} engagements${newFol ? `, adding ${newFol} new followers` : ''}. ${ig ? `Instagram was the strongest channel${igER != null ? ` (engagement rate ${igER}%)` : ''}.` : ''} ${fb && fb.reach == null ? 'Facebook lacks data because Meta discontinued it — enable Reel crossposting from Instagram.' : ''} Next month: increase Reels cadence and extend reach to Facebook.`.replace(/\s+/g, ' ').trim());

    const summary = bi(
      `Tổng reach ${n(totalReach)}${pctTxt(ig?.vsPrev?.reach) ? ` (${pctTxt(ig?.vsPrev?.reach)} so với tháng trước trên Instagram)` : ''}, ${n(totalEng)} lượt tương tác, ${n(totalViews)} lượt xem, ${postsAll} bài đăng. Đây là kết quả tự nhiên (organic), chưa tính quảng cáo.`,
      `Total reach ${n(totalReach)}${pctTxt(ig?.vsPrev?.reach) ? ` (${pctTxt(ig?.vsPrev?.reach)} MoM on Instagram)` : ''}, ${n(totalEng)} engagements, ${n(totalViews)} views, ${postsAll} posts. These are organic results, excluding paid ads.`);

    return { headline, tldr, summary, channels, highlights, issues, plan, insights, nextMonth, _ruleBased: true };
  }

  private async draftWithAI(
    data: Awaited<ReturnType<MarketingService['monthlyData']>>,
    history: any[] = [],
    // A second pass: the first JSON and what was wrong with it (report-guard.ts).
    correction?: { prior: string; note: string },
  ): Promise<{ content?: any; model?: string; error?: string; payload?: unknown }> {
    const key = process.env.ANTHROPIC_API_KEY || '';
    if (!key) return { error: 'ANTHROPIC_API_KEY chưa được đặt trên server' };
    const model = process.env.ANTHROPIC_AGENT_MODEL || 'claude-haiku-4-5-20251001';

    const system =
      'You are a senior marketing analyst at an agency, writing the MONTHLY client report for a nail-salon owner who is NOT technical. ' +
      'The report must read as detailed, clear, specific and PROFESSIONAL, yet in plain language with no marketing jargon. ' +
      'STRICT RULES: (1) Use ONLY the numbers in the data. NEVER invent or estimate any figure. ' +
      '(2) Attribution is BLENDED — the data does NOT tell you which ad or channel caused which booking, so do NOT claim a specific channel "generated" specific bookings or revenue. Talk about totals and spend allocation instead. ' +
      '(3) If a needed number is missing or zero, say so plainly (e.g. "chưa nhập chi phí" / "no spend entered") rather than guessing. ' +
      '(3b) NUMBER DISCIPLINE (critical): the app renders every KPI number itself from the data — in your narrative refer to metrics QUALITATIVELY ("reach grew", "the top video") and only quote a figure if it EXACTLY matches the data; never approximate, re-round or invent a number, and never let two sentences state different values for the same metric. The BEST/top post = the one with the most VIEWS. For ads: if spendByChannel has ANY spend, describe ads as running with that exact amount — never write "no ads" when spend > 0. If a comparison has no prior-month value, say "chưa đủ dữ liệu so sánh" instead of implying growth. ' +
      '(4) Output MUST be valid JSON only, matching this EXACT shape, every string in BOTH Vietnamese (vi) and English (en): ' +
      '{"headline":{"vi":"","en":""},"tldr":{"vi":"","en":""},"summary":{"vi":"","en":""},"channels":[{"name":"","verdict":"good","vi":"","en":""}],"highlights":[{"vi":"","en":""}],"issues":[{"vi":"","en":""}],"plan":[{"vi":"","en":""}],"insights":[{"vi":"","en":""}],"nextMonth":{"content":[{"vi":"","en":""}],"ads":[{"vi":"","en":""}],"growth":[{"vi":"","en":""}],"kpi":[{"vi":"","en":""}]}}. ' +
      'headline = the SINGLE most important takeaway of the month in ONE short sentence a busy owner remembers at a glance (e.g. "Doanh thu tăng 31% so với tháng trước"). ' +
      'tldr = the EXECUTIVE SUMMARY: EXACTLY 2 short sentences — how the month went + the single biggest win + the main gap. ' +
      'summary = supporting detail: MUST mention the month-over-month trend from vsLastMonth (e.g. "up 20% vs last month") and state the effectiveness in plain words. ' +
      'channels = evaluate EACH channel that has spend in spendByChannel. verdict = "good" (cheap results / clearly working), "ok" (working, room to improve), "weak" (expensive / little to show), or "nodata" (only spend entered, no reach/clicks/leads to judge). Judge by cost-per-lead or cost-per-click when those numbers exist and CITE that number in the sentence; if they do not exist, verdict MUST be "nodata". ALSO use channelTrends (month-over-month movement per channel): cite the most significant change with its % (e.g. "reach tăng 24%, click giảm 8%"). If a channel FELL while its spend stayed or rose, say so plainly and reflect it in the verdict. Give ONE short line per channel: numbers + trend + action (keep / tăng / giảm / thử lại / tạm dừng). Never invent a number. ' +
      'socialOrganic = per-network ORGANIC (non-paid) results: platform (facebook|instagram), followers (total), newFollowers, reach, views, engagement, and vsPrev month-over-month % for each. For EACH network present, ADD one entry to "channels" named "Facebook (organic)" or "Instagram (organic)" judging MOMENTUM (not ROI, since organic has no spend): verdict "good" if reach/engagement/followers grew, "ok" if roughly flat, "weak" if they fell, "nodata" if all numbers are null. CITE the concrete number and its vsPrev % (e.g. "IG reach 12,400, tăng 18% vs tháng trước; +240 follower mới"). Some Facebook metrics are null because Meta deprecated them in 2025-2026 — NEVER invent them; report only the numbers present (for a nail salon, Instagram is usually the richer channel). Surface the single best organic win in highlights. ' +
      'bookingsFromGoogleMaps = bookings PROVEN to come from Google Maps via the salon\'s Business Profile link (first-party UTM) — when > 0, mention it in summary or highlights as a verified Google Maps result. ' +
      'highlights = concrete wins this month (2-3). issues = CHALLENGES: for each, name the problem AND the solution or recommendation together (1-2) — naming a problem and your response builds trust. ' +
      'plan = set to an EMPTY array []. We derive next-month actions from nextMonth below — do not fill plan. ' +
      'insights = INSIGHT NỔI BẬT: 2-3 sharp OBSERVATIONS (patterns, NOT actions) — best content format (Reels vs photos from topPosts), dominant audience segment (age/gender from socialOrganic.audience), engagement-rate read. Base ONLY on socialOrganic. ' +
      'nextMonth = FOUR buckets, each 1-2 SHORT bullets grounded in THIS month\'s real numbers: ' +
      'nextMonth.content = content plan (cadence, formats to push — e.g. more Reels if Reels won, UGC/review topics). ' +
      'nextMonth.ads = paid plan; if there is NO spend data, put ONE bullet like "Chưa chạy quảng cáo — cân nhắc thử ngân sách nhỏ để tăng reach". ' +
      'nextMonth.growth = growth/community plan (collab/KOC, mini-game, reply faster; if Facebook numbers are thin, recommend bật chia sẻ Reels IG sang Facebook Page). ' +
      'nextMonth.kpi = 2-3 MEASURABLE targets computed from current numbers, each citing the current value, e.g. "Reach IG ≥ X (hiện Y)", "Follower +N". Round sensibly. ' +
      'BREVITY IS REQUIRED — the owner wants short, complete notes, NOT an essay. HARD CAPS: headline ≤ 12 words; every other bullet = ONE plain sentence ≤ 18 words in EACH language; keep vi and en equally short. Output ONLY compact minified JSON (no markdown, no comments), based ONLY on the real numbers; never invent.';

    const facts = (data as any).facts as MonthFacts | null | undefined;
    const running = facts?.state === 'to-date';
    const payload = {
      month: data.month,
      // A month still in progress is compared only to the same days of last
      // month; the text must say "to date" and must not sound an alarm.
      currency: (data as { currency?: string }).currency ?? 'USD',
      moneyUnits: 'Every field ending in Cents is in the minor unit of `currency` (USD/CAD/AUD: cents — divide by 100; VND has no minor unit: the number IS đồng). Write amounts with that currency, never a $ for VND.',
      periodState: running ? `IN PROGRESS — numbers through day ${facts!.daysCovered}; every vsPrev compares the same ${facts!.daysCovered} days of last month; write calmly, say "tính đến ngày ${facts!.daysCovered}"` : 'CLOSED — full month',
      bookings: data.outcome.totals.bookings,
      showedUp: (data.outcome as any).visitsTracked === false ? null : data.outcome.totals.showed,
      bookingRevenueCents: (data.outcome as any).visitsTracked === false ? null : data.outcome.totals.revenueCents,
      ...((data.outcome as any).visitsTracked === false ? { visitsNote: 'NOT MEASURED: this salon takes bookings in Lumio but checks customers out on another system, so showedUp, bookingRevenueCents, show rate and ROAS are unknown (null). Never write 0 customers came, $0 revenue or a drop; at most say these are tracked outside Lumio.' } : {}),
      newCustomers: data.outcome.newCustomers,
      bookingsByChannel: data.outcome.channels.filter((c: any) => c.bookings > 0),
      ownedChannels: data.outcome.owned,
      bookingsFromGoogleMaps: (data.outcome as any).gbp,
      totalSpendCents: data.blended.totalSpendCents,
      spendByChannel: data.spend.map((r: any) => ({ channel: r.channel, amountCents: r.amountCents, reach: r.reach, clicks: r.clicks, leads: r.leads })),
      blended: data.blended,
      vsLastMonth: (data as any).deltas,
      channelTrends: (data as any).channelTrends,
      socialOrganic: ((data as any).socialInsights ?? []).map((si: any) => ({
        platform: si.platform,
        followers: si.followers, newFollowers: si.newFollowers, reach: si.reach, views: si.views, engagement: si.engagement,
        engagementRatePct: (si.engagement != null && si.reach) ? Math.round((si.engagement / si.reach) * 1000) / 10 : null,
        postsCount: si.postsCount, vsPrev: si.vsPrev, audience: si.audience,
        // The five MOST-VIEWED posts (the list arrives newest-first; the AI read
        // "best format" off the five newest before 4 Nov 2026).
        topPosts: [...(si.posts ?? [])].sort((a: any, b: any) => (b.views ?? -1) - (a.views ?? -1) || ((b.likes ?? 0) + (b.comments ?? 0)) - ((a.likes ?? 0) + (a.comments ?? 0))).slice(0, 5).map((pp: any) => ({ type: pp.type, likes: pp.likes, comments: pp.comments, reach: pp.reach, views: pp.views, caption: pp.caption })),
      })),
      effectiveness: (data as any).effectiveness,
      // Code-computed content numbers: the AI quotes these, never re-derives them.
      contentFacts: (data as any).facts ? (() => { const f = (data as any).facts; return {
        state: f.state, daysCovered: f.daysCovered,
        posts: f.posts.total, postsVsPrevPct: f.posts.vsPrev.pct, byPlatform: f.posts.byPlatform.map((b: any) => ({ platform: b.platform, posts: b.posts, interactions: b.interactions, views: b.views })),
        interactions: f.interactions.total, interactionsVsPrevPct: f.interactions.vsPrev.pct, views: f.views.total,
        topPosts: f.top.map((t: any) => ({ platform: t.platform, type: t.type, interactions: t.interactions, views: t.views, likes: t.likes, comments: t.comments, caption: t.caption })),
      }; })() : null,
      last4Months: history,
      workDone: data.workLog.map((w: any) => ({ category: w.category, title: w.title })),
    };
    const userText = 'DATA (JSON):\n' + JSON.stringify(payload);
    const messages: Array<{ role: 'user' | 'assistant'; content: string }> = [{ role: 'user', content: userText }];
    if (correction) messages.push({ role: 'assistant', content: correction.prior }, { role: 'user', content: correction.note });

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model, max_tokens: 8000, system, messages }),
      });
      if (!res.ok) { const body = (await res.text().catch(() => '')).slice(0, 200); this.logger.warn(`Anthropic ${res.status}: ${body}`); return { error: `Anthropic API ${res.status}: ${body}` }; }
      const json = (await res.json()) as { content?: Array<{ type: string; text?: string }>; stop_reason?: string };
      let text = (json.content || []).filter((b) => b.type === 'text').map((b) => b.text || '').join('').trim();
      // Strip ```json fences the model sometimes adds.
      text = text.replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
      const start = text.indexOf('{'); const end = text.lastIndexOf('}');
      if (start < 0 || end < 0) return { error: 'AI trả về nội dung không đọc được' };
      let content: any;
      try {
        content = JSON.parse(text.slice(start, end + 1));
      } catch {
        // Model output was likely truncated. Report clearly rather than a raw JSON error.
        const cut = json.stop_reason === 'max_tokens' ? ' (bị cắt vì quá dài)' : '';
        return { error: `AI trả về JSON chưa hoàn chỉnh${cut} — bấm Tạo lại` };
      }
      return { content, model, payload };
    } catch (e) {
      this.logger.warn(`AI draft failed: ${String(e)}`);
      return { error: String((e as Error).message).slice(0, 200) };
    }
  }

  // ---- Report lifecycle ---------------------------------------------------
  /** Last N months of headline figures, oldest -> newest, for trend analysis. */
  async monthlyHistory(user: AuthenticatedUser, month: string, tenantParam?: string, count = 4) {
    const [y, m] = month.split('-').map(Number);
    const out: Array<{ month: string; spendCents: number; revenueCents: number; bookings: number; newCustomers: number }> = [];
    for (let i = count - 1; i >= 0; i--) {
      const d = new Date(y, m - 1 - i, 1);
      const mm = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const [ov, spend] = await Promise.all([
        this.overview(user, `${mm}-01`, this.lastDayKeyOf(mm), tenantParam),
        this.prisma.marketingSpend.findMany({ where: { tenantId: this.tenantId(user, tenantParam), periodMonth: mm }, select: { amountCents: true } }),
      ]);
      out.push({ month: mm, spendCents: spend.reduce((a: number, r: { amountCents: number }) => a + r.amountCents, 0), revenueCents: ov.totals.revenueCents, bookings: ov.totals.bookings, newCustomers: ov.newCustomers });
    }
    return out;
  }

  async generateReport(user: AuthenticatedUser, month: string, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    // Reviews are mirrored continuously by the Google Reviews module; refresh the
    // month's figures right before writing so the draft quotes today's rating.
    await this.refreshGbpReviews(tenantId, month).catch(() => undefined);
    const data = await this.monthlyData(user, month, tenantParam);
    const history = await this.monthlyHistory(user, month, tenantParam, 4).catch(() => [] as any[]);
    let ai = await this.draftWithAI(data, history);
    const running = ((data as any).facts as MonthFacts | null | undefined)?.state === 'to-date';
    // Every figure the AI wrote must be in the data it was given, and a month
    // still running may not be written up as an emergency. One correction
    // pass; whatever still strays is marked on the content for the editor.
    let guard: GuardReport | null = null;
    if (ai.content) {
      guard = guardNarrative(ai.content, ai.payload, running);
      if (!guard.ok) {
        const retry = await this.draftWithAI(data, history, { prior: JSON.stringify(ai.content), note: correctionFor(guard) });
        if (retry.content) {
          const g2 = guardNarrative(retry.content, retry.payload, running);
          if (g2.stray.length + g2.alarms.length <= guard.stray.length + guard.alarms.length) { ai = retry; guard = g2; }
        }
      }
    }
    const ok = !!ai.content;
    const rule = this.ruleBasedDraft(data);
    let content: any;
    if (ok) {
      content = ai.content;
      if (guard && !guard.ok) {
        content._guard = { stray: guard.stray, alarms: guard.alarms };
        // An alarm that survived the correction is replaced by the calm,
        // rule-based line; a stray figure is left for a person to see.
        for (const path of guard.alarms) {
          const key = path.split('.')[0] as 'headline' | 'tldr' | 'summary';
          content[key] = rule[key];
        }
      }
      // Backfill any section the AI left empty so the report is never partial.
      const isEmptyArr = (v: any) => !Array.isArray(v) || v.length === 0;
      for (const k of ['highlights', 'issues', 'insights', 'plan', 'channels']) if (isEmptyArr(content[k])) content[k] = rule[k];
      const nm = content.nextMonth;
      const nmEmpty = !nm || (isEmptyArr(nm.content) && isEmptyArr(nm.ads) && isEmptyArr(nm.growth) && isEmptyArr(nm.kpi));
      if (nmEmpty) content.nextMonth = rule.nextMonth;
      if (!content.headline?.vi) content.headline = rule.headline;
      if (!content.tldr?.vi) content.tldr = rule.tldr;
      if (!content.summary?.vi) content.summary = rule.summary;
    } else {
      // No AI (key missing / call failed) — ship the deterministic report so it is NEVER blank.
      content = { ...rule, _aiUnavailable: true, _aiError: ai.error ?? 'unknown' };
    }
    const saved = await this.prisma.marketingReport.upsert({
      where: { tenantId_periodMonth: { tenantId, periodMonth: month } },
      create: { tenantId, periodMonth: month, status: 'review', content, dataSnapshot: data as any, aiModel: ok ? (ai.model ?? null) : null },
      update: { content, dataSnapshot: data as any, aiModel: ok ? (ai.model ?? null) : null, status: 'review' },
    });
    return { ...saved, aiUsed: ok, aiError: ok ? null : ai.error, reportSource: ok ? 'ai' : 'auto' };
  }

  async getReport(user: AuthenticatedUser, month: string, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    return this.prisma.marketingReport.findUnique({ where: { tenantId_periodMonth: { tenantId, periodMonth: month } } });
  }

  async updateReport(user: AuthenticatedUser, month: string, dto: { content: any; tenantId?: string }) {
    const tenantId = this.tenantId(user, dto.tenantId);
    const existing = await this.prisma.marketingReport.findUnique({ where: { tenantId_periodMonth: { tenantId, periodMonth: month } } });
    if (!existing) throw new NotFoundException('Report not generated yet');
    if (existing.status === 'sent') throw new BadRequestException('A sent report cannot be edited');
    return this.prisma.marketingReport.update({ where: { id: existing.id }, data: { content: dto.content, status: existing.status === 'approved' ? 'review' : existing.status } });
  }

  async approveReport(user: AuthenticatedUser, month: string, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    const existing = await this.prisma.marketingReport.findUnique({ where: { tenantId_periodMonth: { tenantId, periodMonth: month } } });
    if (!existing) throw new NotFoundException('Report not generated yet');
    return this.prisma.marketingReport.update({ where: { id: existing.id }, data: { status: 'approved', approvedByUserId: user.userId, approvedAt: new Date() } });
  }

  // ---- Month-end automation ----------------------------------------------

  /** "2026-11" → "2026-10". */
  private monthBefore(month: string): string {
    const [y, m] = month.split('-').map(Number);
    return m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, '0')}`;
  }

  /** "2026-10" → "2026-11". */
  private monthAfter(month: string): string {
    const [y, m] = month.split('-').map(Number);
    return m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`;
  }

  /** The month that has just ended FOR THIS SALON (its own clock, not the server's). */
  private closedMonthFor(tz: string | null | undefined, now = new Date()): string {
    return this.monthBefore(dayKeyTz(now, tz || 'UTC').slice(0, 7));
  }

  /** 'YYYY-MM' for the month before the given date (default: now). */
  private previousMonth(ref = new Date()): string {
    const d = new Date(Date.UTC(ref.getUTCFullYear(), ref.getUTCMonth() - 1, 1));
    return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
  }

  /**
   * Auto-draft last month's report for every active salon that has something to
   * report. Idempotent — a salon whose report already exists is skipped, so
   * running this many times is safe. Reports are left in 'review' so a human
   * always approves before anything reaches a client. A system run acts as a
   * super admin scoped to one explicit tenant, so tenant isolation still holds.
   */
  /**
   * Tell the salon a month-end draft is waiting. Without this the scheduler
   * writes a report nobody knows about. Email goes to the salon's own admins
   * (falling back to the tenant contact email) over the salon's own mail
   * provider — the same chain booking confirmations use. Never throws: a mail
   * problem must not fail the report run.
   */
  private async notifyDraftReady(tenantId: string, month: string) {
    try {
      const [tenant, admins] = await Promise.all([
        this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { name: true, contactEmail: true } }),
        this.prisma.user.findMany({
          where: { tenantId, isActive: true, role: { in: [UserRole.SALON_ADMIN] } },
          select: { email: true },
          take: 5,
        }),
      ]);
      const to = Array.from(new Set([...admins.map((a) => a.email), tenant?.contactEmail ?? ''].filter((e) => !!e && e.includes('@'))));
      if (to.length === 0) return;

      const salon = tenant?.name ?? 'your salon';
      const label = this.monthLabel(month);
      const link = `${publicWebBase()}/salon/marketing/monthly?month=${month}`;
      const subject = `${label} marketing report is drafted — review & approve`;
      const text = `The ${label} marketing report for ${salon} has been drafted automatically and is waiting for your review. Open it, check the numbers, edit if needed, then click Approve: ${link}`;
      const html = `<p>The <strong>${label}</strong> marketing report for <strong>${salon}</strong> has been drafted automatically.</p>`
        + `<p>It is waiting in <em>In review</em> — check the numbers, edit anything you want, then Approve before sending it to the client.</p>`
        + `<p style="margin:16px 0"><a href="${link}" style="background:#6366f1;color:#fff;text-decoration:none;padding:11px 20px;border-radius:8px;font-weight:600">Open the report</a></p>`
        + `<p style="color:#64748b;font-size:13px">Nothing is sent to anyone until you approve it.</p>`;

      const t = await this.mailTransportFor(tenantId, salon);
      await Promise.allSettled(to.map((recipient) => this.notifications.send({
        tenantId,
        channel: NotificationChannel.EMAIL,
        recipient,
        subject,
        body: text,
        html,
        ...t,
        relatedType: 'marketing_report',
        relatedId: month,
      })));
    } catch (e) {
      this.logger.warn(`Draft-ready notice failed for tenant ${tenantId} ${month}: ${String(e)}`);
    }
  }

  /** The salon's own mail provider — the same chain booking confirmations use. */
  private async mailTransportFor(tenantId: string, salon: string) {
    const n = await this.settings.getNotificationSettings(tenantId);
    const senderName = n.senderName || salon;
    const replyTo = n.replyTo || n.senderEmail || undefined;
    const smtp = n.smtp.user && n.smtp.pass
      ? { host: n.smtp.host, port: n.smtp.port, user: n.smtp.user, pass: n.smtp.pass, secure: n.smtp.secure, replyTo: n.replyTo || undefined, from: `${senderName} <${n.senderEmail || n.smtp.user}>` }
      : undefined;
    const brevo = n.brevo.apiKey && n.senderEmail
      ? { apiKey: n.brevo.apiKey, senderEmail: n.senderEmail, replyTo: n.replyTo || undefined, senderName: n.brevo.senderName || senderName }
      : undefined;
    const gmail = n.gmail.clientId && n.gmail.clientSecret && n.gmail.refreshToken && n.gmail.senderEmail
      ? { clientId: n.gmail.clientId, clientSecret: n.gmail.clientSecret, refreshToken: n.gmail.refreshToken, senderEmail: n.gmail.senderEmail, senderName, replyTo }
      : undefined;
    return { smtp, brevo, gmail, mailService: n.mailService, senderName, replyTo };
  }

  /** Who receives the salon's report: its admins, its contact address, and whoever the policy adds. */
  private async reportRecipients(tenantId: string, policy: ReportPolicy): Promise<{ to: string[]; salon: string; market: string | null }> {
    const [tenant, admins] = await Promise.all([
      this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { name: true, contactEmail: true, market: true } }),
      this.prisma.user.findMany({ where: { tenantId, isActive: true, role: { in: [UserRole.SALON_ADMIN] } }, select: { email: true }, take: 5 }),
    ]);
    const to = Array.from(new Set([...admins.map((a) => a.email), tenant?.contactEmail ?? '', ...policy.extraRecipients].map((e) => String(e).trim().toLowerCase()).filter((e) => !!e && e.includes('@'))));
    return { to, salon: tenant?.name ?? 'your salon', market: tenant?.market ?? null };
  }

  // ---- Report policy & lifecycle (report-lifecycle.ts) --------------------

  async getReportPolicy(tenantId: string): Promise<ReportPolicy> {
    const row = await this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: REPORT_POLICY_KEY } } }).catch(() => null);
    return cleanReportPolicy(row?.value ?? {}, DEFAULT_REPORT_POLICY);
  }

  async updateReportPolicy(user: AuthenticatedUser, dto: { autoSend?: unknown; sendDay?: unknown; extraRecipients?: unknown; tenantId?: string }): Promise<ReportPolicy> {
    const tenantId = this.tenantId(user, dto.tenantId);
    const cur = await this.getReportPolicy(tenantId);
    const next = cleanReportPolicy(dto, cur);
    await this.prisma.setting.upsert({
      where: { tenantId_key: { tenantId, key: REPORT_POLICY_KEY } },
      update: { value: next as never },
      create: { tenantId, key: REPORT_POLICY_KEY, value: next as never },
    });
    await this.audit(tenantId, user.userId, 'marketing.report_policy', next);
    return next;
  }

  /** Where the month stands, what happens next, and every send so far. */
  async lifecycle(user: AuthenticatedUser, month: string, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    if (!/^\d{4}-\d{2}$/.test(month || '')) throw new BadRequestException('month must be YYYY-MM');
    const [report, policy, tz] = await Promise.all([
      this.prisma.marketingReport.findUnique({ where: { tenantId_periodMonth: { tenantId, periodMonth: month } }, select: { status: true, approvedAt: true, sentAt: true, createdAt: true, updatedAt: true, content: true } }),
      this.getReportPolicy(tenantId),
      this.tenantTz(tenantId),
    ]);
    const todayKey = dayKeyTz(new Date(), tz || 'UTC');
    const state = lifecycleOf(month, report, todayKey);
    const sends = await this.prisma.notification.findMany({
      where: { tenantId, relatedType: 'marketing_report_sent', relatedId: month },
      orderBy: { createdAt: 'desc' }, take: 10,
      select: { recipient: true, status: true, createdAt: true },
    });
    const guard = (report?.content as { _guard?: unknown } | null)?._guard ?? null;
    return {
      month, state, todayKey, policy,
      nextAction: nextActionOf(state, policy),
      autoSendDue: autoSendDue(month, report, policy, todayKey),
      report: report ? { status: report.status, approvedAt: report.approvedAt, sentAt: report.sentAt, createdAt: report.createdAt, updatedAt: report.updatedAt } : null,
      guard,
      sends: sends.map((n) => ({ recipient: n.recipient, status: n.status, at: n.createdAt })),
    };
  }

  /**
   * Send the month's report to the salon. A draft a person sends is approved
   * by that act. Nothing is sent twice: a sent report is locked. The e-mail
   * carries the headline, the executive summary, the month's key numbers and
   * a link to the full report; every delivery is a Notification row
   * (relatedType 'marketing_report_sent'), which is the send history.
   */
  async sendReport(user: AuthenticatedUser, month: string, tenantParam?: string, opts: { auto?: boolean } = {}) {
    const tenantId = this.tenantId(user, tenantParam);
    const existing = await this.prisma.marketingReport.findUnique({ where: { tenantId_periodMonth: { tenantId, periodMonth: month } } });
    if (!existing) throw new NotFoundException('Report not generated yet');
    if (existing.status === 'sent' || existing.sentAt) throw new BadRequestException('Report already sent');
    const policy = await this.getReportPolicy(tenantId);
    const { to, salon, market } = await this.reportRecipients(tenantId, policy);
    if (!to.length) throw new BadRequestException('No recipient: the salon has no admin e-mail or contact e-mail');
    const vi = market === 'VN';
    const c = (existing.content ?? {}) as Record<string, any>;
    const L = (x: { vi?: string; en?: string } | undefined) => (x ? (vi ? x.vi || x.en : x.en || x.vi) || '' : '');
    const snap = (existing.dataSnapshot ?? {}) as Record<string, any>;
    const facts = snap.facts as MonthFacts | null | undefined;
    const label = this.monthLabel(month);
    const link = `${publicWebBase()}/salon/marketing/monthly?month=${month}`;
    const esc = (x: string) => String(x).replace(/[&<>]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[ch] as string));
    const num = (n: unknown) => (n == null ? '—' : Number(n).toLocaleString(vi ? 'vi-VN' : 'en-US'));
    const kv: Array<[string, string]> = [
      [vi ? 'Lịch hẹn' : 'Bookings', num(snap.outcome?.totals?.bookings)],
      [vi ? 'Khách mới' : 'New customers', num(snap.outcome?.newCustomers)],
      ...(facts ? [[vi ? 'Bài đăng' : 'Posts', num(facts.posts.total)] as [string, string], [vi ? 'Tương tác' : 'Interactions', num(facts.interactions.total)] as [string, string]] : []),
    ];
    const tops = (facts?.top ?? []).slice(0, 3).map((t) => `${t.platform === 'facebook' ? 'FB' : t.platform === 'instagram' ? 'IG' : 'TT'} · ${t.caption || t.type} — ${num(t.views)} ${vi ? 'lượt xem' : 'views'} · ${num(t.interactions)} ${vi ? 'tương tác' : 'interactions'}`);
    const subject = vi ? `Báo cáo marketing ${label} — ${salon}` : `${label} marketing report — ${salon}`;
    const headline = L(c.headline), tldr = L(c.tldr);
    const text = [headline, '', tldr, '', ...kv.map(([k, v]) => `${k}: ${v}`), ...(tops.length ? ['', vi ? 'Bài nổi bật:' : 'Top posts:', ...tops] : []), '', (vi ? 'Xem báo cáo đầy đủ: ' : 'Full report: ') + link].join('\n');
    const html = `<h2 style="margin:0 0 8px">${esc(headline)}</h2><p style="color:#334155">${esc(tldr)}</p>`
      + `<table style="border-collapse:collapse;margin:12px 0">${kv.map(([k, v]) => `<tr><td style="padding:4px 14px 4px 0;color:#64748b">${esc(k)}</td><td style="padding:4px 0;font-weight:700">${esc(v)}</td></tr>`).join('')}</table>`
      + (tops.length ? `<p style="color:#64748b;margin:12px 0 4px">${vi ? 'Bài nổi bật' : 'Top posts'}</p><ul>${tops.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>` : '')
      + `<p style="margin:16px 0"><a href="${link}" style="background:#6366f1;color:#fff;text-decoration:none;padding:11px 20px;border-radius:8px;font-weight:600">${vi ? 'Xem báo cáo đầy đủ' : 'Open the full report'}</a></p>`;
    const t = await this.mailTransportFor(tenantId, salon);
    const results = await Promise.allSettled(to.map((recipient) => this.notifications.send({
      tenantId, channel: NotificationChannel.EMAIL, recipient, subject, body: text, html, ...t,
      relatedType: 'marketing_report_sent', relatedId: month,
    })));
    const delivered = results.filter((r) => r.status === 'fulfilled').length;
    if (!delivered) throw new BadRequestException('E-mail could not be sent — check the salon’s mail settings');
    const saved = await this.prisma.marketingReport.update({
      where: { id: existing.id },
      data: { status: 'sent', sentAt: new Date(), ...(existing.approvedAt ? {} : { approvedAt: new Date(), approvedByUserId: user.userId }) },
    });
    await this.audit(tenantId, user.userId, opts.auto ? 'marketing.report_auto_sent' : 'marketing.report_sent', { month, recipients: to.length, delivered });
    return { ...saved, recipients: to, delivered };
  }

  /** The daily auto-send: every salon whose policy says so, last month's report, on/after its send day. */
  async runAutoSend(now = new Date()): Promise<{ sent: number; failed: number }> {
    const tenants = await this.prisma.tenant.findMany({ where: { status: TenantStatus.ACTIVE, deletedAt: null }, select: { id: true, timezone: true } });
    const sys: AuthenticatedUser = { userId: 'system', email: 'system@lumio.local', role: UserRole.SUPER_ADMIN, tenantId: null };
    let sent = 0, failed = 0;
    for (const t of tenants) {
      const policy = await this.getReportPolicy(t.id);
      if (!policy.autoSend) continue;
      const todayKey = dayKeyTz(now, t.timezone || 'UTC');
      const month = this.closedMonthFor(t.timezone, now);
      const report = await this.prisma.marketingReport.findUnique({ where: { tenantId_periodMonth: { tenantId: t.id, periodMonth: month } }, select: { status: true, sentAt: true, dataSnapshot: true } });
      if (!autoSendDue(month, report, policy, todayKey)) continue;
      // Never send a report written while the month was still running (opened
      // mid-month): month close redrafts it with the whole month first.
      if (reportIsPartial(report?.dataSnapshot)) { this.logger.warn(`auto-send ${t.id} ${month}: report holds a mid-month snapshot — waiting for the month-end redraft`); continue; }
      try { await this.sendReport(sys, month, t.id, { auto: true }); sent++; }
      catch (e) { failed++; this.logger.warn(`auto-send ${t.id} ${month}: ${String((e as Error)?.message ?? e)}`); }
    }
    return { sent, failed };
  }

  private monthLabel(month: string): string {
    const [y, m] = month.split('-').map((x) => parseInt(x, 10));
    if (!y || !m) return month;
    return new Date(Date.UTC(y, m - 1, 1)).toLocaleDateString('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' });
  }

  /**
   * What the salon sees on the report page: is month-end auto-drafting on, and
   * where does each of the last few months stand. Derived from real rows — no
   * "last run" bookkeeping to drift out of sync.
   */
  async autoReportStatus(user: AuthenticatedUser, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    const enabled = (process.env.MARKETING_AUTOREPORT_ENABLED ?? (process.env.NODE_ENV === 'production' ? 'true' : 'false')) === 'true';
    const months: string[] = [];
    const now = new Date();
    for (let i = 1; i <= 3; i++) {
      const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
      months.push(`${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`);
    }
    const rows = await this.prisma.marketingReport.findMany({
      where: { tenantId, periodMonth: { in: months } },
      select: { periodMonth: true, status: true, createdAt: true, approvedAt: true, sentAt: true },
    });
    const byMonth = new Map(rows.map((r) => [r.periodMonth, r]));
    const lastNotice = await this.prisma.notification.findFirst({
      where: { tenantId, relatedType: 'marketing_report' },
      orderBy: { createdAt: 'desc' },
      select: { relatedId: true, recipient: true, status: true, createdAt: true },
    });
    return {
      enabled,
      // The scheduler drafts LAST month during the first 5 days of a month.
      months: months.map((m) => {
        const r = byMonth.get(m);
        return {
          month: m,
          label: this.monthLabel(m),
          status: r?.status ?? null,
          createdAt: r?.createdAt ?? null,
          approvedAt: r?.approvedAt ?? null,
          sentAt: r?.sentAt ?? null,
        };
      }),
      lastNotice: lastNotice
        ? { month: lastNotice.relatedId, recipient: lastNotice.recipient, status: lastNotice.status, at: lastNotice.createdAt }
        : null,
    };
  }

  async runMonthlyAutoGenerate(targetMonth?: string, now = new Date()) {
    const utcMonth = this.previousMonth(now);
    const tenants = await this.prisma.tenant.findMany({
      where: { status: TenantStatus.ACTIVE, deletedAt: null },
      select: { id: true, timezone: true },
    });
    const sys: AuthenticatedUser = { userId: 'system', email: 'system@lumio.local', role: UserRole.SUPER_ADMIN, tenantId: null };
    let generated = 0, skipped = 0, failed = 0;

    for (const t of tenants) {
      const tz = t.timezone || 'UTC';
      // The month that ended on the SALON's clock. Early on the 1st (UTC) a US
      // salon is still in the last day of the month — wait for its midnight
      // instead of drafting a month that still has an evening of visits to come.
      const month = targetMonth ?? this.closedMonthFor(tz, now);
      if (!targetMonth && month !== utcMonth) { skipped++; continue; }
      const existing = await this.prisma.marketingReport.findUnique({
        where: { tenantId_periodMonth: { tenantId: t.id, periodMonth: month } },
      });
      // A draft written while the month was still running (someone opened it on
      // the 12th) is redrafted with the whole month; anything approved, sent or
      // drafted after the month closed is left alone.
      const stale = !!existing && existing.status === 'review' && reportIsPartial(existing.dataSnapshot);
      if (existing && !stale) { skipped++; continue; }
      const from = startOfDayTz(`${month}-01`, tz);
      const to = new Date(startOfDayTz(`${this.monthAfter(month)}-01`, tz).getTime() - 1);
      // Only draft where there is real activity — never an empty report.
      const [spendCount, apptCount] = await Promise.all([
        this.prisma.marketingSpend.count({ where: { tenantId: t.id, periodMonth: month } }),
        this.prisma.appointment.count({ where: { tenantId: t.id, startTime: { gte: from, lte: to } } }),
      ]);
      if (spendCount === 0 && apptCount === 0) { skipped++; continue; }
      try {
        // Pull spend/metrics from any connected API channels first, so the
        // auto-drafted report reflects real platform numbers. A failing channel
        // never blocks the report — its error is recorded on the connection.
        await this.syncAllChannels(sys, t.id, month).catch(() => undefined);
        await this.generateReport(sys, month, t.id);
        await this.notifyDraftReady(t.id, month);
        generated++;
      } catch (e) {
        failed++;
        this.logger.warn(`Auto-report failed for tenant ${t.id} ${month}: ${String(e)}`);
      }
    }
    const month = targetMonth ?? utcMonth;
    this.logger.log(`Auto-report ${month}: generated ${generated}, skipped ${skipped}, failed ${failed}.`);
    return { month, generated, skipped, failed };
  }

  // ======================= PHASE 3: social/ads API channels =================

  /** List every platform (incl. scaffolds) with this tenant's connection status. */
  async listChannels(user: AuthenticatedUser, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    const conns = (await this.prisma.marketingChannelConnection.findMany({ where: { tenantId } })) as any[];
    const byPlatform = new Map<string, any>(conns.map((c: any) => [c.platform, c]));
    const out = [] as any[];
    for (const p of this.social.list()) {
      const c = byPlatform.get(p.platform);
      // No explicit connection? Check whether another screen already covers it,
      // and SAY SO — the green tick must explain where it came from, and the
      // page must stop asking the owner to connect a thing they connected.
      const linkedRaw = c?.status === 'ACTIVE' ? null : await this.linkedCreds(tenantId, p.platform);
      const src = credsSource(c?.status ?? null, Boolean(linkedRaw));
      const linked = src === 'linked' ? linkedRaw : null;
      const own = src === 'explicit' ? c : null;
      out.push({
        ...p,
        connected: (!!own && own.status === 'ACTIVE') || !!linked,
        status: own?.status ?? (linked ? 'ACTIVE' : null),
        accountName: own?.accountName ?? linked?.accountName ?? null,
        externalAccountId: own?.externalAccountId ?? linked?.creds.externalAccountId ?? null,
        // 'LINKED:<source>' — the UI keys off this to show "đang dùng kết nối
        // ở Kết nối kênh social" instead of a token form.
        keyHint: own?.keyHint ?? (linked ? `LINKED:${linked.source}` : null),
        lastSyncedAt: c?.lastSyncedAt ?? null,
        // A linked channel's last failure is still worth showing (it is stored
        // on the old row), but only when that row is the one in use.
        lastError: own?.lastError ?? null,
      });
    }
    return out;
  }

  async connectChannel(user: AuthenticatedUser, dto: { platform: string; externalAccountId?: string; token?: string; refreshToken?: string; clientId?: string; clientSecret?: string; developerToken?: string; tenantId?: string }) {
    const tenantId = this.tenantId(user, dto.tenantId);
    const connector = this.social.get(dto.platform); // throws if unknown/disabled
    const own: ChannelCreds = {
      token: dto.token?.trim() || undefined,
      refreshToken: dto.refreshToken?.trim() || undefined,
      clientId: dto.clientId?.trim() || undefined,
      clientSecret: dto.clientSecret?.trim() || undefined,
      developerToken: dto.developerToken?.trim() || undefined,
      externalAccountId: dto.externalAccountId?.trim() || undefined,
    };
    // No secret pasted? Fall back to the shared agency token — the salon only
    // supplies its account id. We then store NO per-tenant secret at all.
    const shared = !own.token && !own.refreshToken ? this.agencyCreds(dto.platform) : null;
    // Encryption key is only needed when we must STORE a per-tenant secret.
    if (!shared && !encConfigured()) throw new BadRequestException('PAYMENT_ENC_KEY not configured on the server');
    const creds: ChannelCreds = shared ? ({ ...shared, externalAccountId: own.externalAccountId } as ChannelCreds) : own;
    const verify = await connector.verify(creds);
    if (!verify.ok) throw new BadRequestException(verify.error || 'Could not verify the credentials with the platform');
    const hint = shared ? 'AGENCY' : maskHint(creds.token || creds.refreshToken || '');
    const data = {
      externalAccountId: creds.externalAccountId ?? null,
      accountName: verify.accountName ?? null,
      credentialEnc: shared ? null : encryptSecret(JSON.stringify(creds)),
      keyHint: hint,
      status: 'ACTIVE',
      lastError: null,
    };
    const saved = await this.prisma.marketingChannelConnection.upsert({
      where: { tenantId_platform: { tenantId, platform: dto.platform } },
      create: { tenantId, platform: dto.platform, ...data },
      update: data,
    });
    await this.audit(tenantId, user.userId, 'marketing.channel.connect', { platform: dto.platform });
    return this.channelView(saved);
  }

  async testChannel(user: AuthenticatedUser, platform: string, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    const { creds, linked } = await this.resolveCreds(tenantId, platform);
    const r = await this.social.get(platform).verify(creds);
    if (!linked) await this.prisma.marketingChannelConnection.updateMany({ where: { tenantId, platform }, data: { status: r.ok ? 'ACTIVE' : 'ERROR', lastError: r.ok ? null : (r.error ?? 'error') } });
    return r;
  }

  /** "Chẩn đoán": what Meta lets this salon's connection read, edge by edge. No secrets in the answer. */
  async diagnoseChannel(user: AuthenticatedUser, platform: string, month: string, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    const { creds, linked } = await this.resolveCreds(tenantId, platform);
    const connector = this.social.get(platform);
    if (!connector.diagnose) return { error: 'Kênh này chưa có chẩn đoán.' };
    const m = /^\d{4}-\d{2}$/.test(month || '') ? month : new Date().toISOString().slice(0, 7);
    const r = await connector.diagnose(creds, m);
    return { ...r, linked, tokenSource: creds.token && creds.token === this.agencyCreds(platform)?.token ? 'agency' : 'own' };
  }

  async disconnectChannel(user: AuthenticatedUser, platform: string) {
    const tenantId = this.tenantId(user);
    await this.prisma.marketingChannelConnection.updateMany({ where: { tenantId, platform }, data: { status: 'REVOKED', credentialEnc: null } });
    await this.audit(tenantId, user.userId, 'marketing.channel.disconnect', { platform });
    return { ok: true };
  }

  /** Pull last-month figures from the platform API into the spend table. */
  /**
   * Google review stats for a month, computed from the reviews the Google
   * Reviews module already mirrors into our own table. That module holds the
   * business.manage OAuth, so nothing extra has to be approved here — and the
   * numbers are real rows, not a typed-in guess.
   *
   * Returns null when nothing has been mirrored (salon has not connected review
   * sync), so a salon's manually entered numbers are left alone.
   */
  private async gbpReviewStats(tenantId: string, month: string) {
    // The salon's month: a review written at 9 pm on the 31st in Austin is that month's.
    if (!/^\d{4}-\d{2}$/.test(month || '')) throw new BadRequestException('month must be YYYY-MM');
    const tz = await this.tzOf(tenantId);
    const from = startOfDayTz(`${month}-01`, tz);
    const to = new Date(startOfDayTz(`${this.monthAfter(month)}-01`, tz).getTime() - 1);
    const rows = await this.prisma.googleReview.findMany({
      where: { tenantId },
      select: { starRating: true, reviewCreatedAt: true, createdAt: true, reviewerName: true, comment: true },
      orderBy: [{ reviewCreatedAt: 'desc' }, { createdAt: 'desc' }],
      take: 5000,
    });
    if (rows.length === 0) return null;
    const at = (r: { reviewCreatedAt: Date | null; createdAt: Date }) => r.reviewCreatedAt ?? r.createdAt;
    // Everything that existed by the end of the reported month — a June report
    // must not include a July review.
    const upto = rows.filter((r) => at(r) <= to);
    const count = upto.length;
    const rating = count > 0 ? Math.round((upto.reduce((sum, r) => sum + (r.starRating || 0), 0) / count) * 10) / 10 : null;
    const inMonth = rows.filter((r) => at(r) >= from && at(r) <= to);
    return {
      rating,
      count: count || null,
      newThisMonth: inMonth.length,
      badCount: inMonth.filter((r) => (r.starRating || 0) <= 2).length,
      recent: inMonth.slice(0, 3).map((r) => ({
        author: r.reviewerName ?? '',
        rating: r.starRating || 0,
        comment: (r.comment ?? '').slice(0, 300),
        time: at(r).toISOString(),
      })),
      manual: false,
      source: 'google_reviews',
      syncedAt: new Date().toISOString(),
    };
  }

  /**
   * Refresh the review block of a month's GBP snapshot from mirrored reviews.
   * Runs on every month-end sync, independent of whether the GBP Performance
   * API is connected. A salon's manual numbers win — clearing them (saving all
   * four fields empty) hands the month back to the automatic figures.
   */
  async refreshGbpReviews(tenantId: string, month: string): Promise<{ updated: boolean }> {
    const auto = await this.gbpReviewStats(tenantId, month);
    if (!auto) return { updated: false };
    const existing = await this.prisma.socialInsight.findUnique({
      where: { tenantId_platform_periodMonth: { tenantId, platform: 'gbp', periodMonth: month } },
    });
    const raw: any = (existing?.raw as any) ?? {};
    if (raw?.gbp?.reviews?.manual === true) return { updated: false };
    raw.gbp = raw.gbp ?? {};
    raw.gbp.reviews = auto;
    await this.prisma.socialInsight.upsert(jsonSafe({
      where: { tenantId_platform_periodMonth: { tenantId, platform: 'gbp', periodMonth: month } },
      create: { tenantId, platform: 'gbp', periodMonth: month, raw, source: 'api', syncedAt: new Date() },
      update: { raw },
    }));
    return { updated: true };
  }

  async syncChannel(user: AuthenticatedUser, platform: string, month: string, tenantParam?: string) {
    // Organic owned-channel (Facebook Page + IG) uses a different pull + store.
    if (platform === 'meta_social' || platform === 'tiktok') return this.syncOrganic(user, platform, month, tenantParam);
    const tenantId = this.tenantId(user, tenantParam);
    if (!/^\d{4}-\d{2}$/.test(month || '')) throw new BadRequestException('month must be YYYY-MM');
    const connector = this.social.get(platform);
    const { creds, linked } = await this.resolveCreds(tenantId, platform);
    try {
      const m = await connector.fetchMonthly(creds, month);
      // Map platform metrics onto the manual spend row (source='api'), so a synced
      // number simply replaces what a human would have typed. Nothing invented.
      const reach = m.reach ?? m.impressions ?? null;
      const leads = m.leads ?? m.calls ?? null;
      await this.prisma.marketingSpend.upsert({
        where: { tenantId_channel_periodMonth: { tenantId, channel: platform, periodMonth: month } },
        create: { tenantId, channel: platform, periodMonth: month, amountCents: m.spendCents ?? 0, reach, clicks: m.clicks ?? null, leads, source: 'api', createdByUserId: user.userId, note: 'Auto-synced' },
        update: { amountCents: m.spendCents ?? 0, reach, clicks: m.clicks ?? null, leads, source: 'api', note: 'Auto-synced' },
      });
      // Google Business Profile: also store a rich monthly snapshot (for the GBP deck).
      if (platform === 'gbp' && m.raw && (m.raw as any).gbp) {
        const g = (m.raw as any).gbp;
        // Keep the review block: the Performance API does not return reviews, so
        // overwriting raw wholesale would erase what review sync (or a human) put there.
        const prev = await this.prisma.socialInsight.findUnique({
          where: { tenantId_platform_periodMonth: { tenantId, platform: 'gbp', periodMonth: month } },
        });
        const prevReviews = (prev?.raw as any)?.gbp?.reviews ?? null;
        const autoReviews = prevReviews?.manual === true ? null : await this.gbpReviewStats(tenantId, month);
        g.reviews = autoReviews ?? prevReviews ?? null;
        const actions = (g.calls ?? 0) + (g.directions ?? 0) + (g.websiteClicks ?? 0) + (g.bookings ?? 0) + (g.conversations ?? 0);
        const gdata = {
          followers: g.impressions ?? null,   // repurposed so the monthly-series machinery charts impressions
          reach: g.impressions ?? null, views: g.websiteClicks ?? null, engagement: actions,
          raw: { gbp: g } as any, syncedAt: new Date(),
        };
        await this.prisma.socialInsight.upsert(jsonSafe({
          where: { tenantId_platform_periodMonth: { tenantId, platform: 'gbp', periodMonth: month } },
          create: { tenantId, platform: 'gbp', periodMonth: month, ...gdata },
          update: gdata,
        }));
      }
      // A sync that ran on the LINKED connection must not mark an old,
      // failing row on this page ACTIVE — that row would then win next time
      // and fail again. It only records when the numbers last came in.
      await this.prisma.marketingChannelConnection.updateMany({ where: { tenantId, platform }, data: linked ? { lastSyncedAt: new Date(), lastError: null } : { lastSyncedAt: new Date(), status: 'ACTIVE', lastError: null } });
      await this.audit(tenantId, user.userId, 'marketing.channel.sync', { platform, month });
      return { ok: true, platform, month, metrics: m };
    } catch (e) {
      await this.prisma.marketingChannelConnection.updateMany({ where: { tenantId, platform }, data: linked ? { lastError: String((e as Error).message).slice(0, 300) } : { status: 'ERROR', lastError: String((e as Error).message).slice(0, 300) } });
      throw new BadRequestException(String((e as Error).message));
    }
  }

  /**
   * Pull last-month ORGANIC Facebook Page + linked Instagram numbers
   * (platform 'meta_social') into the social_insights table — one row per
   * network. Zero fabrication: whatever the API omits stays null. A failing
   * pull is recorded on the connection and never blocks the report.
   */
  async syncOrganic(user: AuthenticatedUser, platform: string, month: string, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    if (!/^\d{4}-\d{2}$/.test(month || '')) throw new BadRequestException('month must be YYYY-MM');
    const connector = this.social.get(platform);
    if (!connector.fetchOrganic) throw new BadRequestException(`${platform} does not support organic insights`);
    const { creds, linked } = await this.resolveCreds(tenantId, platform);
    // Count the month in the salon's own clock (marketing/month-window.ts).
    creds.timezone = await this.tenantTz(tenantId);
    try {
      const res = await connector.fetchOrganic(creds, month);
      const rows: Array<{ ch: string; m: any }> = [];
      if (res.facebook) rows.push({ ch: 'facebook', m: res.facebook });
      if (res.instagram) rows.push({ ch: 'instagram', m: res.instagram });
      if (res.tiktok) rows.push({ ch: 'tiktok', m: res.tiktok });
      for (const { ch, m } of rows) {
        // Every post the network listed becomes/updates a social_posts row —
        // the report's counts come from there, not from this month's upsert.
        if (this.socialPosts && (ch === 'facebook' || ch === 'instagram' || ch === 'tiktok')) {
          await this.socialPosts.record(tenantId, ch, m.posts ?? [], creds.timezone ?? null).catch((e: Error) => this.logger.warn(`social_posts (${tenantId}/${ch}): ${e.message}`));
        }
        const data = {
          followers: m.followers ?? null,
          newFollowers: m.newFollowers ?? null,
          reach: m.reach ?? null,
          views: m.views ?? null,
          engagement: m.engagement ?? null,
          profileViews: m.profileViews ?? null,
          postsCount: m.postsCount ?? null,
          raw: { ...((m.raw as Record<string, unknown>) ?? {}), posts: m.posts ?? [], series: m.series ?? [], audience: m.audience ?? null } as any,
          source: 'api',
          syncedAt: new Date(),
        };
        await this.prisma.socialInsight.upsert(jsonSafe({
          where: { tenantId_platform_periodMonth: { tenantId, platform: ch, periodMonth: month } },
          create: { tenantId, platform: ch, periodMonth: month, ...data },
          update: data,
        }));
      }
      // A sync that ran on the LINKED connection must not mark an old,
      // failing row on this page ACTIVE — that row would then win next time
      // and fail again. It only records when the numbers last came in.
      await this.prisma.marketingChannelConnection.updateMany({ where: { tenantId, platform }, data: linked ? { lastSyncedAt: new Date(), lastError: null } : { lastSyncedAt: new Date(), status: 'ACTIVE', lastError: null } });
      await this.audit(tenantId, user.userId, 'marketing.channel.syncOrganic', { platform, month, channels: rows.map((r) => r.ch) });
      return { ok: true, platform, month, channels: rows.map((r) => ({ platform: r.ch, ...r.m })) };
    } catch (e) {
      await this.prisma.marketingChannelConnection.updateMany({ where: { tenantId, platform }, data: linked ? { lastError: String((e as Error).message).slice(0, 300) } : { status: 'ERROR', lastError: String((e as Error).message).slice(0, 300) } });
      throw new BadRequestException(String((e as Error).message));
    }
  }

  /**
   * "Đồng bộ tất cả": every channel this salon has connected anywhere in the
   * product, for one month, in one go. Best-effort — a failing channel is
   * reported and recorded on its connection, never blocks the others — and a
   * channel that was never connected is skipped, not an error.
   */
  async syncAllChannels(user: AuthenticatedUser, tenantId: string, month: string): Promise<{ synced: number; lines: SyncAllLine[]; reviews: boolean }> {
    if (!/^\d{4}-\d{2}$/.test(month || '')) throw new BadRequestException('month must be YYYY-MM');
    const conns = (await this.prisma.marketingChannelConnection.findMany({ where: { tenantId } })) as any[];
    const byPlatform = new Map<string, any>(conns.map((c: any) => [String(c.platform), c]));
    const lines: SyncAllLine[] = [];
    let synced = 0;
    for (const meta of this.social.list()) {
      if (!meta.enabled) continue;
      const c = byPlatform.get(meta.platform);
      const linked = c?.status === 'ACTIVE' ? null : await this.linkedCreds(tenantId, meta.platform);
      if (credsSource(c?.status ?? null, Boolean(linked)) === 'none') {
        lines.push({ platform: meta.platform, label: meta.label, state: 'skipped', message: 'not-connected' });
        continue;
      }
      try {
        if (meta.platform === 'meta_social' || meta.platform === 'tiktok') await this.syncOrganic(user, meta.platform, month, tenantId);
        else await this.syncChannel(user, meta.platform, month, tenantId);
        synced++;
        lines.push({ platform: meta.platform, label: meta.label, state: 'synced', message: null });
      } catch (e) {
        lines.push({ platform: meta.platform, label: meta.label, state: 'error', message: String((e as Error)?.message ?? e).slice(0, 200) });
      }
    }
    // Reviews live in their own module (own OAuth), so refresh them whether or
    // not the GBP Performance channel is connected.
    const reviews = await this.refreshGbpReviews(tenantId, month).then((r) => r.updated).catch(() => false);
    return { synced, lines, reviews };
  }

  /** The button on the report screen: this salon, this month. */
  async syncAllForUser(user: AuthenticatedUser, month: string, tenantParam?: string) {
    const tenantId = this.tenantId(user, tenantParam);
    const r = await this.syncAllChannels(user, tenantId, month);
    await this.audit(tenantId, user.userId, 'marketing.channel.syncAll', { month, synced: r.synced });
    return { month, ...r, at: new Date().toISOString() };
  }

  /**
   * Every active salon, one month — the daily background run and the agency's
   * "sync the whole system" action. Salons with nothing connected cost one
   * query each and are skipped.
   */
  async syncAllTenants(month?: string): Promise<{ month: string; tenants: number; synced: number; failed: number }> {
    // The daily run, in the first 3 days of a month, also re-reads the month
    // that just ended: its last day(s) were posted after the last daily read,
    // and a salon whose report was already drafted was never read again — its
    // month stayed short of the posts made at the end.
    if (!month && new Date().getUTCDate() <= 3) {
      const d = new Date(); d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth() - 1);
      await this.syncAllTenants(d.toISOString().slice(0, 7)).catch(() => undefined);
    }
    const m = month && /^\d{4}-\d{2}$/.test(month) ? month : new Date().toISOString().slice(0, 7);
    const tenants = await this.prisma.tenant.findMany({ where: { status: TenantStatus.ACTIVE, deletedAt: null }, select: { id: true } });
    const sys: AuthenticatedUser = { userId: 'system', email: 'system@lumio.local', role: UserRole.SUPER_ADMIN, tenantId: null };
    let synced = 0, failed = 0;
    for (const t of tenants) {
      try {
        const r = await this.syncAllChannels(sys, t.id, m);
        synced += r.synced;
        failed += r.lines.filter((l) => l.state === 'error').length;
      } catch (e) {
        failed++;
        this.logger.warn(`sync-all ${t.id} ${m}: ${String((e as Error)?.message ?? e)}`);
      }
    }
    return { month: m, tenants: tenants.length, synced, failed };
  }

  /**
   * Manually entered social numbers for a month (e.g. TikTok before its API is
   * approved). Stored exactly like a synced row (source='manual') so it flows into
   * the report card, month-over-month deltas and the AI analysis with no special-casing.
   * The period is the whole calendar month selected — 1st to last day.
   */
  async saveSocialManual(user: AuthenticatedUser, dto: { platform: string; month: string; followers?: number | null; newFollowers?: number | null; views?: number | null; engagement?: number | null; postsCount?: number | null; notes?: string | null; tenantId?: string }) {
    const tenantId = this.tenantId(user, dto.tenantId);
    if (!/^\d{4}-\d{2}$/.test(dto.month || '')) throw new BadRequestException('month must be YYYY-MM');
    if (!dto.platform) throw new BadRequestException('platform is required');
    const n = (v: any) => (v == null || v === '' || Number.isNaN(Number(v)) ? null : Number(v));
    const data = {
      followers: n(dto.followers), newFollowers: n(dto.newFollowers),
      reach: null as number | null, views: n(dto.views), engagement: n(dto.engagement),
      profileViews: null as number | null, postsCount: n(dto.postsCount),
      raw: { manual: true, notes: dto.notes ?? null } as any,
      source: 'manual', syncedAt: new Date(),
    };
    const saved = await this.prisma.socialInsight.upsert(jsonSafe({
      where: { tenantId_platform_periodMonth: { tenantId, platform: dto.platform, periodMonth: dto.month } },
      create: { tenantId, platform: dto.platform, periodMonth: dto.month, ...data },
      update: data,
    }));
    await this.audit(tenantId, user.userId, 'marketing.social.manual', { platform: dto.platform, month: dto.month });
    return { ok: true, platform: dto.platform, month: dto.month, id: (saved as any).id };
  }

  /**
   * Manually entered Google Business Profile reviews for a month (rating, total,
   * new this month, bad reviews). Merged into the gbp snapshot's raw WITHOUT
   * overwriting the synced Maps metrics. Used until the Google reviews API is on.
   */
  async saveGbpReviews(user: AuthenticatedUser, dto: { month: string; rating?: number | null; totalReviews?: number | null; newReviews?: number | null; badReviews?: number | null; tenantId?: string }) {
    const tenantId = this.tenantId(user, dto.tenantId);
    if (!/^\d{4}-\d{2}$/.test(dto.month || '')) throw new BadRequestException('month must be YYYY-MM');
    const n = (v: any) => (v == null || v === '' || Number.isNaN(Number(v)) ? null : Number(v));
    const existing = await this.prisma.socialInsight.findUnique({ where: { tenantId_platform_periodMonth: { tenantId, platform: 'gbp', periodMonth: dto.month } } });
    const raw: any = (existing?.raw as any) ?? {};
    raw.gbp = raw.gbp ?? {};
    const vals = [n(dto.rating), n(dto.totalReviews), n(dto.newReviews), n(dto.badReviews)];
    if (vals.every((v) => v == null)) {
      // All fields cleared = "stop overriding": fall back to the automatic
      // figures derived from mirrored Google reviews (null if none mirrored).
      raw.gbp.reviews = (await this.gbpReviewStats(tenantId, dto.month)) ?? null;
    } else {
      raw.gbp.reviews = { rating: vals[0], count: vals[1], newThisMonth: vals[2], badCount: vals[3], manual: true };
    }
    await this.prisma.socialInsight.upsert(jsonSafe({
      where: { tenantId_platform_periodMonth: { tenantId, platform: 'gbp', periodMonth: dto.month } },
      create: { tenantId, platform: 'gbp', periodMonth: dto.month, raw, source: 'manual', syncedAt: new Date() },
      update: { raw },
    }));
    await this.audit(tenantId, user.userId, 'marketing.gbp.reviews', { month: dto.month });
    return { ok: true, month: dto.month };
  }

  /**
   * Shared AGENCY credentials from env. Lumio Agency runs the ads for every
   * salon from its own Business Manager, so ONE token can read all managed ad
   * accounts. A salon connection then only needs the account id — no token
   * pasted per tenant, and rotating the env token updates everyone at once.
   *   META_AGENCY_TOKEN                      (system-user token, ads_read)
   *   GBP_AGENCY_CLIENT_ID / _CLIENT_SECRET / _REFRESH_TOKEN
   */
  private agencyCreds(platform: string): Partial<ChannelCreds> | null {
    if ((platform === 'meta' || platform === 'meta_social') && process.env.META_AGENCY_TOKEN) return { token: process.env.META_AGENCY_TOKEN };
    if (platform === 'gbp' && process.env.GBP_AGENCY_REFRESH_TOKEN && process.env.GBP_AGENCY_CLIENT_ID && process.env.GBP_AGENCY_CLIENT_SECRET) {
      return { refreshToken: process.env.GBP_AGENCY_REFRESH_TOKEN, clientId: process.env.GBP_AGENCY_CLIENT_ID, clientSecret: process.env.GBP_AGENCY_CLIENT_SECRET };
    }
    if (platform === 'tiktok' && process.env.TIKTOK_AGENCY_CLIENT_KEY && process.env.TIKTOK_AGENCY_CLIENT_SECRET) {
      // TikTok app key/secret are agency-level; each salon stores only its own refresh token.
      return { clientId: process.env.TIKTOK_AGENCY_CLIENT_KEY, clientSecret: process.env.TIKTOK_AGENCY_CLIENT_SECRET };
    }
    return null;
  }

  /**
   * Credentials another screen of this product already holds.
   *
   * meta_social rides on Messenger AI's Page connection; gbp rides on the
   * Google Reviews OAuth (same business.manage scope the Performance API
   * needs). The decision logic is pure and tested in linked-channels.ts —
   * this method only fetches the two rows and hands them over.
   */
  private async linkedCreds(tenantId: string, platform: string): Promise<LinkedCreds | null> {
    if (!(LINKABLE_PLATFORMS as readonly string[]).includes(platform)) return null;
    try {
      if (platform === 'meta_social') {
        // Prefer the per-page row (multi-page salons); the connection row is
        // the fallback for salons connected before messengerPage existed.
        const pg = await this.prisma.messengerPage.findFirst({
          where: { tenantId }, orderBy: { createdAt: 'asc' },
          select: { pageId: true, pageToken: true, pageName: true },
        } as never).catch(() => null) as { pageId?: string; pageToken?: string; pageName?: string } | null;
        const conn = pg?.pageToken ? null : await this.prisma.messengerConnection.findUnique({
          where: { tenantId }, select: { pageId: true, pageToken: true, pageName: true },
        } as never).catch(() => null) as { pageId?: string; pageToken?: string; pageName?: string } | null;
        const src = pg?.pageToken ? pg : conn;
        return linkedCredsFor(platform, { messenger: src ?? null });
      }
      // gbp — the reviews module's settings row, plus the app client pair from
      // env (the same pair the reviews OAuth itself used).
      const row = await this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: 'googleReviews' } } }).catch(() => null);
      const v = (row?.value ?? {}) as { connected?: boolean; refreshToken?: string; locationId?: string; locationTitle?: string };
      return linkedCredsFor(platform, {
        gbr: {
          ...v,
          clientId: process.env.GBP_CLIENT_ID || process.env.GOOGLE_CLIENT_ID || '',
          clientSecret: process.env.GBP_CLIENT_SECRET || process.env.GOOGLE_CLIENT_SECRET || '',
        },
      });
    } catch {
      return null;
    }
  }

  private async loadChannelCreds(tenantId: string, platform: string): Promise<ChannelCreds> {
    return (await this.resolveCreds(tenantId, platform)).creds;
  }

  /** The credentials to use, and whether they are the linked ones. */
  /** The salon's timezone, or null (then months are UTC, as before). */
  private async tenantTz(tenantId: string): Promise<string | null> {
    try {
      return (await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }))?.timezone ?? null;
    } catch { return null; }
  }

  private async resolveCreds(tenantId: string, platform: string): Promise<{ creds: ChannelCreds; linked: boolean }> {
    const conn = await this.prisma.marketingChannelConnection.findUnique({ where: { tenantId_platform: { tenantId, platform } } });
    // Precedence lives in credsSource (linked-channels.ts): an ACTIVE row here
    // wins; otherwise the connection made on "Kết nối kênh social"; a failing
    // row here is only retried when nothing else exists.
    const linked = conn?.status === 'ACTIVE' ? null : await this.linkedCreds(tenantId, platform);
    const src = credsSource(conn?.status ?? null, Boolean(linked));
    if (src === 'linked' && linked) {
      // Riding on the Messenger Page token: it reads the Page, but insights
      // may need the agency token's permissions — offered as a second try.
      const agency = platform === 'meta_social' ? this.agencyCreds(platform)?.token : undefined;
      return { creds: { ...linked.creds, ...(agency ? { fallbackToken: agency } : {}) }, linked: true };
    }
    if (src === 'none' || !conn) throw new NotFoundException('Channel not connected');
    // No per-tenant secret stored -> the connection rides on the agency token.
    if (!conn.credentialEnc) {
      const shared = this.agencyCreds(platform);
      if (!shared) throw new NotFoundException('Channel not connected (agency token missing on server)');
      return { creds: await this.withPageFallback(tenantId, platform, { ...shared, externalAccountId: conn.externalAccountId ?? undefined } as ChannelCreds), linked: false };
    }
    const stored = JSON.parse(decryptSecret(conn.credentialEnc)) as ChannelCreds;
    // TikTok stores only the salon refresh token; backfill the agency app key/secret from env.
    const shared = this.agencyCreds(platform);
    return { creds: await this.withPageFallback(tenantId, platform, { ...(shared ?? {}), ...stored } as ChannelCreds), linked: false };
  }

  /**
   * An explicit meta_social row (often riding on the agency token) wins over
   * the salon's own Page connection — but the agency token may not hold the
   * Instagram insights permission, while a Page connection made after
   * FB_SCOPE_INSIGHTS was switched on does. So the salon's own Page token is
   * offered as the second try. Same tenant only: it is read by tenantId.
   */
  private async withPageFallback(tenantId: string, platform: string, creds: ChannelCreds): Promise<ChannelCreds> {
    if (platform !== 'meta_social' || creds.fallbackToken) return creds;
    const own = await this.linkedCreds(tenantId, platform).catch(() => null);
    const tk = own?.creds?.token;
    return tk && tk !== creds.token ? { ...creds, fallbackToken: tk } : creds;
  }

  private channelView(c: any) {
    return { platform: c.platform, status: c.status, accountName: c.accountName, externalAccountId: c.externalAccountId, keyHint: c.keyHint, lastSyncedAt: c.lastSyncedAt, lastError: c.lastError };
  }

  private async audit(tenantId: string, userId: string | null, action: string, meta: any) {
    try { await this.prisma.auditLog.create({ data: { tenantId, userId: userId ?? undefined, action, resourceType: 'marketing', metadata: meta as any } }); } catch { /* never break */ }
  }
}
