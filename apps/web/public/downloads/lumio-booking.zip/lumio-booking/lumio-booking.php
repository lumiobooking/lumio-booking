<?php
/**
 * Plugin Name:       Lumio Booking
 * Plugin URI:        https://lumiobooking.com
 * Description:        Embed your salon's Lumio booking form on WordPress AND manage everything (dashboard, calendar, bookings) right inside wp-admin. Configure the booking URL + salon slug under Lumio Booking → Settings. Any "Book now" button then opens the form FULL SCREEN in one tap (phone + desktop); [lumio_booking] still embeds it inline.
 * Version:           1.7.3
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Update URI:        https://lumiobooking.com/wp-update/lumio-booking
 * Author:            Lumio
 * License:           GPL-2.0-or-later
 * Text Domain:       lumio-booking
 */

if (!defined('ABSPATH')) {
    exit; // No direct access.
}

/* Everything is guarded so a duplicate/leftover copy can never cause a
 * "Cannot redeclare function" fatal error on activation. The first copy to
 * load wins; any other copy quietly no-ops. */
if (!function_exists('lumio_booking_base')) {

    if (!defined('LUMIO_BOOKING_OPT_SITE_URL')) {
        define('LUMIO_BOOKING_OPT_SITE_URL', 'lumio_booking_site_url'); // hosted web base
    }
    if (!defined('LUMIO_BOOKING_OPT_SLUG')) {
        define('LUMIO_BOOKING_OPT_SLUG', 'lumio_booking_slug');         // salon slug
        define('LUMIO_BOOKING_OPT_DELIVERY', 'lumio_booking_delivery');  // gtm | ga4 | none | auto
    }

    /** Base URL of the hosted Lumio app (defaults to the public domain). */
    function lumio_booking_base()
    {
        $u = get_option(LUMIO_BOOKING_OPT_SITE_URL, '');
        return $u ? rtrim($u, '/') : 'https://lumiobooking.com';
    }

    /* ---- Admin menu: salon-admin dashboard embedded inside wp-admin ---- */
    add_action('admin_menu', function () {
        add_menu_page('Lumio Booking', 'Lumio Booking', 'manage_options', 'lumio-booking', 'lumio_booking_page_dashboard', 'dashicons-calendar-alt', 26);
        add_submenu_page('lumio-booking', 'Dashboard', 'Dashboard', 'manage_options', 'lumio-booking', 'lumio_booking_page_dashboard');
        add_submenu_page('lumio-booking', 'Calendar', 'Calendar', 'manage_options', 'lumio-booking-calendar', 'lumio_booking_page_calendar');
        add_submenu_page('lumio-booking', 'Bookings', 'Bookings', 'manage_options', 'lumio-booking-bookings', 'lumio_booking_page_bookings');
        add_submenu_page('lumio-booking', 'Settings', 'Settings', 'manage_options', 'lumio-booking-settings', 'lumio_booking_render_settings_page');
    });

    /** Render one embedded salon-admin page (an iframe into the hosted app). */
    function lumio_booking_embed($path, $title)
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $src = esc_url(lumio_booking_base() . $path);
        echo '<div class="wrap">';
        echo '<h1>' . esc_html($title) . '</h1>';
        echo '<p style="color:#646970;margin:4px 0 12px">Your salon overview. If prompted, sign in with your Lumio salon admin account.</p>';
        echo '<iframe src="' . $src . '" title="' . esc_attr($title) . '" allow="payment; clipboard-write" ';
        echo 'style="width:100%;height:calc(100vh - 170px);min-height:600px;border:1px solid #c3c4c7;border-radius:10px;background:#0b1120;"></iframe>';
        echo '</div>';
    }

    function lumio_booking_page_dashboard() { lumio_booking_embed('/salon', 'Lumio Dashboard'); }
    function lumio_booking_page_calendar()  { lumio_booking_embed('/salon/calendar', 'Calendar'); }
    function lumio_booking_page_bookings()  { lumio_booking_embed('/salon/bookings', 'Bookings'); }

    /* ---- Settings: URL + slug for the customer [lumio_booking] shortcode ---- */
    add_action('admin_init', function () {
        register_setting('lumio_booking_settings', LUMIO_BOOKING_OPT_SITE_URL, array(
            'type' => 'string', 'sanitize_callback' => 'esc_url_raw', 'default' => '',
        ));
        register_setting('lumio_booking_settings', LUMIO_BOOKING_OPT_SLUG, array(
            'type' => 'string', 'sanitize_callback' => 'sanitize_title', 'default' => '',
        ));
        register_setting('lumio_booking_settings', LUMIO_BOOKING_OPT_DELIVERY, array(
            'type' => 'string',
            'sanitize_callback' => function ($v) { return in_array($v, array('gtm', 'ga4', 'none', 'auto'), true) ? $v : 'auto'; },
            'default' => 'auto',
        ));
    });

    function lumio_booking_render_settings_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $site_url = get_option(LUMIO_BOOKING_OPT_SITE_URL, '');
        $slug     = get_option(LUMIO_BOOKING_OPT_SLUG, '');
        $preview  = $slug ? lumio_booking_base() . '/book/' . $slug : '';
        $opt_url  = esc_attr(LUMIO_BOOKING_OPT_SITE_URL);
        $opt_slug = esc_attr(LUMIO_BOOKING_OPT_SLUG);

        echo '<div class="wrap">';
        echo '<h1>Lumio Booking — Settings</h1>';
        echo '<p>Connect this site to your salon, then add the shortcode <code>[lumio_booking]</code> to any page.</p>';
        echo '<form method="post" action="options.php">';
        settings_fields('lumio_booking_settings');
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th scope="row"><label for="lumio_site_url">Booking site URL</label></th><td>';
        echo '<input name="' . $opt_url . '" id="lumio_site_url" type="url" class="regular-text" value="' . esc_attr($site_url) . '" placeholder="https://lumiobooking.com" />';
        echo '<p class="description">Leave blank to use https://lumiobooking.com.</p></td></tr>';
        echo '<tr><th scope="row"><label for="lumio_slug">Salon slug</label></th><td>';
        echo '<input name="' . $opt_slug . '" id="lumio_slug" type="text" class="regular-text" value="' . esc_attr($slug) . '" placeholder="lux-nail-spa" />';
        echo '<p class="description">The part after <code>/book/</code> in your booking link.</p></td></tr>';
        $delivery = get_option(LUMIO_BOOKING_OPT_DELIVERY, 'auto');
        $opt_del  = esc_attr(LUMIO_BOOKING_OPT_DELIVERY);
        echo '<tr><th scope="row"><label for="lumio_delivery">Conversion delivery</label></th><td>';
        echo '<select name="' . $opt_del . '" id="lumio_delivery">';
        foreach (array('gtm' => 'GTM — push booking_completed to dataLayer (recommended)', 'ga4' => 'GA4 direct — call gtag purchase', 'none' => 'Off — send nothing', 'auto' => 'Auto — legacy detection (old sites)') as $k => $label) {
            echo '<option value="' . esc_attr($k) . '"' . selected($delivery, $k, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
        echo '<p class="description">How completed bookings from the embedded form reach THIS site\'s analytics. New sites should use GTM: the event is queued on the dataLayer even if GTM has not finished loading.</p></td></tr>';
        if ($preview) {
            echo '<tr><th scope="row">Your booking link</th><td><a href="' . esc_url($preview) . '" target="_blank" rel="noopener">' . esc_html($preview) . '</a></td></tr>';
        }
        echo '</table>';
        submit_button('Save settings');
        echo '</form>';
        echo '<hr /><h2>Show the booking form to customers</h2>';
        echo '<p><strong>Recommended — one tap, full screen.</strong> Any of these opens the booking form full screen instantly, on phones and computers:</p>';
        echo '<ol>';
        echo '<li>Add the shortcode <code>[lumio_booking_button]</code> (optional: <code>[lumio_booking_button text="Book Now" align="center"]</code>).</li>';
        echo '<li>Or point any existing button/link on your site to your booking link above — it is detected automatically.</li>';
        echo '<li>Or add the CSS class <code>lumio-book</code> to any button you already have.</li>';
        echo '</ol>';
        echo '<p><code>[lumio_booking]</code> also works: the page holding it opens the form full screen automatically, so a menu link to that page is a single tap. Embedding it inside a longer page instead? Use <code>[lumio_booking autoopen="0"]</code> to keep it inline.</p>';
        echo '<p>To manage appointments use <strong>Lumio Booking → Dashboard / Calendar / Bookings</strong> on the left.</p>';
        echo '</div>';
    }

    /* ---- Customer shortcode: [lumio_booking] ---- */
    function lumio_booking_shortcode($atts)
    {
        // 'height' is only the INITIAL height; the iframe auto-resizes to the
        // form's real content height (via a postMessage the hosted form sends),
        // so there is never empty space below it.
        $atts = shortcode_atts(array('slug' => '', 'url' => '', 'height' => '560', 'autoopen' => '1'), $atts, 'lumio_booking');
        $site = ($atts['url'] !== '') ? rtrim($atts['url'], '/') : lumio_booking_base();
        $slug = ($atts['slug'] !== '') ? $atts['slug'] : get_option(LUMIO_BOOKING_OPT_SLUG, '');
        $slug = trim((string) $slug);
        if (!$slug) {
            return current_user_can('manage_options') ? '<p><em>Lumio Booking: set your Salon slug under Lumio Booking &rarr; Settings.</em></p>' : '';
        }
        // The page holding this shortcode IS the booking page, so open the form
        // FULL SCREEN the moment it loads: the visitor's tap on the salon's
        // "Booking" menu item is then the ONLY tap needed. A button is left behind
        // so they can reopen it after closing (and it still works without JS).
        // Salons embedding the form inside a longer page opt out with autoopen="0".
        if ($atts['autoopen'] !== '0') {
            $launch = $site . '/book/' . rawurlencode($slug) . '?full=1';
            return '<script>window.__lumioAutoOpen=1;</script>' . lumio_booking_button_html($launch, 'Book Now', 'center');
        }

        $src    = esc_url($site . '/book/' . rawurlencode($slug));
        $height = max(320, intval($atts['height']));

        // Origin of the booking site, for a safe postMessage check.
        $scheme = parse_url($site, PHP_URL_SCHEME);
        $host   = parse_url($site, PHP_URL_HOST);
        $origin = ($scheme && $host) ? $scheme . '://' . $host : '';
        $fid    = 'lumio-booking-' . wp_rand(1000, 99999);

        $html  = '<div class="lumio-booking-embed" style="width:100%;max-width:1200px;margin:0 auto;">';
        $html .= '<iframe id="' . esc_attr($fid) . '" src="' . $src . '" loading="lazy" title="Book an appointment" allow="payment" ';
        $html .= 'style="width:100%;min-height:' . $height . 'px;border:0;border-radius:16px;overflow:hidden;background:transparent;display:block;"></iframe>';
        $html .= '</div>';
        // Auto-resize: match the iframe to the form's reported content height.
        // Auto-resize + scroll-chaining now live in a script hosted on the booking site, so
        // every future embed fix ships with the app and this plugin NEVER needs updating
        // again. The inline part only registers this iframe and loads that script, plus a
        // small fallback that keeps auto-height working if the script cannot be fetched.
        $html .= '<script>(function(){'
            . 'var L=window.LumioEmbed=window.LumioEmbed||{frames:[]};'
            . 'L.frames.push({id:' . wp_json_encode($fid) . ',origin:' . wp_json_encode($origin) . '});'
            . 'if(L.boot){return;}L.boot=1;'
            . 'var s=document.createElement("script");s.src=' . wp_json_encode($site . '/embed.js?v=4') . ';s.async=true;document.head.appendChild(s);'

            . 'setTimeout(function(){if(L.ready){return;}'
            . 'window.addEventListener("message",function(e){var d=e.data;if(!d||d.type!=="lumio-embed-height"){return;}'
            . 'for(var i=0;i<L.frames.length;i++){var fr=L.frames[i];if(fr.origin&&e.origin!==fr.origin){continue;}'
            . 'var f=document.getElementById(fr.id);if(!f){continue;}var h=parseInt(d.height,10);'
            . 'if(h&&h>120){f.style.height=h+"px";f.style.minHeight="0px";}}});},3000);'
            . '})();</script>';
        return $html;
    }
    /* ---- One-tap FULL-SCREEN booking overlay ------------------------------
     * Problem this solves: an inline iframe has no viewport of its own, so on a
     * phone the form used to show a teaser card that the visitor had to tap a
     * SECOND time before the real form appeared. Now any "Book now" button opens
     * the form full screen on the first tap, on phone and desktop alike.
     *
     * A button counts as a trigger when it has class `lumio-book`, the attribute
     * `data-lumio-book`, or simply links to the salon's /book/<slug> URL.
     * The overlay is pre-loaded while the page is idle, so it opens instantly. */

    /** Booking URL that renders full screen (the app skips the teaser card). */
    function lumio_booking_launch_url()
    {
        $slug = trim((string) get_option(LUMIO_BOOKING_OPT_SLUG, ''));
        if (!$slug) {
            return '';
        }
        return lumio_booking_base() . '/book/' . rawurlencode($slug) . '?full=1';
    }

    add_action('wp_footer', function () {
        $url = lumio_booking_launch_url();
        if (!$url) {
            return;
        }
        $slug  = trim((string) get_option(LUMIO_BOOKING_OPT_SLUG, ''));
        $match = '/book/' . rawurlencode($slug);
        echo '<script>(function(){'
            . 'if(window.__lumioLaunch){return;}window.__lumioLaunch=1;'
            . 'var U=' . wp_json_encode($url) . ',M=' . wp_json_encode($match) . ';'
            . 'var LB_ORIGIN=' . wp_json_encode(preg_replace('#^(https?://[^/]+).*$#', '$1', lumio_booking_base())) . ';'
            . 'var LB_SLUG=' . wp_json_encode($slug) . ';'
            . 'var LB_MODE=' . wp_json_encode((string) get_option(LUMIO_BOOKING_OPT_DELIVERY, 'auto')) . ';'
            /* First-party attribution store: first-touch + last-touch for 30 days
               (utm_*, gclid/gbraid/wbraid + landing url + referrer + captured_at).
               Runs on EVERY page, so the source survives multi-page journeys. */
            . 'function lbAttr(){try{var K="lumio_attr_v1",now=Date.now(),st={};try{st=JSON.parse(localStorage.getItem(K)||"{}")||{}}catch(e){}'
            . 'var p=new URLSearchParams(location.search),ks=["utm_source","utm_medium","utm_campaign","utm_content","utm_term","gclid","gbraid","wbraid"],cur={},has=0;'
            . 'for(var i=0;i<ks.length;i++){var v=p.get(ks[i]);if(v){cur[ks[i]]=v;has=1;}}'
            . 'if(has){var en={p:cur,lu:location.href.slice(0,500),rf:(document.referrer||"").slice(0,500),at:new Date().toISOString(),ts:now};'
            . 'if(!st.ft||now-(st.ft.ts||0)>2592e6){st.ft=en;}st.lt=en;try{localStorage.setItem(K,JSON.stringify(st));}catch(e2){}}'
            . 'var u=(st.lt&&now-(st.lt.ts||0)<2592e6)?st.lt:((st.ft&&now-(st.ft.ts||0)<2592e6)?st.ft:null);return u;}catch(e){return null;}}'
            . 'function lbAttrQ(){var q="po="+encodeURIComponent(location.origin),u=lbAttr();'
            . 'if(u){for(var k in u.p){q+="&"+k+"="+encodeURIComponent(u.p[k]);}q+="&lumio_lu="+encodeURIComponent(u.lu)+"&lumio_rf="+encodeURIComponent(u.rf)+"&lumio_at="+encodeURIComponent(u.at);}'
            . 'else{q+="&lumio_lu="+encodeURIComponent(location.href.slice(0,500))+"&lumio_rf="+encodeURIComponent((document.referrer||"").slice(0,500))+"&lumio_at="+encodeURIComponent(new Date().toISOString());}return q;}'
            . 'function lumioUtm(u){try{return u+(u.indexOf("?")>=0?"&":"?")+lbAttrQ();}catch(e){return u;}}'
            /* Decorate every Lumio iframe (shortcode or theme-made) with the
               stored attribution + our origin (po) so the form can post the
               conversion back to a VERIFIED target, never "*". */
            . 'function lbDecorate(){try{var fs=document.querySelectorAll("iframe");for(var i=0;i<fs.length;i++){var f=fs[i];'
            . 'if(f.src&&f.src.indexOf(LB_ORIGIN)===0&&f.src.indexOf("po=")<0){f.src+=(f.src.indexOf("?")>=0?"&":"?")+lbAttrQ();}}}catch(e){}}'
            . 'lbAttr();lbDecorate();document.addEventListener("DOMContentLoaded",lbDecorate);setTimeout(lbDecorate,1500);'
            /* Validated conversion bridge — the ONLY path a booking event may
               take into this site's analytics. Rejects: wrong origin, wrong
               schema, wrong salon, empty transaction id, or a sender that is
               not one of OUR iframes. Idempotent per transaction id. */
            . '(function(){if(window.__lumioBridge){return;}window.__lumioBridge=1;window.__lumioSent={};'
            . 'window.addEventListener("message",function(e){var d=e.data;'
            . 'if(!d||typeof d!=="object"||d.type!=="lumio:booking_completed"){return;}'
            . 'if(e.origin!==LB_ORIGIN){return;}'
            . 'if(d.schema_version!==1){return;}'
            . 'if(!d.transaction_id||typeof d.transaction_id!=="string"){return;}'
            . 'if(LB_SLUG&&d.salon_slug&&d.salon_slug!==LB_SLUG){return;}'
            . 'var ok=false;try{var fs=document.querySelectorAll("iframe");for(var i=0;i<fs.length;i++){if(fs[i].contentWindow===e.source&&fs[i].src.indexOf(LB_ORIGIN)===0){ok=true;break;}}}catch(er){}'
            . 'if(!ok){return;}'
            . 'if(window.__lumioSent[d.transaction_id]){return;}window.__lumioSent[d.transaction_id]=1;'
            . 'var p={event:"booking_completed",transaction_id:d.transaction_id,value:d.value,currency:d.currency,items:d.items};'
            . 'var g={transaction_id:d.transaction_id,value:d.value,currency:d.currency,items:d.items};'
            . 'try{if(LB_MODE==="none"){return;}'
            . 'else if(LB_MODE==="gtm"){window.dataLayer=window.dataLayer||[];window.dataLayer.push(p);}'
            . 'else if(LB_MODE==="ga4"){window.dataLayer=window.dataLayer||[];window.gtag=window.gtag||function(){window.dataLayer.push(arguments);};window.gtag("event","purchase",g);}'
            . 'else{if(window.google_tag_manager){window.dataLayer=window.dataLayer||[];window.dataLayer.push(p);}'
            . 'else if(typeof window.gtag==="function"){window.gtag("event","purchase",g);}'
            . 'else{window.dataLayer=window.dataLayer||[];window.dataLayer.push(p);}}}catch(err){}});})();'
            . 'var wrap=null,frame=null,isOpen=false,savedY=0,pushed=false,adopted=false;'
            . 'function build(){if(wrap){return;}'
            . 'wrap=document.createElement("div");wrap.setAttribute("aria-hidden","true");'
            . 'wrap.style.cssText="position:fixed;top:0;left:0;right:0;bottom:0;z-index:2147483000;background:#fff;display:none;";'
            . 'frame=document.createElement("iframe");frame.title="Book an appointment";'
            . 'frame.setAttribute("allow","payment");'
            . 'frame.style.cssText="width:100%;height:100%;border:0;display:block;";frame.src=lumioUtm(U);'
            . 'var x=document.createElement("button");x.type="button";x.setAttribute("aria-label","Close");x.innerHTML="&times;";'
            . 'x.style.cssText="position:absolute;top:calc(8px + env(safe-area-inset-top));right:calc(8px + env(safe-area-inset-right));'
            . 'width:40px;height:40px;border-radius:20px;border:0;background:rgba(15,23,42,.72);color:#fff;'
            . 'font:600 26px/1 system-ui,-apple-system,sans-serif;cursor:pointer;z-index:2;";'
            . 'x.addEventListener("click",function(){closeOverlay();});'
            . 'wrap.appendChild(frame);wrap.appendChild(x);document.body.appendChild(wrap);}'
            . 'function openOverlay(noHist){build();if(isOpen){return;}isOpen=true;'
            . 'savedY=window.pageYOffset||document.documentElement.scrollTop||0;'
            . 'wrap.style.display="block";wrap.removeAttribute("aria-hidden");'
            . 'document.body.style.position="fixed";document.body.style.top=(-savedY)+"px";'
            . 'document.body.style.left="0";document.body.style.right="0";'
            . 'document.body.style.width="100%";document.body.style.overflow="hidden";'
            . 'if(!noHist){try{history.pushState({lumioBook:1},"");pushed=true;}catch(e){}}}'
            . 'function closeOverlay(fromPop){if(!isOpen){return;}isOpen=false;'
            . 'wrap.style.display="none";wrap.setAttribute("aria-hidden","true");'
            . 'document.body.style.position="";document.body.style.top="";document.body.style.left="";'
            . 'document.body.style.right="";document.body.style.width="";document.body.style.overflow="";'
            . 'window.scrollTo(0,savedY);'
            . 'if(!fromPop&&pushed){pushed=false;try{history.back();}catch(e){}return;}'
            // The page we took over existed only to hold the form, so closing means
            // "leave booking" — send the visitor back to the site rather than leaving
            // them staring at an empty shell of a page.
            // The form opened by itself, so this page exists to hold it. Closing means
            // "I am done booking" -> go back to the site the visitor came from, never
            // strand them on a page that is now just an empty frame and a button.
            // (A salon embedding the form mid-page uses [lumio_booking autoopen="0"],
            // which never auto-opens, so this branch cannot fire there.)
            . 'if(adopted){'
            . 'try{if(history.length>1){history.back();return;}}catch(e){}location.href="/";}}'
            . 'function hit(el){if(!el||!el.getAttribute){return false;}'
            . 'if(el.classList&&el.classList.contains("lumio-book")){return true;}'
            . 'if(el.hasAttribute("data-lumio-book")){return true;}'
            . 'var h=el.getAttribute("href");return !!(h&&h.indexOf(M)!==-1);}'
            . 'document.addEventListener("click",function(ev){var el=ev.target;'
            . 'while(el&&el!==document.body){if(hit(el)){ev.preventDefault();ev.stopPropagation();openOverlay();return;}'
            . 'el=el.parentElement;}},true);'
            . 'document.addEventListener("keydown",function(e){if(e.key==="Escape"){closeOverlay();}});'
            . 'window.addEventListener("popstate",function(){if(isOpen){closeOverlay(true);}});'
            . 'window.addEventListener("message",function(e){var d=e.data;'
            . 'if(d&&typeof d==="object"&&(d.type==="lumio-embed-collapse"||d.type==="lumio-booking-close")){closeOverlay();}});'

            . 'function pre(){if(document.querySelector(".lumio-book,[data-lumio-book],a[href*=\'"+M+"\']")){build();}}'
            // Some salon themes render the booking iframe themselves instead of using
            // the shortcode, so the plugin never sees it. Those frames are content-sized,
            // which is exactly what makes the form fall back to its teaser card and
            // fake-pinned cart. Take over: hide the frame, drop a Book button in its
            // place and show the form full screen, which is the one layout that always
            // has a real viewport no matter how the theme is built.
            . 'function adopt(){var l=document.querySelectorAll("iframe[src*=\'"+M+"\']");'
            . 'for(var i=0;i<l.length;i++){var f=l[i];'
            . 'if(f.__lumioTaken){continue;}'
            . 'if(wrap&&wrap.contains(f)){continue;}'
            . 'if(f.closest&&f.closest(".lumio-booking-embed")){continue;}'
            . 'f.__lumioTaken=1;'
            . 'var b=document.createElement("a");b.className="lumio-book";b.href=U;b.textContent="Book now";'
            . 'b.style.cssText="display:inline-block;padding:14px 28px;border-radius:999px;background:#4f46e5;'
            . 'color:#fff;font-weight:700;font-size:16px;text-decoration:none;line-height:1;";'
            . 'var box=document.createElement("div");box.style.cssText="text-align:center;padding:28px 0;";'
            . 'box.appendChild(b);if(f.parentNode){f.parentNode.insertBefore(box,f);}'
            . 'f.style.setProperty("display","none","important");'
            . 'try{f.src="about:blank";}catch(e){}'
            . 'adopted=true;openOverlay(true);}}'
            . 'adopt();setTimeout(adopt,1200);'
            . 'if(window.requestIdleCallback){requestIdleCallback(pre,{timeout:3000});}else{setTimeout(pre,1500);}'
            // Booking page: show the form straight away (no history entry, so the
            // Back button on a phone returns to the previous page as expected.
            . 'if(window.__lumioAutoOpen){adopted=true;openOverlay(true);}'
            . '})();</script>';
    });

    /** A "Book now" button that opens the full-screen overlay (real link = works without JS). */
    function lumio_booking_button_html($url, $text = 'Book Now', $align = 'left', $color = '#4f46e5')
    {
        $align = in_array($align, array('left', 'center', 'right'), true) ? $align : 'left';
        $style = 'display:inline-block;padding:14px 28px;border-radius:999px;background:' . esc_attr($color)
               . ';color:#fff;font-weight:700;font-size:16px;text-decoration:none;line-height:1;';
        return '<div style="text-align:' . esc_attr($align) . '"><a class="lumio-book" href="' . esc_url($url) . '" style="' . $style . '">'
             . esc_html($text) . '</a></div>';
    }

    /* ---- Customer shortcode: [lumio_booking_button] ---- */
    function lumio_booking_button_shortcode($atts)
    {
        $atts = shortcode_atts(array('text' => 'Book Now', 'align' => 'left', 'color' => '#4f46e5'), $atts, 'lumio_booking_button');
        $url = lumio_booking_launch_url();
        if (!$url) {
            return current_user_can('manage_options') ? '<p><em>Lumio Booking: set your Salon slug under Lumio Booking &rarr; Settings.</em></p>' : '';
        }
        return lumio_booking_button_html($url, $atts['text'], $atts['align'], $atts['color']);
    }
    add_shortcode('lumio_booking_button', 'lumio_booking_button_shortcode');

    /* ---- Self-update ------------------------------------------------------
     * Salons never re-upload this plugin again. WordPress asks the manifest on
     * lumiobooking.com for the latest build, shows it in wp-admin and installs
     * it automatically. The hook name is derived from the "Update URI" header
     * above, so it fires ONLY for this plugin and can never disturb the update
     * checks of any other plugin on the site. */
    if (!defined('LUMIO_BOOKING_UPDATE_URL')) {
        define('LUMIO_BOOKING_UPDATE_URL', 'https://lumiobooking.com/wp-update/lumio-booking.json');
    }

    /** Latest published build info, cached so we never hammer the server. */
    function lumio_booking_remote_manifest()
    {
        // "Check again" on Dashboard -> Updates (and WP-CLI) must reach the server
        // straight away, otherwise a cached answer hides a brand-new build for hours.
        $force = !empty($_GET['force-check']) || (defined('WP_CLI') && WP_CLI);
        if (!$force) {
            $cached = get_transient('lumio_booking_manifest');
            if ($cached !== false) {
                return is_array($cached) ? $cached : array();
            }
        }
        $res = wp_remote_get(LUMIO_BOOKING_UPDATE_URL, array(
            'timeout' => 8,
            'headers' => array('Accept' => 'application/json'),
        ));
        if (is_wp_error($res) || (int) wp_remote_retrieve_response_code($res) !== 200) {
            // Short back-off so an outage cannot slow down wp-admin, but also
            // cannot delay the next real update for long.
            set_transient('lumio_booking_manifest', array(), 15 * MINUTE_IN_SECONDS);
            return array();
        }
        $data = json_decode(wp_remote_retrieve_body($res), true);
        $data = is_array($data) ? $data : array();
        set_transient('lumio_booking_manifest', $data, HOUR_IN_SECONDS);
        return $data;
    }

    add_filter('update_plugins_lumiobooking.com', function ($update, $plugin_data, $plugin_file) {
        $m = lumio_booking_remote_manifest();
        if (empty($m['version']) || empty($m['download_url'])) {
            return $update;
        }
        $current = isset($plugin_data['Version']) ? $plugin_data['Version'] : '0';
        if (version_compare($m['version'], $current, '<=')) {
            return $update; // already up to date
        }
        return array(
            'id'           => 'lumiobooking.com/lumio-booking',
            'slug'         => 'lumio-booking',
            'plugin'       => $plugin_file,
            'version'      => $m['version'],
            'url'          => isset($m['homepage']) ? $m['homepage'] : 'https://lumiobooking.com',
            'package'      => $m['download_url'],
            'tested'       => isset($m['tested']) ? $m['tested'] : '',
            'requires_php' => isset($m['requires_php']) ? $m['requires_php'] : '7.4',
        );
    }, 10, 3);

    /* Install those updates without anyone clicking anything. */
    add_filter('auto_update_plugin', function ($update, $item) {
        if (isset($item->slug) && $item->slug === 'lumio-booking') {
            return true;
        }
        return $update;
    }, 10, 2);

    /* ---- Instant updates ---------------------------------------------------
     * WordPress only polls for plugin updates twice a day, so a fresh Lumio
     * build could sit unseen for hours. Two accelerators fix that:
     *   1. Opening Plugins (or Dashboard->Updates) re-reads the manifest; when
     *      a newer build exists the cached update list is rebuilt on the spot,
     *      so the "update now" row shows immediately.
     *   2. An hourly cron runs the same check and then kicks the automatic
     *      updater, so every site self-installs within the hour, zero clicks.
     * The heavy path (rebuilding the update list) only runs when a newer build
     * actually exists — normal visits cost one 8s-timeout GET to a static JSON.
     */
    function lumio_booking_refresh_updates($install_now)
    {
        delete_transient('lumio_booking_manifest');
        $m = lumio_booking_remote_manifest();
        if (empty($m['version'])) {
            return;
        }
        if (!function_exists('get_plugin_data')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $data = get_plugin_data(__FILE__, false, false);
        $cur = isset($data['Version']) ? $data['Version'] : '0';
        if (version_compare($m['version'], $cur, '<=')) {
            return; // already newest — nothing to rebuild
        }
        delete_site_transient('update_plugins');
        wp_update_plugins();
        if ($install_now && function_exists('wp_maybe_auto_update')) {
            wp_maybe_auto_update();
        }
    }

    add_action('load-plugins.php', function () { lumio_booking_refresh_updates(false); });
    add_action('load-update-core.php', function () { lumio_booking_refresh_updates(false); });

    add_action('lumio_booking_hourly_update', function () { lumio_booking_refresh_updates(true); });
    add_action('init', function () {
        if (!wp_next_scheduled('lumio_booking_hourly_update')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', 'lumio_booking_hourly_update');
        }
    });
    register_deactivation_hook(__FILE__, function () {
        wp_clear_scheduled_hook('lumio_booking_hourly_update');
    });

    add_shortcode('lumio_booking', 'lumio_booking_shortcode');
}
