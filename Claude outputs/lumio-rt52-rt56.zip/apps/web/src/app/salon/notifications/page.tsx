'use client';

// ===========================================================================
// Notifications — Amelia-style template manager.
//  • Templates tab: per-event email/SMS templates the salon can edit, grouped
//    by audience (customer / staff) with a live preview and placeholder chips.
//  • History tab: the log of messages actually sent.
// The delivery connection (sender, admin contacts, SMTP, Twilio) lives in
// Settings → Notifications; this page is purely about the message content.
// ===========================================================================

import { useCallback, useEffect, useRef, useState } from 'react';
import { fmtInTz } from '../../../lib/datetime';
import { SalonShell } from '../../../components/SalonShell';
import { useAuth } from '../../../lib/auth';
import { apiFetch } from '../../../lib/api';
import { ui } from '../../../lib/ui';
import { useLang, tr } from '../../../lib/i18n';
import { useIsMobile } from '../../../lib/responsive';
import { uiLocale } from '../../../lib/datetime';
import { SettingsScreen } from '../../../components/settings/SettingsScreen';
import { smsSegments, toGsm7 } from '../../../lib/sms-text';

interface Tpl {
  enabled: boolean; email: boolean; sms: boolean;
  subject: string; body: string; smsBody: string; offsetHours: number;
}
type Templates = Record<string, Tpl>;
type Audience = 'customer' | 'staff';
type Scheduled = 'before' | 'after' | 'day';

interface CatalogItem {
  id: string; audience: Audience; group: string; label: string; desc: string; scheduled?: Scheduled;
}

// Stable ids must match the backend default catalog.
const CATALOG: CatalogItem[] = [
  { id: 'customer_booking_confirmed', audience: 'customer', group: 'Booking', label: 'Booking confirmed', desc: 'Sent right after a booking is confirmed. Drives the live confirmation email/SMS.' },
  { id: 'customer_staff_assigned', audience: 'customer', group: 'Booking', label: 'Technician assigned', desc: 'Sent when a booking confirmed without a technician gets one.' },
  { id: 'customer_booking_pending', audience: 'customer', group: 'Booking', label: 'Booking received (pending)', desc: 'Sent when a booking is received and awaiting confirmation.' },
  { id: 'customer_booking_cancelled', audience: 'customer', group: 'Booking', label: 'Booking cancelled', desc: 'Sent when a booking is cancelled.' },
  { id: 'customer_booking_rescheduled', audience: 'customer', group: 'Booking', label: 'Rescheduled', desc: 'Sent when the date or time changes.' },
  { id: 'customer_reminder', audience: 'customer', group: 'Reminders & care', label: 'Appointment reminder', desc: 'A reminder sent before the appointment.', scheduled: 'before' },
  { id: 'customer_followup', audience: 'customer', group: 'Reminders & care', label: 'Thank-you / follow-up', desc: 'A thank-you message sent after the visit.', scheduled: 'after' },
  { id: 'customer_birthday', audience: 'customer', group: 'Reminders & care', label: 'Birthday greeting', desc: 'A greeting sent on the customer’s birthday.', scheduled: 'day' },
  { id: 'customer_payment_receipt', audience: 'customer', group: 'Payment', label: 'Payment receipt', desc: 'A receipt sent after a payment is taken.' },
  { id: 'staff_new_booking', audience: 'staff', group: 'Staff alerts', label: 'New booking assigned', desc: 'Sent to the technician when a booking is assigned to them.' },
  { id: 'staff_booking_cancelled', audience: 'staff', group: 'Staff alerts', label: 'Booking cancelled', desc: 'Sent to the technician when their booking is cancelled.' },
  { id: 'staff_daily_agenda', audience: 'staff', group: 'Staff alerts', label: 'Daily schedule', desc: 'A next-day schedule summary for the technician.', scheduled: 'before' },
];

const PLACEHOLDERS = [
  '%customer_name%', '%salon_name%', '%service_name%', '%staff_name%',
  '%appointment_date%', '%appointment_time%', '%duration%', '%total_price%',
  '%add_ons%', '%salon_contact%', '%booking_id%',
  // A move: where the appointment was before.
  '%old_date%', '%old_time%',
];

const SAMPLE: Record<string, string> = {
  customer_name: 'Jane Smith', salon_name: 'Salon A — Demo Nails', service_name: 'Gel Manicure',
  staff_name: 'Tina', appointment_date: 'Mon, Jun 22, 2026', appointment_time: '5:30 PM',
  duration: '45 min', total_price: '$45.00', add_ons: 'Nail Art', salon_contact: '(587) 435-0838', booking_id: 'BK-1042',
  old_date: 'Sat, Jun 20, 2026', old_time: '3:00 PM',
};
function fillPct(s: string) { return s.replace(/%(\w+)%/g, (_m, k) => SAMPLE[k] ?? SAMPLE[PCT_ALIASES[k.toLowerCase()] ?? ''] ?? `%${k}%`); }

/**
 * The other names the API also fills (apps/api/src/notifications/email-template.ts
 * PCT_ALIASES — keep in step). Shown in the preview as the value they get.
 */
const PCT_ALIASES: Record<string, string> = {
  date: 'appointment_date', appointment_day: 'appointment_date', booking_date: 'appointment_date', appt_date: 'appointment_date', appointment_date_formatted: 'appointment_date',
  time: 'appointment_time', booking_time: 'appointment_time', appt_time: 'appointment_time',
  appointment_start_time: 'appointment_time', start_time: 'appointment_time', appointment_time_start: 'appointment_time',
  customer_first_name: 'customer_name', first_name: 'customer_name', client_name: 'customer_name', client_first_name: 'customer_name',
  employee_name: 'staff_name', employee_first_name: 'staff_name', employee_full_name: 'staff_name', technician: 'staff_name', technician_name: 'staff_name', tech_name: 'staff_name', staff: 'staff_name', provider_name: 'staff_name',
  company_name: 'salon_name', business_name: 'salon_name', shop_name: 'salon_name', store_name: 'salon_name', salon: 'salon_name',
  company_phone: 'salon_contact', salon_phone: 'salon_contact', business_phone: 'salon_contact', company_email: 'salon_contact', salon_email: 'salon_contact',
  appointment_price: 'total_price', service_price: 'total_price', price: 'total_price', total: 'total_price', booking_price: 'total_price',
  service_duration: 'duration', appointment_duration: 'duration',
};
/** Placeholders the API knows besides the chips (and their aliases). */
const OTHER_KNOWN = new Set([
  'customer_full_name', 'customer_phone', 'customer_email', 'service_lineup', 'add_ons_only', 'booking_notes',
  'salon_address', 'booking_source', 'booking_ref', 'manage_url', 'appointment_end_time', 'end_time',
  'appointment_date_time', 'appointment_datetime', 'date_time', 'datetime', 'full_name', 'client_full_name',
  'booked_customer_full_name', 'company_address', 'location_address', 'salon_location', 'manage_link',
  'appointment_link', 'cancel_link', 'manage_appointment_url', 'booking_number', 'appointment_id',
  'booking_url', 'booking_link', 'review_url', 'review_link',
]);
const unknownTokens = (s: string) => [...new Set((s.match(/%(\w+)%/g) ?? []).filter((tk) => {
  const k = tk.slice(1, -1).toLowerCase();
  return !(k in SAMPLE) && !(k in PCT_ALIASES) && !OTHER_KNOWN.has(k);
}))];

/** A sample of the 33-character signed code the real text carries. */
const SAMPLE_SMS_LINK = 'https://lumiobooking.com/a/Px2c8Q6dSnu-ilzH6PmqC1Xb4rTq9wE_k';
/**
 * The text exactly as a customer receives it: the template filled, the
 * manage link the confirmation adds (outside Vietnam, unless the template
 * already placed it), then the same plain-text pass the API applies.
 */
function smsAsSent(id: string, smsBody: string, vn: boolean): string {
  let s = fillPct(smsBody);
  if (id === 'customer_booking_confirmed' && !vn && !/%manage_url%/i.test(smsBody)) s = `${s}\nManage/cancel: ${SAMPLE_SMS_LINK}`;
  s = s.replace(/%manage_url%/gi, SAMPLE_SMS_LINK);
  return vn ? s : toGsm7(s);
}

export default function NotificationsPage() {
  return (
    <SalonShell>
      <Inner />
    </SalonShell>
  );
}

function Inner() {
  const { token } = useAuth();
  const { lang } = useLang();
  const t = (k: string) => tr(k, lang);
  type NTab = 'templates' | 'channels' | 'reminders' | 'history';
  const [tab, setTab] = useState<NTab>('templates');
  // Deep links: ?tab=channels (how messages go out), ?tab=reminders.
  useEffect(() => {
    const want = new URLSearchParams(window.location.search).get('tab');
    if (want === 'channels' || want === 'reminders' || want === 'history' || want === 'templates') setTab(want);
  }, []);
  const vi = lang === 'vi';
  return (
    <section>
      <h1 style={{ fontSize: 24, margin: '0 0 4px' }}>{t('nt.title')}</h1>
      <p style={{ color: 'var(--c94a3b8)', marginTop: 0, fontSize: 14 }}>
        {t('nt.subtitle')}
      </p>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, background: 'var(--c1e293b)', border: '1px solid var(--c334155)', borderRadius: 10, padding: 4, width: 'fit-content', maxWidth: '100%', margin: '16px 0 18px' }}>
        <TabBtn active={tab === 'templates'} onClick={() => setTab('templates')}>{t('nt.tabTemplates')}</TabBtn>
        <TabBtn active={tab === 'channels'} onClick={() => setTab('channels')}>{vi ? 'Gửi bằng gì (Email / SMS)' : 'Sending (email / SMS)'}</TabBtn>
        <TabBtn active={tab === 'reminders'} onClick={() => setTab('reminders')}>{vi ? 'Nhắc lịch tự động' : 'Automatic reminders'}</TabBtn>
        <TabBtn active={tab === 'history'} onClick={() => setTab('history')}>{t('nt.tabHistory')}</TabBtn>
      </div>

      {tab === 'templates' && <TemplatesView token={token} />}
      {tab === 'channels' && <SettingsScreen only={['notifications']} bare />}
      {tab === 'reminders' && <SettingsScreen only={['reminders']} bare />}
      {tab === 'history' && <HistoryView token={token} />}
    </section>
  );
}

/* ----------------------------- Templates ----------------------------- */

const GROUP_KEY: Record<string, string> = { 'Booking': 'nt.grpBooking', 'Reminders & care': 'nt.grpReminders', 'Payment': 'nt.grpPayment', 'Staff alerts': 'nt.grpStaff' };

function TemplatesView({ token }: { token: string | null }) {
  const { lang } = useLang();
  const t = (k: string) => tr(k, lang);
  const [templates, setTemplates] = useState<Templates | null>(null);
  const [accent, setAccent] = useState('#6366f1');
  // Vietnamese texts go out exactly as written (registered with the carriers),
  // so the plain-text pass and the manage link do not apply there.
  const [vn, setVn] = useState(false);
  const [audience, setAudience] = useState<Audience>('customer');
  const [selectedId, setSelectedId] = useState<string>('customer_booking_confirmed');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const subjectRef = useRef<HTMLInputElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const smsRef = useRef<HTMLTextAreaElement>(null);
  const focusedRef = useRef<'subject' | 'body' | 'smsBody'>('body');
  const isMobile = useIsMobile();

  const load = useCallback(async () => {
    if (!token) return;
    setLoading(true); setError(null);
    try {
      const s = await apiFetch<{ notificationTemplates: Templates; branding?: { accentColor: string }; market?: string }>('/settings', { token });
      setTemplates(s.notificationTemplates ?? {});
      setVn(String(s.market ?? '').toUpperCase() === 'VN');
      if (s.branding?.accentColor) setAccent(s.branding.accentColor);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load templates');
    } finally { setLoading(false); }
  }, [token]);

  useEffect(() => { load(); }, [load]);

  const items = CATALOG.filter((c) => c.audience === audience);
  const groups = [...new Set(items.map((i) => i.group))];
  const meta = CATALOG.find((c) => c.id === selectedId)!;
  const tpl = templates?.[selectedId];

  const patch = (field: keyof Tpl, value: Tpl[keyof Tpl]) => {
    setTemplates((prev) => (prev ? { ...prev, [selectedId]: { ...prev[selectedId], [field]: value } } : prev));
    setSaved(false);
  };

  const insert = (ph: string) => {
    if (!tpl) return;
    const which = focusedRef.current;
    // Rich-text body: insert at the caret inside the contentEditable.
    if (which === 'body') {
      const el = bodyRef.current;
      if (!el) return;
      el.focus();
      document.execCommand('insertText', false, ph);
      patch('body', el.innerHTML);
      return;
    }
    // Plain inputs (subject / SMS): splice at the caret.
    const el = which === 'subject' ? subjectRef.current : smsRef.current;
    if (!el) return;
    const start = el.selectionStart ?? el.value.length;
    const end = el.selectionEnd ?? el.value.length;
    const cur = (tpl[which] as string) ?? '';
    const next = cur.slice(0, start) + ph + cur.slice(end);
    patch(which, next);
    requestAnimationFrame(() => { el.focus(); const pos = start + ph.length; el.setSelectionRange(pos, pos); });
  };

  const save = async () => {
    if (!token || !templates) return;
    setSaving(true); setError(null);
    try {
      await apiFetch('/settings/notification-templates', { method: 'PATCH', token, body: { templates } });
      setSaved(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save');
    } finally { setSaving(false); }
  };

  if (loading || !templates) return <p style={{ color: 'var(--c94a3b8)' }}>{t('nt.loading')}</p>;

  return (
    <div>
      {error && <div style={ui.banner}>{error}</div>}

      {/* audience tabs + save */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10, marginBottom: 14 }}>
        <div style={{ display: 'flex', gap: 4, background: 'var(--c0f172a)', border: '1px solid var(--c334155)', borderRadius: 8, padding: 3 }}>
          <SubTab active={audience === 'customer'} onClick={() => { setAudience('customer'); setSelectedId('customer_booking_confirmed'); }}>{t('nt.toCustomer')}</SubTab>
          <SubTab active={audience === 'staff'} onClick={() => { setAudience('staff'); setSelectedId('staff_new_booking'); }}>{t('nt.toStaff')}</SubTab>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {saved && <span style={{ color: 'var(--ink-good)', fontSize: 13 }}>{t('nt.saved')}</span>}
          <button onClick={save} disabled={saving} style={ui.primaryBtn}>{saving ? t('nt.saving') : t('nt.saveChanges')}</button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : 'minmax(240px, 300px) 1fr', gap: 16, alignItems: 'start' }}>
        {/* event list */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {groups.map((g) => (
            <div key={g}>
              <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--c64748b)', margin: '0 0 6px 2px', fontWeight: 600 }}>{t(GROUP_KEY[g] ?? g)}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {items.filter((i) => i.group === g).map((i) => {
                  const it = templates[i.id];
                  const active = selectedId === i.id;
                  return (
                    <button key={i.id} onClick={() => setSelectedId(i.id)}
                      style={{ textAlign: 'left', padding: '10px 12px', borderRadius: 10, cursor: 'pointer',
                        border: `1px solid ${active ? '#6366f1' : 'var(--c334155)'}`, background: active ? 'var(--c312e81)' : 'var(--c1e293b)' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                        <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--ce2e8f0)' }}>{t('nt.lbl.' + i.id)}</span>
                        <Dot on={!!it?.enabled} />
                      </div>
                      <div style={{ display: 'flex', gap: 6, marginTop: 5 }}>
                        {it?.email && <Badge>{t('nt.bEmail')}</Badge>}
                        {it?.sms && <Badge>{t('nt.bSms')}</Badge>}
                        {i.scheduled && <Badge>{t('nt.bScheduled')}</Badge>}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* editor + preview */}
        {tpl && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 16 }}>
            <div style={{ ...ui.card, padding: 18 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
                <div>
                  <h2 style={{ fontSize: 16, margin: '0 0 4px' }}>{t('nt.lbl.' + meta.id)}</h2>
                  <p style={{ color: 'var(--c94a3b8)', fontSize: 13, margin: 0 }}>{t('nt.desc.' + meta.id)}</p>
                </div>
                <Switch on={tpl.enabled} onChange={(v) => patch('enabled', v)} />
              </div>

              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', margin: '16px 0' }}>
                <Check label={t('nt.sendEmail')} checked={tpl.email} onChange={(v) => patch('email', v)} />
                <Check label={t('nt.sendSms')} checked={tpl.sms} onChange={(v) => patch('sms', v)} />
                {meta.scheduled && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginLeft: 'auto' }}>
                    <span style={{ fontSize: 13, color: 'var(--ccbd5e1)' }}>{t('nt.send')}</span>
                    <input type="number" min={0} value={tpl.offsetHours}
                      onChange={(e) => patch('offsetHours', Math.max(0, Number(e.target.value)))}
                      style={{ ...ui.input, width: 70, padding: '6px 8px' }} />
                    <span style={{ fontSize: 13, color: 'var(--ccbd5e1)' }}>
                      {t('nt.hours')} {meta.scheduled === 'after' ? t('nt.after') : meta.scheduled === 'day' ? t('nt.onDay') : t('nt.before')}
                    </span>
                  </div>
                )}
              </div>

              {/* Placeholder chips */}
              <div style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 12, color: 'var(--c94a3b8)', marginBottom: 6 }}>{t('nt.clickPlaceholder')}</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {PLACEHOLDERS.map((p) => (
                    <button key={p} onMouseDown={(e) => e.preventDefault()} onClick={() => insert(p)}
                      style={{ fontSize: 12, padding: '4px 9px', borderRadius: 999, border: '1px solid var(--c475569)', background: 'var(--c0f172a)', color: 'var(--ca5b4fc)', cursor: 'pointer' }}>
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              {tpl.email && (
                <>
                  <label style={ui.label}>{t('nt.emailSubject')}</label>
                  <input ref={subjectRef} onFocus={() => (focusedRef.current = 'subject')}
                    value={tpl.subject} onChange={(e) => patch('subject', e.target.value)}
                    style={{ ...ui.input, marginBottom: 14 }} />

                  <label style={ui.label}>{t('nt.emailBody')}</label>
                  <RichTextEditor editorRef={bodyRef} value={tpl.body}
                    onFocus={() => (focusedRef.current = 'body')}
                    onChange={(html) => patch('body', html)} />
                </>
              )}

              {tpl.sms && (
                <>
                  <label style={ui.label}>{t('nt.smsText')}</label>
                  <textarea ref={smsRef} onFocus={() => (focusedRef.current = 'smsBody')}
                    value={tpl.smsBody} onChange={(e) => patch('smsBody', e.target.value)} rows={3}
                    style={{ ...ui.input, fontFamily: 'inherit', lineHeight: 1.5, resize: 'vertical' }} />
                  <SmsCost id={selectedId} smsBody={tpl.smsBody} vn={vn} />
                </>
              )}
              {!tpl.email && !tpl.sms && (
                <p style={{ color: 'var(--c94a3b8)', fontSize: 13, margin: 0 }}>{t('nt.enableToEdit')}</p>
              )}
            </div>

            {/* Live preview */}
            <div>
              <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--c64748b)', margin: '0 0 8px 2px', fontWeight: 600 }}>{t('nt.preview')}</div>
              {tpl.email && <EmailPreview accent={accent} subject={fillPct(tpl.subject)} body={fillPct(tpl.body)} salon={SAMPLE.salon_name} contact={SAMPLE.salon_contact} />}
              {tpl.sms && <SmsPreview text={smsAsSent(selectedId, tpl.smsBody, vn)} salon={SAMPLE.salon_name} />}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function EmailPreview({ accent, subject, body, salon, contact }: { accent: string; subject: string; body: string; salon: string; contact: string }) {
  const { lang } = useLang();
  const t = (k: string) => tr(k, lang);
  return (
    <div style={{ background: '#fff', borderRadius: 12, overflow: 'hidden', border: '1px solid var(--c334155)', maxWidth: 520 }}>
      <div style={{ background: 'var(--c0f172a)', padding: '8px 12px', borderBottom: '1px solid var(--c334155)' }}>
        <div style={{ fontSize: 11, color: 'var(--c94a3b8)' }}>{t('nt.pSubject')}</div>
        <div style={{ fontSize: 13, color: 'var(--ce2e8f0)', fontWeight: 600 }}>{subject || t('nt.emptySubject')}</div>
      </div>
      <div style={{ background: accent, padding: '18px 22px' }}>
        <div style={{ color: '#fff', fontSize: 17, fontWeight: 700 }}>{salon}</div>
      </div>
      <div style={{ padding: 22, color: '#374151', fontSize: 14, lineHeight: 1.6 }} dangerouslySetInnerHTML={{ __html: body || `<em>${t('nt.emptyBody')}</em>` }} />
      <div style={{ background: '#f9fafb', padding: '12px 22px', color: '#4b5563', fontSize: 12, borderTop: '1px solid #eef0f4' }}>
        {salon} · {contact}
      </div>
    </div>
  );
}

/**
 * What one text costs, counted the way the carrier bills it: segments of 160
 * plain characters (153 once split), or 70 (67) as soon as one emoji or curly
 * quote is in it. Counted on the text as SENT — after the link and the
 * plain-text pass — so the number is the real one.
 */
function SmsCost({ id, smsBody, vn }: { id: string; smsBody: string; vn: boolean }) {
  const { lang } = useLang();
  const t = (k: string) => tr(k, lang);
  const sent = smsAsSent(id, smsBody, vn);
  const size = smsSegments(sent);
  const raw = fillPct(smsBody);
  const cleaned = !vn && toGsm7(raw) !== raw;
  const unknown = unknownTokens(smsBody);
  const warn = size.segments > 2;
  return (
    <div style={{ fontSize: 12, marginTop: 6, display: 'grid', gap: 4 }}>
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 8 }}>
        <span style={{
          padding: '2px 8px', borderRadius: 999, fontWeight: 700,
          background: warn ? 'var(--cfef3c7)' : 'var(--cf1f5f9)', color: warn ? 'var(--c78350f)' : 'var(--c334155)',
          border: `1px solid ${warn ? 'var(--cfed7aa)' : 'var(--ce2e8f0)'}`,
        }}>
          {t('nt.segments').replace('{n}', String(size.segments))}
        </span>
        <span style={{ color: 'var(--c64748b)' }}>
          {size.units} {t('nt.chars')}{size.encoding === 'UCS-2' ? ` · ${t('nt.unicode')}` : ''}
        </span>
      </div>
      {cleaned && <div style={{ color: 'var(--c64748b)' }}>{t('nt.plainNote')}</div>}
      {warn && <div style={{ color: 'var(--c78350f)' }}>{t('nt.segmentsTip')}</div>}
      {id === 'customer_booking_confirmed' && !vn && (
        <div style={{ color: 'var(--c64748b)' }}>
          {lang === 'vi'
            ? 'Để nguyên câu mặc định: Lumio tự viết tin gọn — ngày giờ, số người, từng dịch vụ, tổng tiền, link xem/huỷ — thường 1 tin, tối đa 2 tin. Bạn sửa câu thì hệ thống gửi đúng câu của bạn.'
            : 'Left as the default: Lumio writes a short text itself — date and time, party size, every service, total, manage link — usually 1 segment, never more than 2. Edit it and your own words are sent instead.'}
        </div>
      )}
      {unknown.length > 0 && (
        <div style={{ color: 'var(--c991b1b)' }}>{t('nt.unknownPh').replace('{list}', unknown.join(', '))}</div>
      )}
    </div>
  );
}

function SmsPreview({ text, salon }: { text: string; salon: string }) {
  const { lang } = useLang();
  const t = (k: string) => tr(k, lang);
  return (
    <div style={{ marginTop: 12, maxWidth: 520 }}>
      <div style={{ fontSize: 11, color: 'var(--c64748b)', marginBottom: 6 }}>{t('nt.smsFrom').replace('{salon}', salon)}</div>
      <div style={{ display: 'inline-block', background: 'var(--c1e293b)', border: '1px solid var(--c334155)', color: 'var(--ce2e8f0)', padding: '10px 14px', borderRadius: '14px 14px 14px 4px', fontSize: 13, lineHeight: 1.5, maxWidth: '90%', whiteSpace: 'pre-wrap' }}>
        {text || t('nt.emptyMsg')}
      </div>
    </div>
  );
}

/* ------------------------- Rich text editor ------------------------- */

function RichTextEditor({ editorRef, value, onChange, onFocus }: {
  editorRef: React.RefObject<HTMLDivElement>; value: string; onChange: (html: string) => void; onFocus: () => void;
}) {
  const { lang } = useLang();
  const t = (k: string) => tr(k, lang);
  // Sync external value → editor only when it differs (e.g. switching templates),
  // so typing isn't interrupted. Plain-text (legacy) values are shown with breaks.
  useEffect(() => {
    const el = editorRef.current;
    if (!el) return;
    const incoming = value || '';
    const html = /<[a-z][\s\S]*>/i.test(incoming)
      ? incoming
      : incoming.split(/\n{2,}/).map((p) => `<p>${p.replace(/\n/g, '<br>')}</p>`).join('');
    if (el.innerHTML !== html) el.innerHTML = html;
  }, [value, editorRef]);

  const exec = (cmd: string, arg?: string) => {
    editorRef.current?.focus();
    document.execCommand(cmd, false, arg);
    if (editorRef.current) onChange(editorRef.current.innerHTML);
  };

  const Btn = ({ cmd, arg, title, children }: { cmd: string; arg?: string; title: string; children: React.ReactNode }) => (
    <button type="button" title={title} onMouseDown={(e) => e.preventDefault()} onClick={() => exec(cmd, arg)} style={tbBtn}>{children}</button>
  );
  const Sep = () => <span style={{ width: 1, background: 'var(--c334155)', margin: '2px 4px' }} />;

  return (
    <div style={{ border: '1px solid var(--c475569)', borderRadius: 8, overflow: 'hidden', background: 'var(--c0f172a)' }}>
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 2, padding: 6, borderBottom: '1px solid var(--c334155)', background: 'var(--c1e293b)' }}>
        <Btn cmd="bold" title={t('nt.tBold')}><b>B</b></Btn>
        <Btn cmd="italic" title={t('nt.tItalic')}><i>I</i></Btn>
        <Btn cmd="underline" title={t('nt.tUnderline')}><u>U</u></Btn>
        <Btn cmd="strikeThrough" title={t('nt.tStrike')}><s>S</s></Btn>
        <Sep />
        <Btn cmd="formatBlock" arg="h3" title={t('nt.tHeading')}>H</Btn>
        <Btn cmd="formatBlock" arg="p" title={t('nt.tNormal')}>¶</Btn>
        <Sep />
        <Btn cmd="insertUnorderedList" title={t('nt.tBullet')}>• List</Btn>
        <Btn cmd="insertOrderedList" title={t('nt.tNumbered')}>1. List</Btn>
        <Sep />
        <button type="button" title={t('nt.tLink')} onMouseDown={(e) => e.preventDefault()}
          onClick={() => { const url = prompt(t('nt.linkPrompt')); if (url) exec('createLink', url); }} style={tbBtn}>🔗</button>
        <Btn cmd="removeFormat" title={t('nt.tClear')}>⨯</Btn>
      </div>
      <div
        ref={editorRef}
        contentEditable
        suppressContentEditableWarning
        onInput={() => { if (editorRef.current) onChange(editorRef.current.innerHTML); }}
        onFocus={onFocus}
        style={{ minHeight: 190, padding: 14, color: 'var(--ce2e8f0)', fontSize: 14, lineHeight: 1.6, outline: 'none' }}
      />
    </div>
  );
}
const tbBtn: React.CSSProperties = {
  minWidth: 30, height: 28, padding: '0 8px', borderRadius: 6, border: '1px solid var(--c334155)',
  background: 'var(--c0f172a)', color: 'var(--ccbd5e1)', fontSize: 13, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
};

/* ----------------------------- History ----------------------------- */

interface NotificationRow {
  id: string; channel: string; recipient: string; subject: string | null; body: string;
  status: string; provider: string; error: string | null; sentAt: string | null; createdAt: string;
}
const COLORS: Record<string, string> = { SENT: '#22c55e', PENDING: '#eab308', FAILED: '#ef4444' };

function HistoryView({ token }: { token: string | null }) {
  const { lang } = useLang();
  const t = (k: string) => tr(k, lang);
  const [items, setItems] = useState<NotificationRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!token) return;
    setLoading(true); setError(null);
    apiFetch<NotificationRow[]>('/notifications', { token })
      .then(setItems)
      .catch((e) => setError(e instanceof Error ? e.message : 'Failed to load history'))
      .finally(() => setLoading(false));
  }, [token]);

  if (error) return <div style={ui.banner}>{error}</div>;
  if (loading) return <p style={{ color: 'var(--c94a3b8)' }}>{t('nt.loading')}</p>;

  return (
    <div style={{ border: '1px solid var(--c334155)', borderRadius: 12, overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
        <thead>
          <tr style={{ background: 'var(--c1e293b)' }}>
            <th style={ui.th}>{t('nt.hSent')}</th><th style={ui.th}>{t('nt.hChannel')}</th><th style={ui.th}>{t('nt.hRecipient')}</th><th style={ui.th}>{t('nt.hMessage')}</th><th style={ui.th}>{t('nt.hStatus')}</th>
          </tr>
        </thead>
        <tbody>
          {items.length === 0 && <tr><td style={ui.td} colSpan={5}>{t('nt.noMessages')}</td></tr>}
          {items.map((n) => (
            <tr key={n.id} style={{ borderTop: '1px solid var(--c334155)' }}>
              <td style={{ ...ui.td, color: 'var(--c94a3b8)', whiteSpace: 'nowrap' }}>{fmtInTz(n.createdAt, { dateStyle: 'short', timeStyle: 'short' })}</td>
              <td style={ui.td}>{n.channel}</td>
              <td style={{ ...ui.td, color: 'var(--c94a3b8)' }}>{n.recipient}</td>
              <td style={ui.td}>
                {n.subject && <div style={{ fontWeight: 600 }}>{n.subject}</div>}
                <div style={{ color: 'var(--c94a3b8)', fontSize: 13 }}>{n.body}</div>
              </td>
              <td style={ui.td}>
                <span style={{ color: COLORS[n.status] ?? 'var(--c94a3b8)', fontWeight: 600 }}>{n.status}</span>
                {n.status === 'FAILED' && n.error && <div style={{ color: 'var(--cf87171)', fontSize: 11.5, marginTop: 3, maxWidth: 300, whiteSpace: 'normal', lineHeight: 1.4 }}>{n.error}</div>}
                {n.status !== 'FAILED' && n.provider === 'mock' && <div style={{ color: 'var(--cfbbf24)', fontSize: 11, marginTop: 3, maxWidth: 300, whiteSpace: 'normal', lineHeight: 1.4 }}>{lang === 'vi' ? '⚠ Chưa gửi thật — chưa kết nối Twilio/email' : '⚠ Not a real send — connect Twilio/email'}</div>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ----------------------------- small UI ----------------------------- */

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} style={{ padding: '7px 16px', borderRadius: 7, border: 'none', cursor: 'pointer', fontSize: 14, fontWeight: 600, background: active ? '#6366f1' : 'transparent', color: active ? '#fff' : 'var(--c94a3b8)' }}>{children}</button>
  );
}
function SubTab({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} style={{ padding: '6px 14px', borderRadius: 6, border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 600, background: active ? 'var(--c334155)' : 'transparent', color: active ? '#fff' : 'var(--c94a3b8)' }}>{children}</button>
  );
}
function Badge({ children }: { children: React.ReactNode }) {
  return <span style={{ fontSize: 10, padding: '2px 6px', borderRadius: 5, background: 'var(--c0f172a)', border: '1px solid var(--c334155)', color: 'var(--c94a3b8)' }}>{children}</span>;
}
function Dot({ on }: { on: boolean }) {
  return <span style={{ width: 8, height: 8, borderRadius: '50%', background: on ? '#22c55e' : 'var(--c475569)', flexShrink: 0 }} />;
}
function Switch({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!on)} style={{ width: 42, height: 24, borderRadius: 999, border: 'none', cursor: 'pointer', background: on ? '#6366f1' : 'var(--c475569)', position: 'relative', flexShrink: 0 }}>
      <span style={{ position: 'absolute', top: 3, left: on ? 21 : 3, width: 18, height: 18, borderRadius: '50%', background: '#fff', transition: 'left .15s' }} />
    </button>
  );
}
function Check({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!checked)} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 12px', borderRadius: 8, cursor: 'pointer', border: `1px solid ${checked ? '#6366f1' : 'var(--c334155)'}`, background: checked ? 'var(--c312e81)' : 'var(--c1e293b)', color: 'var(--ce2e8f0)', fontSize: 13 }}>
      <span style={{ width: 16, height: 16, borderRadius: 4, border: `2px solid ${checked ? 'var(--ca5b4fc)' : 'var(--c64748b)'}`, background: checked ? '#6366f1' : 'transparent', display: 'grid', placeItems: 'center', fontSize: 11, color: '#fff' }}>{checked ? '✓' : ''}</span>
      {label}
    </button>
  );
}
