import { GROUP_NOTICE_DELAY_MS, groupLead, groupSummary, visitPeople, type GroupMember } from './group-notice';
import { shouldConfirmOnCreate } from './auto-confirm';
import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Logger,
  Optional,
} from '@nestjs/common';
import { CustomersService } from '../customers/customers.service';
import { pastStartProblem } from './past-start';
import { createHmac, timingSafeEqual } from 'crypto';
import { signingSecret } from '../common/secret.util';
import { publicWebBase } from '../common/public-url.util';
import { formatMoney, localeForCountry } from '../common/money';
import { toE164, dialCodeFor } from '../common/phone';
import { fitsBusinessHours, describeWindows, windowsForDay } from '../settings/business-hours';
import { NO_SHOW_BLOCK_MESSAGE, NO_SHOW_POLICY_KEY, NoShowPolicy, cleanNoShowPolicy, noShowVerdict, windowStart } from './no-show-policy';
import { rebookCopy, recallDue, recallMonthsOf } from './recall';
import { buildPreOrder, preOrderText } from './pre-order';
import { skilledFor } from '../assignment/assignment.util';
import { blockingOff, busySpansFor, loadApprovedTimeOff, offWhen } from '../staff/time-off';
import { loadExtraHours, withExtraHours } from '../staff/extra-hours';
import { INDUSTRY_KEY, resolveIndustry } from '../common/industry';
import { buildClientCard, CardVisit } from './client-card';
import { capabilitiesFor } from '../auth/capabilities';
import { canSelfReschedule } from './self-reschedule';
import { canSelfCancel } from './self-cancel';
import { cancelMoney, DEFAULT_REFUND_HOURS, refundable, refundDeadline, type MoneyChoice } from './deposit-policy';
import { bufferOf, padSpan } from './buffer';
import { changeNoticeTargets, changePushText, ownerNoticeText } from './change-notices';
import { AppointmentStatus, NotificationChannel, OrderStatus, PaymentStatus, Prisma, RejectionType, UserRole, WalkInStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { AssignmentService } from '../assignment/assignment.service';
import { NotificationsService } from '../notifications/notifications.service';
import { PushService } from '../push/push.service';
import {
  BookingTemplateData,
  ReferralInvite,
  fill,
  fillPct,
  htmlToText,
  referralBlockHtml,
  referralBlockText,
  renderBookingEmailHtml,
  renderBookingEmailText,
  renderTemplatedEmailHtml,
} from '../notifications/email-template';
import { SettingsService } from '../settings/settings.service';
import { ReminderSettings, ReviewSettings, RebookingSettings, DEFAULT_NOTIFICATION_SETTINGS, DEFAULT_NOTIFICATION_TEMPLATES, LEGACY_NOTIFICATION_DEFAULTS, LEGACY_TEMPLATE_DEFAULTS, VN_NOTIFICATION_TEXTS, VN_TEMPLATE_TEXTS } from '../settings/settings.constants';
import { customerBookingSms, ownerBookingSms } from '../notifications/booking-sms';
import { PaymentsService } from '../payments/payments.service';
import { ReferralService } from '../referral/referral.service';
import { TrashService } from '../maintenance/trash.service';
import { AuthenticatedUser, resolveTenantScope } from '../common/tenant/tenant-context';
import { CreateBookingDto } from './dto/create-booking.dto';
import { ListBookingsDto } from './dto/list-bookings.dto';
import { addMinutes, parseStartTime, BLOCKING_STATUSES, wallTimeToUtc, planLineTechnician, lineStaffIds } from './booking.util';
import { clashMessage, stretchMayOverlap, type Lang as StretchLang } from './stretch-policy';
import { matchMissedToVisits, pairTicketWithBooking } from '../walkins/booking-link';
import { WalkinsService } from '../walkins/walkins.service';
import { deskUserIds } from '../walkins/overdue-alert';
import { repairTillLinks } from './till-repair';
import { dayKeyTz, startOfDayTz } from '../common/salon-time';
import { openTimesFor, type BusyBlock } from './open-times';
import { hasPromoWindow, inPromoWindow, salonYmd, type PromoWindow } from '../settings/promo-window';
import { appliesOn, channelOfSource, type SaleChannel } from '../settings/promo-channel';

const BOOKING_INCLUDE = {
  customer: { select: { id: true, firstName: true, lastName: true, email: true, phone: true } },
  service: { select: { id: true, name: true, durationMinutes: true } },
  assignedStaff: { select: { id: true, firstName: true, lastName: true } },
  table: { select: { id: true, name: true, seats: true } },
  preferredStaff: { select: { id: true, firstName: true, lastName: true } },
  // Lightweight payment summary so the calendar/list can show "paid / unpaid".
  // type + createdAt: the drawer says "waiting for the online deposit since…" for an open hold.
  payments: { select: { status: true, amountCents: true, type: true, createdAt: true } },
} satisfies Prisma.AppointmentInclude;

// Minimal shape of the Prisma transaction client we rely on (keeps the file
// testable with a lightweight mock).
type Tx = Prisma.TransactionClient;


/**
 * Turns the stored `source` code into something a salon owner reads as a
 * sentence. "hosted" is the name of a code path, not an answer to "where did
 * this booking come from".
 */
function bookingSourceLabel(source: string | null | undefined, vi: boolean): string {
  const key = (source ?? '').toLowerCase();
  const en: Record<string, string> = {
    hosted: 'Online booking page', online: 'Online booking page', admin: 'Front desk',
    messenger: 'Facebook Messenger', instagram: 'Instagram', zalo: 'Zalo',
    web: 'Website chat', voice: 'Phone (AI)', walkin: 'Walk-in', pos: 'Front desk',
  };
  const viMap: Record<string, string> = {
    hosted: 'Trang đặt lịch online', online: 'Trang đặt lịch online', admin: 'Quầy lễ tân',
    messenger: 'Facebook Messenger', instagram: 'Instagram', zalo: 'Zalo',
    web: 'Chat trên website', voice: 'Điện thoại (AI)', walkin: 'Khách vãng lai', pos: 'Quầy lễ tân',
  };
  const map = vi ? viMap : en;
  return map[key] ?? (source ?? '');
}

/** Same rule as the booking form: digits/()+-. only, 8–15 digits. */
function isValidPhoneNumber(v: string): boolean {
  const digits = v.replace(/\D/g, '');
  return /^\+?[0-9\s().-]+$/.test(v) && digits.length >= 8 && digits.length <= 15;
}

/** How long a booking lasts when the service itself has no length set. */
export const DEFAULT_SERVICE_MINUTES = 30;

@Injectable()
export class BookingsService {
  // Self-service reschedules are executed by a language model on behalf of the
  // public. Every allow and every refusal is logged with its reason, because
  // "why did my appointment move" has to be answerable afterwards.
  private readonly logger = new Logger(BookingsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly assignment: AssignmentService,
    private readonly notifications: NotificationsService,
    private readonly settings: SettingsService,
    private readonly payments: PaymentsService,
    private readonly referral: ReferralService,
    private readonly push: PushService,
    private readonly trash: TrashService,
    // Correcting a booking's contact (updateContact). Optional so the unit tests build it bare.
    @Optional() private readonly customers?: CustomersService,
    // The client's open floor ticket follows a change of technician (followOnFloor).
    @Optional() private readonly walkins?: WalkinsService,
  ) {}

  /**
   * The booking changed technician while the client may already be in the
   * salon: move her floor ticket too (walkins/booking-tech-sync.ts), or the old
   * tech keeps the "Right now" card and the new one cannot write the SOAP note.
   * Never fails the booking change; a failure is logged with its cause.
   */
  private async followOnFloor(tenantId: string, id: string, from: string | null, to: string | null | undefined, serviceId?: string) {
    if (!this.walkins || !to || (!serviceId && from === to)) return;
    try {
      await this.walkins.followBooking(tenantId, id, from, to, serviceId);
    } catch (e) {
      this.logger.warn(`booking ${id}: the floor ticket could not follow the new technician — ${e instanceof Error ? e.message : String(e)}`);
    }
  }

  private tenantId(user: AuthenticatedUser): string {
    const id = resolveTenantScope(user);
    if (!id) {
      throw new NotFoundException('No tenant context');
    }
    return id;
  }

  /**
   * The desk corrects who a booking is for — name, phone, email, birthday.
   * The client record is corrected (or the booking moves to the client the
   * phone belongs to), and a ticket already checked in follows.
   */
  async updateContact(user: AuthenticatedUser, id: string, dto: { firstName: string; lastName?: string; phone?: string; email?: string; birthDate?: string }) {
    const tenantId = this.tenantId(user);
    if (!this.customers) throw new BadRequestException('Not available');
    const appt = await this.prisma.appointment.findFirst({ where: { id, tenantId }, select: { id: true, customerId: true } });
    if (!appt) throw new NotFoundException('Booking not found');
    if (dto.phone?.trim() && !isValidPhoneNumber(dto.phone.trim())) {
      throw new BadRequestException('Please enter a valid phone number (8–15 digits).');
    }
    const res = await this.customers.correctVisitContact(tenantId, appt.customerId, dto);
    const customerId = res.customerId ?? appt.customerId;
    if (customerId !== appt.customerId) {
      await this.prisma.appointment.updateMany({ where: { id: appt.id, tenantId }, data: { customerId } });
    }
    const name = [dto.firstName.trim(), (dto.lastName ?? '').trim()].filter(Boolean).join(' ').slice(0, 80);
    const phone = (dto.phone ?? '').trim().slice(0, 40);
    await this.prisma.walkIn.updateMany({
      where: { tenantId, appointmentId: appt.id },
      data: { customerName: name, customerId, ...(phone ? { phone } : {}) } as never,
    }).catch(() => undefined);
    await this.audit.log({ tenantId, userId: user.userId, action: 'booking.contact_updated', resourceType: 'appointment', resourceId: appt.id, metadata: { switched: res.switched } });
    return { id: appt.id, customerId, switched: res.switched, emailSkipped: res.emailSkipped };
  }

  /**
   * "Tìm khách" in the booking drawer: the booking is moved to ANOTHER client —
   * one on file (picked by id, this salon's only) or a new one created from a
   * name and a phone / email (an existing client with that phone is reused).
   * The old client's record is not touched (updateContact corrects a record;
   * this changes whose visit it is). A ticket already checked in follows.
   */
  async switchCustomer(user: AuthenticatedUser, id: string, dto: { customerId?: string; firstName?: string; lastName?: string; phone?: string; email?: string }) {
    const tenantId = this.tenantId(user);
    const appt = await this.prisma.appointment.findFirst({ where: { id, tenantId }, select: { id: true, customerId: true } });
    if (!appt) throw new NotFoundException('Booking not found');
    let target: { id: string; firstName: string; lastName: string | null; phone: string | null } | null = null;
    if (dto.customerId) {
      target = await this.prisma.customer.findFirst({ where: { id: dto.customerId, tenantId }, select: { id: true, firstName: true, lastName: true, phone: true } });
      if (!target) throw new NotFoundException('Customer not found');
    } else {
      if (!this.customers) throw new BadRequestException('Not available');
      if (!(dto.firstName ?? '').trim()) throw new BadRequestException('Enter the client\'s name.');
      if (dto.phone?.trim() && !isValidPhoneNumber(dto.phone.trim())) throw new BadRequestException('Please enter a valid phone number (8–15 digits).');
      const made = await this.customers.findOrCreateByContact(tenantId, dto);
      if (!made) throw new BadRequestException('A phone number or email is needed for a new client.');
      target = { id: made.id, firstName: made.firstName, lastName: made.lastName ?? null, phone: made.phone ?? null };
    }
    if (target.id === appt.customerId) return { id: appt.id, customerId: target.id, changed: false };
    await this.prisma.appointment.updateMany({ where: { id: appt.id, tenantId }, data: { customerId: target.id } });
    const name = [target.firstName, target.lastName ?? ''].filter(Boolean).join(' ').trim().slice(0, 80);
    await this.prisma.walkIn.updateMany({
      where: { tenantId, appointmentId: appt.id },
      data: { customerName: name, customerId: target.id, ...(target.phone ? { phone: target.phone } : {}) } as never,
    }).catch(() => undefined);
    await this.audit.log({ tenantId, userId: user.userId, action: 'booking.customer_switched', resourceType: 'appointment', resourceId: appt.id, metadata: { from: appt.customerId, to: target.id, created: !dto.customerId } });
    return { id: appt.id, customerId: target.id, changed: true };
  }

  /**
   * Throws ConflictException if the staff member already has a blocking
   * appointment overlapping [start, end). Half-open intervals: existingStart <
   * newEnd AND existingEnd > newStart.
   */
  private async assertNoOverlap(
    tx: Tx,
    tenantId: string,
    staffId: string,
    start: Date,
    end: Date,
    ignoreAppointmentId?: string,
    /** The salon's rest gap (bookings/buffer.ts); 0 = back to back allowed. */
    bufferMin = 0,
  ): Promise<void> {
    const pad = Math.max(0, bufferMin) * 60_000;
    const conflict = await tx.appointment.findFirst({
      where: {
        tenantId,
        assignedStaffId: staffId,
        status: { in: BLOCKING_STATUSES },
        startTime: { lt: new Date(end.getTime() + pad) },
        endTime: { gt: new Date(start.getTime() - pad) },
        ...(ignoreAppointmentId ? { id: { not: ignoreAppointmentId } } : {}),
      },
      select: { id: true },
    });
    if (conflict) {
      throw new ConflictException(bufferMin > 0
        ? `Staff member is already booked for this time slot (the salon keeps ${bufferMin} minutes between appointments)`
        : 'Staff member is already booked for this time slot');
    }
    await this.assertNotOff(tx, tenantId, staffId, start, end);
  }

  /**
   * TIME OFF IS NOT BOOKABLE — by anyone, the desk included.
   *
   * Approved time off already hid the technician from the booking page, the
   * bots and the engine, but the desk could still type a booking straight onto
   * her day off. A temporary block from the Calendar is the same row (with no
   * technician for the whole salon). Every path that puts time on a
   * technician runs assertNoOverlap, which ends here; a booking with no
   * technician is checked against the whole-salon blocks only. No override:
   * the owner removes the block instead. If the rows cannot be read, the
   * booking goes through (the availability screens already hid the time).
   */
  private async assertNotOff(db: Tx | PrismaService, tenantId: string, staffId: string | null, start: Date, end: Date): Promise<void> {
    const fmt = (tz: string, d: Date) => new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
    let tz = 'UTC';
    try { tz = (await db.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }))?.timezone || 'UTC'; } catch { /* keep UTC */ }
    let from = '', to = '';
    try { from = fmt(tz, new Date(start.getTime() - 86_400_000)); to = fmt(tz, new Date(end.getTime() + 86_400_000)); } catch { tz = 'UTC'; from = fmt(tz, start); to = fmt(tz, end); }
    const offs = await loadApprovedTimeOff(db, tenantId, from, to, staffId ? [staffId] : []);
    const hit = blockingOff(offs, staffId, start, end, tz);
    if (!hit) return;
    if (hit.staffId == null) {
      throw new ConflictException(`BLOCKED: the salon has blocked ${offWhen(hit)}. Pick another time.`);
    }
    const st = await db.staffMember.findFirst({ where: { id: hit.staffId, tenantId }, select: { firstName: true } }).catch(() => null);
    throw new ConflictException(`TIME_OFF: ${st?.firstName ?? 'This technician'} is off ${offWhen(hit)}. Pick another technician or another time.`);
  }

  /** The salon's rest gap between a technician's appointments, in minutes. */
  private async bufferMinutes(tenantId: string): Promise<number> {
    return bufferOf(await this.settings.getBookingRules(tenantId).catch(() => null));
  }

  /**
   * Serialize concurrent bookings for the same (tenant, staff) so two requests
   * cannot both pass the overlap check and double-book. The transaction-scoped
   * advisory lock is released automatically when the transaction ends.
   */
  private lockStaffSlot(tx: Tx, tenantId: string, staffId: string) {
    return tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${`${tenantId}:${staffId}`}))`;
  }

  private async assertStaffActive(tenantId: string, staffId: string) {
    const staff = await this.prisma.staffMember.findFirst({
      where: { id: staffId, tenantId, isActive: true, takesAppointments: true },
      select: { id: true },
    });
    if (!staff) {
      throw new BadRequestException('Staff member not found or not bookable for this tenant');
    }
  }

  /**
   * Best promo % a service gets on the booking's date: the HIGHER of the
   * recurring weekday-discount rules and the specific-date rules (a sale on exact
   * dates / date ranges), matched by the service's category. Returns 0 when
   * nothing applies. Read straight from the settings rows to avoid a cross-module
   * dependency.
   */
  private async promoDiscountPercent(tenantId: string, start: Date, categoryId: string | null, where: SaleChannel = 'online'): Promise<number> {
    try {
      const tenant = await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } });
      const tz = tenant?.timezone || 'UTC';
      const [wdRow, dtRow] = await Promise.all([
        this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: 'weekday_discounts' } } }),
        this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: 'date_discounts' } } }),
      ]);
      let best = 0;

      // Recurring weekday rules (matched by salon-local weekday).
      const wd = wdRow?.value as ({ enabled?: boolean; rules?: Array<{ day: number; categoryId: string | null; percent: number }> } & PromoWindow) | undefined;
      // Run dates bound the whole weekday program (e.g. "Tuesdays −10% until Oct 25").
      // …and only where the salon runs it (online only / walk-ins only / everywhere).
      if (wd?.enabled && Array.isArray(wd.rules) && appliesOn(wd, where) && inPromoWindow(wd, salonYmd(start, tz))) {
        // en-US on purpose: this reads the weekday NAME back into an index via
        // the map below. It is a parser, not something anybody sees.
        const wdName = new Intl.DateTimeFormat('en-US', { timeZone: tz, weekday: 'short' }).format(start);
        const map: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
        const weekday = map[wdName] ?? start.getDay();
        for (const r of wd.rules) {
          if (r.day !== weekday) continue;
          if (r.categoryId && r.categoryId !== categoryId) continue;
          if (r.percent > best) best = r.percent;
        }
      }

      // Specific-date rules (exact dates / ranges) — take the higher of the two.
      const dt = dtRow?.value as { enabled?: boolean; rules?: Array<{ startDate: string; endDate: string | null; categoryId: string | null; percent: number }> } | undefined;
      if (dt?.enabled && Array.isArray(dt.rules)) {
        const localDate = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(start);
        for (const r of dt.rules) {
          if (!r?.startDate) continue;
          if (!appliesOn(r, where)) continue;
          if (r.categoryId && r.categoryId !== categoryId) continue;
          const end = r.endDate || r.startDate;
          if (r.startDate <= localDate && localDate <= end && r.percent > best) best = r.percent;
        }
      }

      return Math.min(90, Math.max(0, best));
    } catch {
      return 0;
    }
  }

  /** Category-independent program promos: first-visit (verified new customer)
   *  and group size (party of 2+). Returns the single BEST % — program promos
   *  never stack with each other or with weekday/date rules (max wins), and a
   *  promo lookup failure must never break booking. */
  private async programDiscountPercent(tenantId: string, dto: CreateBookingDto, visitAt?: Date, where: SaleChannel = 'online'): Promise<number> {
    let best = 0;
    try {
      // The salon-local day of the visit, for programs with run dates. Looked
      // up only when a program has one, so open-ended programs cost nothing.
      let visitDay: string | null = null;
      const dayOfVisit = async (): Promise<string> => {
        if (visitDay) return visitDay;
        let tz: string | null = null;
        try { tz = (await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }))?.timezone ?? null; } catch { tz = null; }
        // The visit's real instant when the caller has it (startTime may be a
        // salon wall time with no zone).
        const at = visitAt ?? (dto.startTime ? new Date(dto.startTime) : new Date());
        visitDay = salonYmd(Number.isNaN(at.getTime()) ? new Date() : at, tz);
        return visitDay;
      };
      const running = async (w: PromoWindow | undefined) => !hasPromoWindow(w) || inPromoWindow(w, await dayOfVisit());
      const [fvRow, grRow] = await Promise.all([
        this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: 'first_visit_discount' } } }),
        this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: 'group_discount' } } }),
      ]);

      // Visit-based tiers — identity must be verifiable (phone/email given).
      // visitNumber = completed/arrived visits so far + 1 (the visit being booked);
      // a tier fires only on its EXACT visit number (visit 1 = brand-new customer,
      // visit 5 = returning-customer thank-you, etc.).
      const fv = fvRow?.value as ({ enabled?: boolean; percent?: number; rules?: Array<{ visit?: number; percent?: number }> } & PromoWindow) | undefined;
      const rawPhone = (dto.customerPhone || '').trim();
      const phone = (await this.normalizedPhone(tenantId, rawPhone)) ?? '';
      const email = (dto.customerEmail || '').trim().toLowerCase();
      if (fv?.enabled && (phone || email) && appliesOn(fv, where) && (await running(fv))) {
        const rules = Array.isArray(fv.rules) && fv.rules.length
          ? fv.rules
          : ((fv.percent ?? 0) > 0 ? [{ visit: 1, percent: fv.percent! }] : []);
        if (rules.length) {
          const or: Prisma.CustomerWhereInput[] = [];
          // Both shapes: rows written before normalisation still hold the raw text.
          if (phone) or.push({ phone });
          if (rawPhone && rawPhone !== phone) or.push({ phone: rawPhone });
          if (email) or.push({ email });
          const existing = await this.prisma.customer.findFirst({ where: { tenantId, OR: or }, select: { id: true } });
          const visits = existing
            ? await this.prisma.appointment.count({
                where: { tenantId, customerId: existing.id, status: { in: [AppointmentStatus.ARRIVED, AppointmentStatus.COMPLETED] } },
              })
            : 0;
          const visitNumber = visits + 1;
          const hit = rules.find((r) => (r?.visit ?? 0) === visitNumber);
          if (hit && (hit.percent ?? 0) > 0) best = Math.max(best, Math.min(90, hit.percent!));
        }
      }

      // Group size — best tier whose minSize the party reaches.
      const gr = grRow?.value as ({ enabled?: boolean; tiers?: Array<{ minSize?: number; percent?: number }> } & PromoWindow) | undefined;
      const size = dto.partySize ?? 1;
      if (gr?.enabled && Array.isArray(gr.tiers) && size >= 2 && appliesOn(gr, where) && (await running(gr))) {
        for (const t of gr.tiers) {
          if ((t?.minSize ?? 99) <= size && (t?.percent ?? 0) > best) best = t.percent!;
        }
      }
    } catch {
      best = 0; // promos are best-effort
    }
    return Math.min(90, Math.max(0, best));
  }

  /**
   * The customer's phone in one canonical shape, read with the salon's country.
   *
   * Two people are the same person whether they typed "0912 345 678",
   * "0912345678" or "+84 912 345 678"; a database that stores whichever one
   * they happened to type will insist they are three. Falls back to the trimmed
   * input when the number cannot be normalised, so nothing is ever lost.
   */
  private async normalizedPhone(tenantId: string, raw?: string | null): Promise<string | null> {
    const trimmed = String(raw ?? '').trim();
    if (!trimmed) return null;
    try {
      const [t, extra] = await Promise.all([
        this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }),
        this.prisma.setting.findFirst({ where: { tenantId, key: 'company_extra' }, select: { value: true } }),
      ]);
      const country = (extra?.value as { country?: string } | null)?.country ?? '';
      return toE164(trimmed, dialCodeFor(country, t?.timezone)) ?? trimmed;
    } catch {
      return trimmed;
    }
  }

  /**
   * `typedByCustomer`: the person on the salon's own booking form or plugin
   * typed these details themselves, for THIS booking. Their name is then the
   * name on the visit. (Not the hotline or a chat bot, which write down what
   * they heard — those keep the name on file.)
   */
  private async upsertCustomer(tx: Tx, tenantId: string, dto: CreateBookingDto, trusted = false, typedByCustomer = false) {
    // Only ever upgrade consent to true (never silently revoke a prior opt-in
    // just because a returning customer left the box unchecked this time).
    const consent = dto.smsConsent === true ? { smsConsent: true, smsConsentAt: new Date() } : {};
    // Optional birthday the customer shared. Only set it when given (and valid) —
    // a returning customer who leaves it blank keeps the birthday we already have.
    const birth = (() => {
      if (!dto.customerBirthDate) return undefined;
      const d = new Date(dto.customerBirthDate);
      return isNaN(d.getTime()) ? undefined : d;
    })();
    const birthData = birth ? { birthDate: birth } : {};
    // Referral attribution applies to NEW customers only (the `create` branches),
    // so a returning customer is never re-attributed.
    const referredById = await this.referral.resolveReferrerId(tx, tenantId, dto.referralCode);
    const referredBy = referredById ? { referredById } : {};
    const phone = await this.normalizedPhone(tenantId, dto.customerPhone);
    const digits = (v: unknown) => String(v ?? '').replace(/\D/g, '').slice(-10);
    // An email already on another record whose phone is DIFFERENT from the one
    // typed now: that record is not this booking's contact (see below).
    let emailTaken = false;
    if (dto.customerEmail) {
      const email = dto.customerEmail.toLowerCase();
      // Anyone can type an email on the public page, the plugin or a chat. For
      // them an existing record keeps its name and phone (a surname or a phone
      // is only ever added) — otherwise typing someone's email re-pointed their
      // reminders to a stranger's phone. The salon's own staff still update.
      if (!trusted) {
        const known = await tx.customer.findUnique({ where: { tenantId_email: { tenantId, email } }, select: { id: true, firstName: true, lastName: true, phone: true } });
        // The email is on file with ANOTHER phone. Booking onto that record
        // sent the confirmation, the reminders and the visit to the old number
        // and the old name — "I typed my new details and it booked the old
        // ones". The phone typed now is this booking's contact, so the booking
        // follows the phone (below); the other record is left untouched.
        if (known && known.phone && phone && digits(known.phone) !== digits(phone)) {
          emailTaken = true;
        } else if (known) {
          const typedFirst = String(dto.customerFirstName ?? '').trim();
          return tx.customer.update({
            where: { id: known.id },
            data: {
              firstName: typedByCustomer && typedFirst ? typedFirst : (String(known.firstName ?? '').trim() || dto.customerFirstName),
              lastName: typedByCustomer && typedFirst ? (dto.customerLastName?.trim() || String(known.lastName ?? '').trim() || null) : (String(known.lastName ?? '').trim() || dto.customerLastName || null),
              phone: known.phone || phone,
              ...consent,
              ...birthData,
            },
          });
        }
      }
      if (!emailTaken) return tx.customer.upsert({
        where: { tenantId_email: { tenantId, email } },
        update: {
          firstName: dto.customerFirstName,
          lastName: dto.customerLastName ?? null,
          phone,
          ...consent,
          ...birthData,
        },
        create: {
          tenantId,
          email,
          firstName: dto.customerFirstName,
          lastName: dto.customerLastName ?? null,
          phone,
          ...consent,
          ...birthData,
          ...referredBy,
        },
      });
    }
    // No email: the phone IS the identity, and in most of the world it is the
    // only one a customer gives. Without this every booking made by the same
    // person created a NEW customer — so their visit count never grew, their
    // history never gathered, and a first-visit discount fired every time.
    // Matched on the normalised number and on whatever was stored before
    // normalisation existed, so returning customers are recognised either way.
    if (phone) {
      const raw = String(dto.customerPhone ?? '').trim();
      const existing = await tx.customer.findFirst({
        where: { tenantId, OR: raw && raw !== phone ? [{ phone }, { phone: raw }] : [{ phone }] },
        select: { id: true },
        orderBy: { createdAt: 'asc' },
      });
      if (existing) {
        // A returning customer keeps the name already on file unless this
        // booking carries a fuller one. The hotline hears one spoken word and
        // the AI writes down what it heard, so "Trang" arrived as "Chang" and
        // renamed a five-year customer — and passing lastName straight through
        // wiped the surname a receptionist had typed in. A surname is only
        // ever added here, never blanked.
        const known = await tx.customer.findUnique({ where: { id: existing.id }, select: { firstName: true, lastName: true } });
        const keepFirst = String(known?.firstName ?? '').trim();
        const keepLast = String(known?.lastName ?? '').trim();
        // Typed on the booking form by the customer: what they typed is the name.
        const typedFirst = typedByCustomer ? String(dto.customerFirstName ?? '').trim() : '';
        return tx.customer.update({
          where: { id: existing.id },
          data: {
            firstName: typedFirst || keepFirst || dto.customerFirstName,
            lastName: typedFirst ? (dto.customerLastName?.trim() || keepLast || null) : (dto.customerLastName ?? (keepLast || null)),
            phone,
            ...consent,
            ...birthData,
          },
        });
      }
    }
    return tx.customer.create({
      data: {
        tenantId,
        firstName: dto.customerFirstName,
        lastName: dto.customerLastName ?? null,
        phone,
        ...consent,
        ...birthData,
        ...referredBy,
      },
    });
  }

  // Salon Admin create (tenant from the JWT).
  async create(user: AuthenticatedUser, dto: CreateBookingDto, source?: string) {
    // Booking outside opening hours on purpose is the owner's call alone.
    const owner = user.role === 'SALON_ADMIN' || user.role === 'SUPER_ADMIN';
    const clean = Object.assign(Object.create(Object.getPrototypeOf(dto)), dto, { outsideHours: owner ? dto.outsideHours === true : false }) as CreateBookingDto;
    // No technician chosen at the desk: the engine picks one now (turns, skills,
    // who is free at that time), exactly as for an online booking — the salon's
    // assignment mode still decides. `autoAssign: false` leaves it open on purpose.
    const autoAssign = !clean.staffId && clean.autoAssign !== false;
    // THE CUSTOMER IS ALREADY HERE. The desk books someone standing at the
    // counter: the booking must read "Đã đến", not Pending — a Pending visit
    // in the chair is how the midnight sweep marks a customer who came as a
    // no-show. Only for a start near now: "arrived" on next Tuesday is a typo.
    const tenantId = this.tenantId(user);
    const arrivedNow = clean.arrivedNow === true && arrivedNowApplies(new Date(clean.startTime), new Date());
    delete (clean as { arrivedNow?: boolean }).arrivedNow;
    // Booked by the salon itself (on the phone, at the counter): the customer
    // already agreed, so it is CONFIRMED on creation — no second confirm.
    const created = await this.createForTenant(tenantId, clean, user.userId, source, null, { autoAssign, deskConfirm: true, ...(arrivedNow ? { quiet: true } : {}) });
    if (!arrivedNow || !created) return created;
    const ids = [(created as { id: string }).id];
    const at = new Date();
    const r = await this.prisma.appointment.updateMany({
      where: { id: { in: ids }, tenantId, status: { in: BookingsService.ACTIONABLE } },
      data: { status: AppointmentStatus.ARRIVED, arrivedAt: at },
    });
    if (r.count) {
      await this.audit.log({ tenantId, userId: user.userId, action: 'booking.arrived', resourceType: 'appointment', resourceId: ids[0], metadata: { at: 'create' } });
      // On the floor too, exactly like pressing Check-in: a ticket tied to the
      // booking, its technician starting now. Best-effort — the booking is
      // ARRIVED either way; a failure is logged with its cause.
      if (this.walkins) {
        await this.walkins.seatAppointment(user, ids[0]).catch((e) => {
          this.logger.warn(`arrived-now booking ${ids[0]} not seated on the floor: ${e instanceof Error ? e.message : String(e)}`);
        });
      }
    }
    return (await this.prisma.appointment.findFirst({ where: { id: ids[0], tenantId }, include: BOOKING_INCLUDE })) ?? created;
  }

  /**
   * Core booking creation, scoped to an explicit tenantId. Used both by the
   * Salon Admin flow and by the public/WordPress flow (where the tenant comes
   * from the API key, not a logged-in user). Race-safe when a staff is given.
   */
  /**
   * Restaurant reservations: pick the smallest active table whose seat count
   * fits the party and that is not already occupied for the requested time.
   * Returns null when nothing is free (the reservation is left table-less so the
   * host can seat it manually). Scoped to tenantId — never crosses tenants.
   */
  private async findFreeTable(
    tx: Prisma.TransactionClient,
    tenantId: string,
    start: Date,
    end: Date,
    partySize: number,
    preferArea?: string,
  ): Promise<string | null> {
    const tables = await tx.restaurantTable.findMany({
      where: { tenantId, isActive: true, seats: { gte: Math.max(1, partySize) } },
      orderBy: [{ seats: 'asc' }, { sortOrder: 'asc' }],
      select: { id: true, area: true },
    });
    if (tables.length === 0) return null;
    if (preferArea) tables.sort((a: { area: string | null }, b: { area: string | null }) => (a.area === preferArea ? 0 : 1) - (b.area === preferArea ? 0 : 1));
    const busy = await tx.appointment.findMany({
      where: {
        tenantId,
        tableId: { in: tables.map((t: { id: string }) => t.id) },
        status: { notIn: [AppointmentStatus.CANCELLED, AppointmentStatus.NO_SHOW] },
        startTime: { lt: end },
        endTime: { gt: start },
      },
      select: { tableId: true },
    });
    const taken = new Set(busy.map((b: { tableId: string | null }) => b.tableId));
    const free = tables.find((t: { id: string }) => !taken.has(t.id));
    return free ? free.id : null;
  }

  async createForTenant(
    tenantId: string,
    dto: CreateBookingDto,
    actorUserId: string | null,
    source?: string,
    device?: string | null,
    /**
     * `autoAssign` asks the engine to pick a technician BEFORE the confirmation
     * is written. The online page and the chat bot used to create the booking,
     * let the confirmation fly, and assign a technician a few milliseconds
     * later — so every hosted booking told the customer "To be assigned" even
     * though a tech had been chosen by the time they opened the mail.
     */
    /**
     * `groupGuest` — SERVER-SIDE CALLERS ONLY, never read from a request body.
     * The second, third… person in a group the hotline books: "me and my two
     * friends" gives one phone number and three first names. The guests carry
     * no contact of their own (their own number would merge them into the
     * caller's customer record), so the phone rule below is waived for them —
     * the person who called is the group's contact.
     */
    /** `quiet` — the customer is at the counter (arrivedNow): no "your booking is confirmed" text. */
    /**
     * `deskConfirm` — SERVER-SIDE CALLERS ONLY (BookingsService.create). The
     * salon booked it itself, with the customer on the phone or at the counter:
     * the booking is CONFIRMED as soon as it exists. Before, it sat at "Chờ
     * xác nhận" and the desk had to confirm a booking it had just made. A
     * salon that has technicians accept in the app (staffMustAccept) keeps the
     * technician's accept step for a booking that has a technician.
     */
    opts?: { autoAssign?: boolean; groupGuest?: boolean; quiet?: boolean; deskConfirm?: boolean },
  ) {
    // Contact rules. Online (public) customer bookings MUST include a phone number
    // — it is the salon's primary way to reach the client and it cuts down on spam
    // bookings. Admin-created bookings need NO contact at all: the person is at
    // the desk or on the phone with staff, exactly like a walk-in — reminders
    // and confirmations are simply skipped when there is nowhere to send them.
    const contactEmail = dto.customerEmail?.trim();
    const contactPhone = dto.customerPhone?.trim();
    const isPublicBooking = actorUserId === null;
    if (isPublicBooking && !contactPhone && !opts?.groupGuest) {
      throw new BadRequestException('A phone number is required to book.');
    }
    if (contactPhone && !isValidPhoneNumber(contactPhone)) {
      throw new BadRequestException('Please enter a valid phone number (8–15 digits).');
    }

    // Anti-spam velocity cap: a single phone number may create at most a handful
    // of PUBLIC bookings per rolling 24h for one salon. Stops a competitor who
    // scripts the public form with one number to flood the calendar and burn the
    // salon's SMS credit. Admin-created bookings are never capped.
    if (isPublicBooking && contactPhone) {
      const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const recent = await this.prisma.appointment.count({
        where: { tenantId, createdAt: { gte: since }, customer: { phone: contactPhone } },
      });
      // A phone call is not a scripted form: the number is the carrier's
      // caller ID and every minute is metered. A family booking twice in a day
      // by phone used to hit the web form's cap and the assistant could only
      // say "please call the salon" — to someone already calling the salon.
      if (recent >= (source === 'hotline' ? 20 : 6)) {
        throw new BadRequestException('You have reached the maximum number of online bookings for today. Please call the salon to book again.');
      }
    }

    // The salon's no-show policy (bookings/no-show-policy.ts): off unless the
    // owner set "refuse online from N no-shows". The desk can always book.
    if (isPublicBooking && contactPhone && !opts?.groupGuest) {
      await this.assertNoShowPolicy(tenantId, contactPhone);
    }

    const service = await this.prisma.service.findFirst({
      where: { id: dto.serviceId, tenantId, isActive: true },
    });
    if (!service) {
      throw new NotFoundException('Service not found or inactive');
    }
    // First come, first served: the salon takes this line walk-in only.
    // Online, chat, hotline and the desk alike — the walk-in board is where
    // it belongs (the owner clears the flag on the service to book it again).
    if ((service as { walkInOnly?: boolean }).walkInOnly) {
      throw new BadRequestException(walkInOnlyMessage(service.name));
    }

    // Where it happens, when not at the business (a property to view, a client's home).
    const location = dto.location?.replace(/\s+/g, ' ').trim().slice(0, 300) || null;
    // Dishes ordered ahead (restaurants): only this restaurant's active menu.
    const preOrder = dto.preOrder?.length
      ? buildPreOrder(dto.preOrder, await this.prisma.menuItem.findMany({
          where: { tenantId, isActive: true, id: { in: dto.preOrder.map((l) => l.menuItemId).slice(0, 80) } },
          select: { id: true, name: true, priceCents: true },
        }))
      : [];

    // Validate + load selected add-ons: this salon's, and offered on a service
    // of THIS booking — the headline one or any extra — its own, its
    // category's shared ones, or the whole menu's. Each is stored with
    // `kind: 'addon'` and the service it was taken for, so every screen after
    // this (desk, till, calendar, receipt) tells an add-on from a service.
    const addonIds = [...new Set(dto.addonIds ?? [])];
    const pickedIds = [...new Set([service.id, ...(dto.serviceIds ?? [])])].filter(Boolean);
    const pickedCats = addonIds.length
      ? await this.prisma.service.findMany({ where: { tenantId, id: { in: pickedIds } }, select: { id: true, categoryId: true } })
      : [];
    const catIds = [...new Set(pickedCats.map((c) => c.categoryId).filter((c): c is string => !!c))];
    const addonRows = addonIds.length
      ? await this.prisma.serviceAddon.findMany({
          where: {
            id: { in: addonIds }, tenantId, isActive: true,
            OR: [
              { serviceId: { in: pickedIds } },
              { serviceId: null, categoryId: null },
              ...(catIds.length ? [{ serviceId: null, categoryId: { in: catIds } }] : []),
            ],
          } as never,
          select: { id: true, name: true, priceCents: true, durationMinutes: true, serviceId: true, categoryId: true } as never,
        }) as unknown as { id: string; name: string; priceCents: number; durationMinutes: number; serviceId: string | null; categoryId: string | null }[]
      : [];
    if (addonRows.length !== addonIds.length) {
      throw new BadRequestException('One or more add-ons are invalid for this service');
    }
    const addons = addonRows.map((a) => ({
      id: a.id, name: a.name, priceCents: a.priceCents, durationMinutes: a.durationMinutes, kind: 'addon' as const,
      forServiceId: a.serviceId ?? (a.categoryId ? pickedCats.find((c) => c.categoryId === a.categoryId)?.id ?? service.id : service.id),
    }));

    const start = parseStartTime(dto.startTime);
    // Staff at the desk may record a customer already in the chair (up to 12 h
    // back); online / chat / hotline bookings must start in the future.
    const pastProblem = pastStartProblem(start, Date.now(), !isPublicBooking);
    if (pastProblem) throw new BadRequestException(pastProblem);

    // ---- Pricing ----
    const addonPrice = addons.reduce((s, a) => s + a.priceCents, 0);
    const addonDuration = addons.reduce((s, a) => s + a.durationMinutes, 0);

    // Program promos that don't depend on the category (first visit / group).
    // Policy: ONE best promo % per line — never stacked on top of weekday/date.
    // The customer booking herself is "online"; a booking the desk takes for a
    // caller gets only the promotions the salon runs everywhere.
    const saleWhere: SaleChannel = isPublicBooking ? 'online' : 'desk';
    const programPct = await this.programDiscountPercent(tenantId, dto, start, saleWhere);

    // Primary service: its own discount, then the best promo for its category.
    const primaryDisc = Math.min(90, Math.max(0, service.discountPercent ?? 0));
    const primaryNet = Math.round((service.priceCents * (100 - primaryDisc)) / 100);
    const primaryWd = Math.max(await this.promoDiscountPercent(tenantId, start, service.categoryId, saleWhere), programPct);
    const primaryFinal = Math.round((primaryNet * (100 - primaryWd)) / 100);

    // Extra services in the SAME visit (multi-service). The first service stays
    // the primary (in serviceId); the rest become priced line items. Each gets
    // its own service discount + the weekday promo for its own category.
    const extraIds = [...new Set(dto.serviceIds ?? [])].filter((id) => id && id !== service.id);
    const extraServices = extraIds.length
      ? await this.prisma.service.findMany({ where: { id: { in: extraIds }, tenantId, isActive: true } })
      : [];
    // Fail loudly. Silently dropping an inactive/foreign id used to produce a
    // booking with fewer services (and a lower price) than the staff picked.
    if (extraServices.length !== extraIds.length) {
      throw new BadRequestException('One or more selected services are unavailable.');
    }
    const walkInExtra = extraServices.find((x) => (x as { walkInOnly?: boolean }).walkInOnly);
    if (walkInExtra) throw new BadRequestException(walkInOnlyMessage(walkInExtra.name));
    const extraItems: { id: string; name: string; priceCents: number; durationMinutes: number; kind: 'service' }[] = [];
    for (const s of extraServices) {
      const disc = Math.min(90, Math.max(0, s.discountPercent ?? 0));
      const net = Math.round((s.priceCents * (100 - disc)) / 100);
      const wd = Math.max(await this.promoDiscountPercent(tenantId, start, s.categoryId, saleWhere), programPct);
      extraItems.push({ id: s.id, name: s.name, priceCents: Math.round((net * (100 - wd)) / 100), durationMinutes: s.durationMinutes, kind: 'service' });
    }
    const extraPrice = extraItems.reduce((sum, x) => sum + x.priceCents, 0);
    const extraDuration = extraItems.reduce((sum, x) => sum + x.durationMinutes, 0);

    // A service with no length set — the field has no database default, and a
    // blank box in the services form saves 0 — produced an appointment that
    // started and ended at the same minute: "0 min" on the calendar, no block
    // of time, nothing for the next booking to collide with. A booking always
    // occupies time, so an unset length reads as the house default rather
    // than as zero. Setting the real length on the service fixes it properly.
    const primaryMinutes = service.durationMinutes > 0 ? service.durationMinutes : DEFAULT_SERVICE_MINUTES;
    const totalDuration = primaryMinutes + extraDuration + addonDuration;
    const totalPrice = primaryFinal + extraPrice + addonPrice;
    // Snapshot stored on the appointment: extra services first, then add-ons.
    const lineItems = [...extraItems, ...addons];
    const end = addMinutes(start, totalDuration);

    // The salon must actually be open — checked HERE, on the server.
    //
    // The slot grid the customer picks from is generated in the browser. That is
    // fine for building a screen and useless as a rule: this endpoint had no
    // hours check at all, so a request posted directly — a script, a bot, a tab
    // left open past a settings change — was accepted for 3am on a day the shop
    // is shut, and the salon found out when someone turned up.
    //
    // PUBLIC bookings only. `isPublicBooking` is the same gate the phone-number
    // rule above uses: staff at the desk must still be able to write down a
    // walk-in at 8pm or a favour for a regular. This protects the salon from the
    // outside; it does not tell the owner what to do inside their own shop.
    // The DESK may book before opening or after closing on an open day (an
    // early regular, a late favour) — the form shows a reminder, not a wall.
    // A CLOSED day or a day off still needs the owner, on purpose
    // (dto.outsideHours, owner-only — see create()).
    const deskHours = !isPublicBooking && dto.outsideHours !== true;
    const readHours = async () => {
      const [hoursTenant, hoursRules] = await Promise.all([
        this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }),
        this.settings.getBookingRules(tenantId),
      ]);
      return { hoursTenant, hoursRules };
    };
    // Public: no hours, no booking. Desk: a typo guard — if the hours cannot be
    // read, the receptionist's booking still goes through.
    const hoursRead = isPublicBooking ? await readHours() : deskHours ? await readHours().catch(() => null) : null;
    if (hoursRead) {
      const { hoursTenant, hoursRules } = hoursRead;
      const tz = hoursTenant?.timezone || 'UTC';
      // Weekday and clock time AS THE SALON SEES THEM. Comparing a UTC instant
      // against opening hours is how a 9am booking becomes 2am somewhere else.
      const parts = new Intl.DateTimeFormat('en-US', {
        timeZone: tz, weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false,
        year: 'numeric', month: '2-digit', day: '2-digit',
      }).formatToParts(start);
      const wd = parts.find((x) => x.type === 'weekday')?.value ?? '';
      const hh = Number(parts.find((x) => x.type === 'hour')?.value ?? NaN);
      const mm = Number(parts.find((x) => x.type === 'minute')?.value ?? NaN);
      const dayIndex = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(wd);
      const day = dayIndex >= 0 ? (hoursRules.businessHours ?? [])[dayIndex] : undefined;

      // The holiday list. The voice bot and the review gate both honour
      // daysOff; the public booking form was the one door left unlocked — a
      // customer could book Thanksgiving and nobody would know until they
      // knocked on a dark shop.
      const dateStr = `${parts.find((x) => x.type === 'year')?.value}-${parts.find((x) => x.type === 'month')?.value}-${parts.find((x) => x.type === 'day')?.value}`;
      if ((hoursRules.daysOff ?? []).includes(dateStr)) {
        throw new BadRequestException(isPublicBooking
          ? 'The salon is closed that day. Please pick another date.'
          : `OUTSIDE_HOURS: ${dateStr} is marked as a day off. Pick another date (the owner can still book it on purpose).`);
      }

      if (dayIndex >= 0 && Number.isFinite(hh) && Number.isFinite(mm)) {
        // hour12:false reports midnight as 24 in some environments.
        const startMinutes = (hh % 24) * 60 + mm;
        if (!isPublicBooking) {
          if (!windowsForDay(day).length) {
            throw new BadRequestException(`OUTSIDE_HOURS: the salon is closed on ${wd}. Pick another day (the owner can still book it on purpose).`);
          }
        } else if (!fitsBusinessHours({ day, startMinutes, durationMin: totalDuration })) {
          const open = describeWindows(day);
          throw new BadRequestException(
            open === 'closed'
              ? 'The salon is closed that day. Please pick another date.'
              : `That time is outside opening hours (${open}). Please pick another time.`,
          );
        }
      }
    }

    if (dto.staffId) {
      await this.assertStaffActive(tenantId, dto.staffId);
    } else {
      // No technician yet: a whole-salon block still closes the time.
      await this.assertNotOff(this.prisma, tenantId, null, start, end);
    }

    // Two fields only the till may use. A public request carrying them is
    // treated as if it never did: an end customer cannot book onto someone
    // else's record, nor skip the technician's acceptance.
    const onFile = actorUserId && dto.customerId ? dto.customerId : null;
    const confirmNow = Boolean(actorUserId && dto.confirmNow && dto.staffId);

    const appointment = await this.prisma.$transaction(async (tx) => {
      const customer = (onFile && (await tx.customer.findFirst({ where: { id: onFile, tenantId } })))
        || (await this.upsertCustomer(tx, tenantId, dto, !!actorUserId, !actorUserId && !opts?.groupGuest && (source === 'hosted' || source === 'plugin')));

      if (dto.staffId) {
        await this.lockStaffSlot(tx, tenantId, dto.staffId);
        // The salon's rest gap binds what customers and bots book; the desk may squeeze.
        await this.assertNoOverlap(tx, tenantId, dto.staffId, start, end, undefined, actorUserId ? 0 : await this.bufferMinutes(tenantId));
      }

      // Restaurant tenants: auto-assign the smallest free table that fits the party.
      let tableId: string | null = null;
      const tenantRow = await tx.tenant.findUnique({ where: { id: tenantId }, select: { businessType: true } });
      if (tenantRow?.businessType === 'RESTAURANT') {
        tableId = await this.findFreeTable(tx, tenantId, start, end, dto.partySize ?? 1, dto.area);
      }

      return tx.appointment.create({
        data: {
          tenantId,
          tableId,
          customerId: customer.id,
          serviceId: service.id,
          assignedStaffId: dto.staffId ?? null,
          preferredStaffId: dto.preferredStaffId ?? dto.staffId ?? null,
          // Booked at the counter with the tech standing there: confirmed on
          // the spot, no accept round-trip and no 30-minute deadline.
          status: confirmNow ? AppointmentStatus.CONFIRMED : dto.staffId ? AppointmentStatus.ASSIGNED : AppointmentStatus.PENDING,
          ...(confirmNow ? { confirmedAt: new Date(), customerConfirmedAt: new Date() } : {}),
          startTime: start,
          endTime: end,
          priceCents: totalPrice,
          currency: service.currency,
          addons: lineItems as unknown as Prisma.InputJsonValue,
          // Dishes ordered ahead and the address are also written into the notes, which every screen already shows.
          notes: ([dto.notes, location ? `Address: ${location}` : null, preOrder.length ? `Pre-order: ${preOrderText(preOrder)}` : null].filter(Boolean).join(' · ').slice(0, 2000)) || null,
          source: source ?? (actorUserId ? 'admin' : 'online'),
          device: device ?? null,
          utmSource: dto.utmSource?.slice(0, 120) || null,
          offerCode: dto.offerCode?.trim().toUpperCase().slice(0, 16) || null,
          utmMedium: dto.utmMedium?.slice(0, 120) || null,
          utmCampaign: dto.utmCampaign?.slice(0, 120) || null,
          utmContent: dto.utmContent?.slice(0, 120) || null,
          utmTerm: dto.utmTerm?.slice(0, 120) || null,
          gclid: dto.gclid?.slice(0, 300) || null,
          gbraid: dto.gbraid?.slice(0, 300) || null,
          wbraid: dto.wbraid?.slice(0, 300) || null,
          attrLandingUrl: dto.attrLandingUrl?.slice(0, 900) || null,
          attrReferrer: dto.attrReferrer?.slice(0, 900) || null,
          attrCapturedAt: (() => { const d = dto.attrCapturedAt ? new Date(dto.attrCapturedAt) : null; return d && !isNaN(d.getTime()) ? d : null; })(),
          partySize: dto.partySize ?? 1,
          groupId: dto.groupId?.trim() || null,
          assignedAt: dto.staffId ? new Date() : null,
          responseDeadline: dto.staffId && !confirmNow ? addMinutes(new Date(), 30) : null,
        },
        include: BOOKING_INCLUDE,
      });
    });

    if (preOrder.length || location) {
      // Its own write, typed loosely: the columns are newer than some generated clients.
      await this.prisma.appointment.updateMany({ where: { id: appointment.id, tenantId }, data: { ...(preOrder.length ? { preOrder } : {}), ...(location ? { location } : {}) } as never });
    }

    await this.audit.log({
      tenantId,
      userId: actorUserId,
      action: 'booking.created',
      resourceType: 'appointment',
      resourceId: appointment.id,
      metadata: {
        serviceId: service.id,
        startTime: start.toISOString(),
        staffId: dto.staffId,
        source: source ?? (actorUserId ? 'admin' : 'public'),
        device: device ?? null,
      },
    });

    // Assign the technician BEFORE anyone is told about the booking.
    //
    // The confirmation can only name a technician if one is known while it is
    // being written. Callers that ask for auto-assignment (the hosted booking
    // page, the chat bot) used to run the engine after this method returned —
    // milliseconds after the mail had already been queued — which is the whole
    // reason the customer's email read "Technician: To be assigned" on a salon
    // whose engine had in fact picked someone.
    //
    // Best-effort: a booking that cannot be staffed is still a booking, and the
    // confirmation still goes out (naming no one, which is then the truth).
    const hadStaffAtCreate = Boolean(appointment.assignedStaffId);
    let finished: typeof appointment = appointment;
    if (opts?.autoAssign && !hadStaffAtCreate) {
      try {
        const rules = await this.settings.getBookingRules(tenantId);
        if (rules.assignmentMode === 'auto') {
          const res = await this.autoAssignForTenant(tenantId, appointment.id);
          const assigned = res?.booking as typeof appointment | null | undefined;
          if (assigned) finished = assigned;
        }
      } catch {
        // engine unavailable / nobody eligible — keep the unassigned booking
      }
    }

    // The customer chose a technician: that technician also does the visit's
    // other services (one person, one chair — see planLineTechnician). Done
    // here, before the confirmation is written, so the mail names one
    // technician for the whole visit instead of leaving the extra lines
    // unowned for a later "auto assign" press to spread across the team.
    if (hadStaffAtCreate && lineItems.some((l) => (l as { kind?: string }).kind === 'service')) {
      try {
        const rules = await this.settings.getBookingRules(tenantId);
        await this.assignExtraServiceLines(tenantId, appointment.id, { fillGaps: rules.assignmentMode === 'auto' });
        const refreshed = await this.prisma.appointment.findFirst({ where: { id: appointment.id, tenantId }, include: BOOKING_INCLUDE });
        if (refreshed) finished = refreshed as typeof appointment;
      } catch { /* the booking stands; the lines can be assigned by hand */ }
    }

    if (opts?.deskConfirm && actorUserId) {
      try {
        const confirmed = await this.confirmDeskBooking(tenantId, finished as { id: string; status: AppointmentStatus; assignedStaffId: string | null });
        if (confirmed) finished = confirmed as typeof appointment;
      } catch (e) {
        // The booking stands either way; the desk can still confirm by hand.
        this.logger.warn(`desk booking ${appointment.id} not auto-confirmed: ${e instanceof Error ? e.message : String(e)}`);
      }
    } else if (isPublicBooking) {
      // A customer booked (page, plugin, chat, AI line): confirmed on the spot
      // unless the salon turned "Tự động xác nhận" off (BookingRules.autoConfirm).
      // Before the confirmation is written, so what she is sent and what the
      // calendar says agree. A deposit still being paid does not hold this
      // back: an unpaid hold cancels a CONFIRMED booking too (deposit-hold.ts).
      try {
        const confirmed = await this.confirmDeskBooking(tenantId, finished as { id: string; status: AppointmentStatus; assignedStaffId: string | null }, { customer: true });
        if (confirmed) {
          finished = confirmed as typeof appointment;
          await this.audit.log({ tenantId, userId: null, action: 'booking.auto_confirmed', resourceType: 'appointment', resourceId: appointment.id, metadata: { source: source ?? 'online' } });
        }
      } catch (e) {
        // The booking stands; it waits in "Cần xác nhận" for the desk instead.
        this.logger.warn(`booking ${appointment.id} not auto-confirmed: ${e instanceof Error ? e.message : String(e)}`);
      }
    }

    // Fire-and-forget confirmation; never block/fail the booking on it.
    // A member of a party does not speak for itself: the party is told once,
    // when it has stopped growing (group-notice.ts) — not five emails and five
    // texts for "me and four friends".
    const partyId = (finished as { groupId?: string | null }).groupId ?? null;
    if (!opts?.quiet) {
      if (partyId) this.queueGroupConfirmation(tenantId, partyId);
      else this.sendBookingConfirmation(tenantId, finished).catch(() => undefined);
    }
    // If a technician was assigned at creation, email them too. An auto-assign
    // above already sent that mail from autoAssignForTenant, so this only
    // covers the front-desk case — otherwise the tech gets it twice.
    if (hadStaffAtCreate) {
      this.sendStaffAssignmentEmail(tenantId, appointment.id).catch(() => undefined);
    }

    return finished;
  }

  /**
   * The customer's next appointments, found by their phone number.
   *
   * Phone, not name: two people called Anna is normal in a book of two hundred,
   * and showing one customer another customer's appointment is the worst thing
   * this feature could do. The number is matched in both its normalised and its
   * raw form, because rows written before normalisation still hold the text the
   * customer typed.
   */
  async upcomingForPhone(tenantId: string, rawPhone: string, limit = 5) {
    const phone = (await this.normalizedPhone(tenantId, rawPhone)) ?? '';
    const raw = String(rawPhone ?? '').trim();
    if (!phone && !raw) return [];
    const or: Prisma.CustomerWhereInput[] = [];
    if (phone) or.push({ phone });
    if (raw && raw !== phone) or.push({ phone: raw });
    const customers = await this.prisma.customer.findMany({
      where: { tenantId, OR: or }, select: { id: true }, take: 5,
    });
    if (!customers.length) return [];
    return this.prisma.appointment.findMany({
      where: {
        tenantId,
        customerId: { in: customers.map((c) => c.id) },
        startTime: { gte: new Date() },
        status: { in: BookingsService.ACTIONABLE },
      },
      select: {
        id: true, startTime: true, endTime: true, status: true,
        service: { select: { name: true } },
        assignedStaff: { select: { firstName: true } },
      },
      orderBy: { startTime: 'asc' },
      take: limit,
    });
  }

  /**
   * A customer moves their own appointment, from Messenger or the AI hotline.
   *
   * SEPARATE FROM reschedule() ON PURPOSE
   *
   * `reschedule()` is the staff action: someone at the desk who can see the
   * whole day, who is allowed to overrule the rules, and who is accountable for
   * it. This one is executed by a language model on behalf of a member of the
   * public, so every guard the desk provides by being a person has to be
   * written down: the caller must prove which appointment is theirs, the timing
   * policy applies, opening hours apply, and the technician must actually be
   * free.
   *
   * The verdict comes from self-reschedule.ts, which knows nothing about
   * Prisma, so the same rule serves both bots and can be tested without a
   * database. What is left here is everything that needs the database.
   */
  /**
   * A caller (hotline / chat bot) asks for a particular technician on a
   * booking they already have. Before, the bot had no way to do it and told
   * the customer "a staff member will call you back to add Alex" — and the
   * customer had to call again and insist. Same checks as the desk's assign:
   * this salon only, a live booking, an active bookable technician who does
   * the service, free then (bookings, time off and blocks — assertNoOverlap).
   * The caller's right to this booking is checked by the caller of this
   * method (the hotline: the booking is on a number confirmed on this line).
   */
  async selfChangeTech(input: { tenantId: string; appointmentId: string; staffId: string; by: 'messenger' | 'hotline' }): Promise<{ ok: boolean; code: string; say: string; staffName?: string }> {
    const { tenantId, appointmentId, staffId, by } = input;
    const appt = await this.prisma.appointment.findFirst({
      where: { id: appointmentId, tenantId },
      select: { id: true, startTime: true, endTime: true, status: true, assignedStaffId: true, serviceId: true },
    }).catch(() => null);
    if (!appt) return { ok: false, code: 'not-found', say: 'That booking was not found.' };
    if (!BookingsService.ACTIONABLE.includes(appt.status)) return { ok: false, code: 'not-live', say: 'That booking is no longer active, so its technician cannot be changed.' };
    const st = await this.prisma.staffMember.findFirst({
      where: { id: staffId, tenantId, isActive: true },
      select: { id: true, firstName: true, takesAppointments: true, staffServices: { select: { serviceId: true } } } as never,
    }).catch(() => null) as unknown as { id: string; firstName: string; takesAppointments?: boolean; staffServices?: { serviceId: string }[] } | null;
    if (!st || st.takesAppointments === false) return { ok: false, code: 'no-tech', say: 'That technician is not taking appointments.' };
    const skills = st.staffServices ?? [];
    if (skills.length && appt.serviceId && !skills.some((x) => x.serviceId === appt.serviceId)) {
      return { ok: false, code: 'not-skilled', say: `${st.firstName} does not do this service.` };
    }
    if (appt.assignedStaffId === st.id) return { ok: true, code: 'same', say: `${st.firstName} is already on this booking.`, staffName: st.firstName };
    try {
      await this.prisma.$transaction(async (tx) => {
        await this.lockStaffSlot(tx, tenantId, st.id);
        await this.assertNoOverlap(tx, tenantId, st.id, appt.startTime, appt.endTime, appt.id);
        const keepStatus = appt.status === AppointmentStatus.CONFIRMED || appt.status === AppointmentStatus.ARRIVED;
        await tx.appointment.updateMany({
          where: { id: appt.id, tenantId },
          data: {
            assignedStaffId: st.id, preferredStaffId: st.id, assignedAt: new Date(), rejectedAt: null,
            ...(keepStatus ? {} : { status: AppointmentStatus.ASSIGNED, responseDeadline: addMinutes(new Date(), 30) }),
          } as never,
        });
      });
    } catch (e) {
      const msg = String((e as Error).message || e);
      const say = /TIME_OFF|BLOCKED/.test(msg) ? `${st.firstName} is off at that time.` : /already booked/i.test(msg) ? `${st.firstName} already has a booking at that time.` : 'That change could not be made.';
      return { ok: false, code: 'busy', say };
    }
    await this.audit.log({ tenantId, userId: null as never, action: 'booking.tech_changed_by_customer', resourceType: 'appointment', resourceId: appt.id, metadata: { staffId: st.id, from: appt.assignedStaffId, by } });
    await this.followOnFloor(tenantId, appt.id, appt.assignedStaffId, st.id).catch(() => undefined);
    this.sendStaffAssignmentEmail(tenantId, appt.id).catch(() => undefined);
    return { ok: true, code: 'changed', say: `${st.firstName} is now on this booking.`, staffName: st.firstName };
  }

  /**
   * "Arms and legs instead of legs only" — a client changes WHAT is done at a
   * booking she already has, from the hotline. Same day, same time, same
   * technician; the new list is priced and timed like the desk's edit
   * (editLines), and a longer visit that would run into the technician's next
   * booking is refused, naming it. The caller's right to this booking is
   * checked by the caller of this method.
   */
  async selfChangeServices(input: { tenantId: string; appointmentId: string; serviceIds: string[]; by: 'messenger' | 'hotline' }): Promise<{ ok: boolean; code: string; say: string; services: string[]; endsAt?: string }> {
    const { tenantId, appointmentId, by } = input;
    const ids = [...new Set((input.serviceIds ?? []).filter(Boolean))];
    if (!ids.length) return { ok: false, code: 'empty', say: 'No service was given.', services: [] };
    const b = await this.prisma.appointment.findFirst({ where: { id: appointmentId, tenantId }, select: { id: true, status: true, serviceId: true, startTime: true, addons: true } }).catch(() => null);
    if (!b) return { ok: false, code: 'not-found', say: 'That booking was not found.', services: [] };
    if (!BookingsService.ACTIONABLE.includes(b.status)) return { ok: false, code: 'not-live', say: 'That booking is no longer active.', services: [] };
    if (b.startTime.getTime() <= Date.now()) return { ok: false, code: 'started', say: 'That visit has already started — the front desk changes it in the salon.', services: [] };
    const found = await this.prisma.service.findMany({ where: { tenantId, id: { in: ids }, isActive: true }, select: { id: true } });
    if (found.length !== ids.length) return { ok: false, code: 'unknown-service', say: 'One of those services is not on the menu.', services: [] };
    type Line = { id?: string; kind?: string };
    const lines: Line[] = Array.isArray(b.addons) ? (b.addons as unknown as Line[]) : [];
    const [main, ...rest] = ids;
    // Service lines not in the new list go; extras (add-ons) stay with the visit.
    const removeIndexes = lines.map((l, i) => ((l.kind ?? 'service') === 'service' && !(l.id && rest.includes(l.id)) ? i : -1)).filter((i) => i >= 0);
    const keptIds = new Set(lines.filter((l, i) => !removeIndexes.includes(i) && l.id).map((l) => l.id as string));
    const addServiceIds = rest.filter((x) => !keptIds.has(x) && x !== main);
    const actor = { userId: null, role: UserRole.SALON_ADMIN, tenantId } as unknown as AuthenticatedUser;
    try {
      await this.editLines(actor, appointmentId, { replaceMainServiceId: main !== b.serviceId ? main : undefined, removeIndexes, addServiceIds, lang: 'en' });
    } catch (e) {
      const msg = String((e as Error).message || e);
      return { ok: false, code: /already|overlap|booked|next/i.test(msg) ? 'busy' : 'refused', say: msg.slice(0, 200), services: [] };
    }
    const after = await this.prisma.appointment.findFirst({ where: { id: appointmentId, tenantId }, select: { endTime: true, addons: true, service: { select: { name: true } }, tenant: { select: { timezone: true } } } as never }).catch(() => null) as unknown as { endTime: Date; addons: unknown; service: { name: string } | null; tenant: { timezone: string } | null } | null;
    const names = [after?.service?.name, ...(Array.isArray(after?.addons) ? (after!.addons as { name?: string; kind?: string }[]).filter((l) => (l.kind ?? 'service') === 'service').map((l) => l.name) : [])].filter((x): x is string => !!x);
    const endsAt = after?.endTime ? new Intl.DateTimeFormat('en-US', { timeZone: after.tenant?.timezone || 'UTC', hour: 'numeric', minute: '2-digit' }).format(after.endTime) : undefined;
    await this.audit.log({ tenantId, userId: null as never, action: 'booking.services_changed_by_customer', resourceType: 'appointment', resourceId: appointmentId, metadata: { by, services: names } });
    return { ok: true, code: 'changed', say: 'Changed.', services: names, endsAt };
  }

  async selfReschedule(input: {
    tenantId: string;
    appointmentId: string;
    /** Proof of ownership. Must match the appointment's customer. */
    phone: string;
    newStartIso: string;
    by: 'messenger' | 'hotline';
  }): Promise<{ ok: boolean; code: string; say: string; appointment?: unknown; startTime?: Date }> {
    const { tenantId, appointmentId, by } = input;
    const rules = await this.settings.getBookingRules(tenantId);
    const appt = await this.prisma.appointment.findFirst({
      where: { id: appointmentId, tenantId },
      select: {
        id: true, startTime: true, endTime: true, status: true, assignedStaffId: true,
        customer: { select: { phone: true } },
      } as never,
    }).catch(() => null) as unknown as {
      id: string; startTime: Date; endTime: Date; status: AppointmentStatus;
      assignedStaffId: string | null; customer: { phone: string | null } | null;
      selfRescheduleCount?: number;
    } | null;

    if (!appt) {
      return { ok: false, code: 'not-found', say: 'Em không tìm thấy lịch hẹn đó ạ. Anh/chị cho em xin lại số điện thoại đã dùng để đặt nhé.' };
    }

    // Ownership, checked against the phone rather than trusted from the model.
    // Without this, a caller who guessed an id could move a stranger's booking.
    const given = (await this.normalizedPhone(tenantId, input.phone)) ?? String(input.phone ?? '').trim();
    const owner = (await this.normalizedPhone(tenantId, appt.customer?.phone ?? '')) ?? (appt.customer?.phone ?? '');
    const digits = (s: string) => s.replace(/\D/g, '');
    const sameOwner = Boolean(given && owner)
      && (given === owner || (digits(given).length >= 7 && digits(given).slice(-9) === digits(owner).slice(-9)));
    if (!sameOwner) {
      this.logger.warn(`self-reschedule refused (${by}): phone does not match appointment ${appointmentId}`);
      return { ok: false, code: 'not-owner', say: 'Số điện thoại này không khớp với lịch hẹn đó ạ. Anh/chị kiểm tra giúp em số đã dùng khi đặt nhé.' };
    }

    const moves = Number((appt as { selfRescheduleCount?: number }).selfRescheduleCount ?? 0);
    const newStart = new Date(input.newStartIso);
    const verdict = canSelfReschedule(
      {
        enabled: rules.selfRescheduleEnabled !== false,
        noticeHours: rules.selfRescheduleNoticeHours ?? 24,
        minLeadHours: rules.minLeadHours ?? 1,
        maxMoves: rules.selfRescheduleMaxMoves ?? 2,
      },
      {
        now: Date.now(),
        currentStartMs: appt.startTime.getTime(),
        newStartMs: newStart.getTime(),
        maxAdvanceDays: rules.maxAdvanceDays ?? 60,
        movesSoFar: moves,
        live: BookingsService.ACTIONABLE.includes(appt.status),
      },
    );
    if (!verdict.allowed) {
      this.logger.log(`self-reschedule refused (${by}) ${appointmentId}: ${verdict.detail}`);
      return { ok: false, code: verdict.code, say: verdict.say };
    }

    const durationMs = appt.endTime.getTime() - appt.startTime.getTime();
    const newEnd = new Date(newStart.getTime() + durationMs);

    // Opening hours, on the server, for the same reason the public booking path
    // checks them: the model is choosing a time from a conversation, not from a
    // slot grid, and nothing else stops it picking 3am on a Sunday.
    const tenant = await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } });
    const tz = tenant?.timezone || 'UTC';
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: tz, weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false,
    }).formatToParts(newStart);
    const wd = parts.find((x) => x.type === 'weekday')?.value ?? '';
    const hh = Number(parts.find((x) => x.type === 'hour')?.value ?? NaN);
    const mm = Number(parts.find((x) => x.type === 'minute')?.value ?? NaN);
    const dayIndex = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(wd);
    const day = dayIndex >= 0 ? (rules.businessHours ?? [])[dayIndex] : undefined;
    if (dayIndex >= 0 && Number.isFinite(hh) && Number.isFinite(mm)) {
      const startMinutes = (hh % 24) * 60 + mm;
      if (!fitsBusinessHours({ day, startMinutes, durationMin: Math.round(durationMs / 60_000) })) {
        const open = describeWindows(day);
        return {
          ok: false, code: 'closed',
          say: open === 'closed'
            ? 'Hôm đó tiệm nghỉ ạ. Anh/chị chọn giúp em một ngày khác nhé?'
            : `Giờ đó ngoài giờ mở cửa của tiệm (${open}). Anh/chị chọn giúp em một khung trong giờ nhé?`,
        };
      }
    }

    try {
      const updated = await this.prisma.$transaction(async (tx) => {
        if (appt.assignedStaffId) {
          await this.lockStaffSlot(tx, tenantId, appt.assignedStaffId);
          await this.assertNoOverlap(tx, tenantId, appt.assignedStaffId, newStart, newEnd, appt.id);
        }
        await tx.appointment.updateMany({
          where: { id: appt.id, tenantId },
          data: {
            startTime: newStart,
            endTime: newEnd,
            // The reminders already sent describe the OLD time. Clearing them
            // lets the reminder job send fresh ones for the new time; leaving
            // them would mean the customer's only reminder was for a slot they
            // no longer hold.
            remind1SentAt: null,
            remind2SentAt: null,
            customerConfirmedAt: null,
            selfRescheduleCount: moves + 1,
          } as never,
        });
        return tx.appointment.findFirst({ where: { id: appt.id, tenantId }, include: BOOKING_INCLUDE });
      });

      await this.audit.log({
        tenantId, userId: null,
        action: 'booking.self_rescheduled',
        resourceType: 'appointment',
        resourceId: appt.id,
        metadata: { by, from: appt.startTime.toISOString(), to: newStart.toISOString(), move: moves + 1 },
      });
      this.logger.log(`self-reschedule OK (${by}) ${appt.id}: ${appt.startTime.toISOString()} -> ${newStart.toISOString()}`);

      // The customer's written record must match the calendar, and the
      // technician's day just changed — the "rescheduled" template says so;
      // a second "confirmed" read as a second booking.
      if (updated) this.sendChangeNotice(tenantId, appt.id, 'rescheduled', { by: 'customer', from: appt.startTime }).catch(() => undefined);

      return { ok: true, code: 'ok', say: '', appointment: updated, startTime: newStart };
    } catch (e) {
      const msg = String((e as Error).message || e);
      if (/already booked/i.test(msg)) {
        return { ok: false, code: 'taken', say: 'Khung giờ đó thợ đã có khách rồi ạ. Anh/chị chọn giúp em một giờ khác nhé?' };
      }
      this.logger.warn(`self-reschedule failed (${by}) ${appointmentId}: ${msg.slice(0, 160)}`);
      return { ok: false, code: 'error', say: 'Em chưa đổi được lịch lúc này. Em nhờ nhân viên gọi lại cho anh/chị ngay nhé.' };
    }
  }

  /**
   * Cancel an appointment for the customer who booked it, from Messenger or
   * the AI hotline. Same shape and same guarantees as selfReschedule: the
   * phone proves ownership, the policy decides, and the sentence the customer
   * hears comes back with the verdict so the two bots cannot drift apart.
   *
   * WHAT THIS DOES NOT DO: decide about money. An appointment with a paid
   * payment is refused here (code `deposit`) and goes to a person, because
   * cancelling settles payments and a deposit exists to make a late
   * cancellation cost something.
   */
  async selfCancel(input: {
    tenantId: string;
    appointmentId: string;
    /** Proof of ownership. Must match the appointment's customer. */
    phone: string;
    by: 'messenger' | 'hotline';
  }): Promise<{ ok: boolean; code: string; say: string; startTime?: Date }> {
    const { tenantId, appointmentId, by } = input;
    const rules = await this.settings.getBookingRules(tenantId);
    const appt = await this.prisma.appointment.findFirst({
      where: { id: appointmentId, tenantId },
      select: { id: true, startTime: true, status: true, customer: { select: { phone: true } } } as never,
    }).catch(() => null) as unknown as {
      id: string; startTime: Date; status: AppointmentStatus; customer: { phone: string | null } | null;
    } | null;

    if (!appt) {
      return { ok: false, code: 'not-found', say: 'Em không tìm thấy lịch hẹn đó ạ. Anh/chị cho em xin lại số điện thoại đã dùng để đặt nhé.' };
    }

    // Ownership, checked against the phone rather than trusted from the model.
    // Without this, a caller who guessed an id could cancel a stranger's visit —
    // and unlike a bad reschedule, nothing about it is visible until the
    // customer arrives to an appointment that is no longer there.
    const given = (await this.normalizedPhone(tenantId, input.phone)) ?? String(input.phone ?? '').trim();
    const owner = (await this.normalizedPhone(tenantId, appt.customer?.phone ?? '')) ?? (appt.customer?.phone ?? '');
    const digits = (v: string) => v.replace(/\D/g, '');
    const sameOwner = Boolean(given && owner)
      && (given === owner || (digits(given).length >= 7 && digits(given).slice(-9) === digits(owner).slice(-9)));
    if (!sameOwner) {
      this.logger.warn(`self-cancel refused (${by}): phone does not match appointment ${appointmentId}`);
      return { ok: false, code: 'not-owner', say: 'Số điện thoại này không khớp với lịch hẹn đó ạ. Anh/chị kiểm tra giúp em số đã dùng khi đặt nhé.' };
    }

    const paid = await this.prisma.payment.count({
      where: { tenantId, appointmentId: appt.id, status: PaymentStatus.PAID },
    }).catch(() => 0);

    const verdict = canSelfCancel(
      {
        enabled: rules.selfCancelEnabled !== false,
        noticeHours: rules.selfCancelNoticeHours ?? 24,
      },
      {
        now: Date.now(),
        startMs: appt.startTime.getTime(),
        live: BookingsService.ACTIONABLE.includes(appt.status),
        hasPaidDeposit: paid > 0,
      },
    );
    if (!verdict.allowed) {
      this.logger.log(`self-cancel refused (${by}) ${appointmentId}: ${verdict.detail}`);
      return { ok: false, code: verdict.code, say: verdict.say };
    }

    try {
      // `by: 'ai'` is not decoration — the calendar and the audit trail must say
      // a bot did this, so the salon can tell a customer-cancelled slot from one
      // its own front desk cleared.
      await this.cancelForTenant(tenantId, appt.id, null, 'ai', by === 'hotline' ? 'AI hotline' : 'AI Messenger');
      this.logger.log(`self-cancel OK (${by}) ${appt.id}: ${appt.startTime.toISOString()}`);
      return { ok: true, code: 'ok', say: '', startTime: appt.startTime };
    } catch (e) {
      const msg = String((e as Error).message || e);
      this.logger.warn(`self-cancel failed (${by}) ${appointmentId}: ${msg.slice(0, 160)}`);
      return { ok: false, code: 'error', say: 'Em chưa huỷ được lịch lúc này. Em nhờ nhân viên gọi lại cho anh/chị ngay nhé.' };
    }
  }

  /**
   * Add services to an appointment that already exists — one visit, one bill.
   *
   * WHY THIS EXISTS
   *
   * A customer who asks for eyebrow waxing AND an acrylic refill is describing
   * ONE visit. The Messenger bot could only create single-service bookings, so
   * it called create twice and the salon got two appointments fifteen minutes
   * apart, two rows on the calendar, and two separate bills for one person
   * sitting in one chair. The multi-service path has existed in
   * createForTenant since it was written; nothing could reach it after the
   * fact.
   *
   * Pricing runs through the SAME discount rules as a fresh booking — each
   * service keeps its own discount and its own category's weekday promo —
   * because a service added a minute later must not cost a different amount
   * from the same service added a minute earlier.
   *
   * The appointment grows at the end. That is the only direction it may grow:
   * moving the start would move an appointment the customer has already been
   * told about, and the overlap check below is what stops the longer block
   * running into whatever the technician has next.
   */
  async addServicesToAppointment(
    tenantId: string,
    appointmentId: string,
    serviceIds: string[],
  ): Promise<{ appointment: Awaited<ReturnType<typeof this.prisma.appointment.findFirst>>; added: string[] }> {
    const appt = await this.prisma.appointment.findFirst({
      where: { id: appointmentId, tenantId },
      include: { service: true, customer: { select: { phone: true, email: true } } },
    });
    if (!appt) throw new NotFoundException('Appointment not found');
    if (appt.status === AppointmentStatus.CANCELLED || appt.status === AppointmentStatus.COMPLETED) {
      throw new BadRequestException('That appointment is already closed.');
    }

    const existing = Array.isArray(appt.addons) ? (appt.addons as unknown as { id?: string }[]) : [];
    const already = new Set([appt.serviceId, ...existing.map((x) => String(x?.id ?? ''))]);
    const wanted = [...new Set(serviceIds)].filter((id) => id && !already.has(id));
    if (!wanted.length) {
      return { appointment: appt, added: [] };
    }

    const services = await this.prisma.service.findMany({
      where: { id: { in: wanted }, tenantId, isActive: true },
    });
    // Same rule as createForTenant: fail loudly. Silently dropping one id
    // produces a bill with fewer services than the customer asked for, which
    // nobody discovers until the till.
    if (services.length !== wanted.length) {
      throw new BadRequestException('One or more selected services are unavailable.');
    }

    // The real customer, so a first-visit or group tier lands on the added
    // service exactly as it landed on the primary one. Passing a blank
    // customer here would quietly price the second service higher than the
    // first, on the same bill, minutes apart.
    const programPct = await this.programDiscountPercent(tenantId, {
      serviceId: appt.serviceId,
      startTime: appt.startTime.toISOString(),
      customerFirstName: '',
      customerPhone: appt.customer?.phone ?? undefined,
      customerEmail: appt.customer?.email ?? undefined,
      // Read loosely: partySize is on the deployed schema but absent from the
      // Prisma client this was written against, and a field access that
      // compiles in exactly one of the two places is not worth a group tier.
      partySize: (appt as { partySize?: number }).partySize ?? 1,
    } as unknown as CreateBookingDto, appt.startTime, channelOfSource(appt.source));

    const items: { id: string; name: string; priceCents: number; durationMinutes: number; kind: 'service' }[] = [];
    for (const s of services) {
      const disc = Math.min(90, Math.max(0, s.discountPercent ?? 0));
      const net = Math.round((s.priceCents * (100 - disc)) / 100);
      const wd = Math.max(await this.promoDiscountPercent(tenantId, appt.startTime, s.categoryId, channelOfSource(appt.source)), programPct);
      items.push({
        id: s.id, name: s.name, kind: 'service',
        priceCents: Math.round((net * (100 - wd)) / 100),
        durationMinutes: s.durationMinutes,
      });
    }

    const addedMinutes = items.reduce((sum, x) => sum + x.durationMinutes, 0);
    const addedPrice = items.reduce((sum, x) => sum + x.priceCents, 0);
    const end = addMinutes(appt.endTime, addedMinutes);

    const updated = await this.prisma.$transaction(async (tx) => {
      if (appt.assignedStaffId) {
        await this.lockStaffSlot(tx, tenantId, appt.assignedStaffId);
        // Excluding this appointment from its own overlap check: it is the one
        // being extended, and comparing it against itself would always fail.
        await this.assertNoOverlap(tx, tenantId, appt.assignedStaffId, appt.startTime, end, appt.id);
      }
      return tx.appointment.update({
        where: { id: appt.id },
        data: {
          endTime: end,
          priceCents: appt.priceCents + addedPrice,
          addons: [...existing, ...items] as unknown as Prisma.InputJsonValue,
        },
        include: BOOKING_INCLUDE,
      });
    });

    await this.audit.log({
      tenantId, userId: null,
      action: 'booking.services_added',
      resourceType: 'appointment',
      resourceId: appt.id,
      metadata: { added: items.map((x) => x.name), addedPriceCents: addedPrice, addedMinutes },
    });

    // Send the confirmation again, now that it is true.
    //
    // The first one went out naming one service and one end time, and both have
    // just changed. A second message a minute later is mildly annoying; a
    // confirmation that understates what the customer is booked for — and what
    // they will be charged — is worse, and the technician needs to know the
    // block got longer. Fire-and-forget, exactly like the first: the services
    // are already added and a mail failure must not undo that.
    this.sendBookingConfirmation(tenantId, updated as never).catch(() => undefined);

    return { appointment: updated, added: items.map((x) => x.name) };
  }

  /**
   * Where the owner's booking emails go: the first real address among the
   * salon's own settings, then the salon owner's login email. Never a
   * no-reply address, never something that is not an email. Tenant-scoped.
   */
  private async ownerAlertEmail(tenantId: string, candidates: Array<string | null | undefined>): Promise<string> {
    const real = (v: unknown) => {
      const e = String(v ?? '').trim();
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) && !/^(no-?reply|do-?not-?reply)@/i.test(e) ? e : '';
    };
    for (const c of candidates) { const e = real(c); if (e) return e; }
    const owner = await this.prisma.user.findFirst({
      where: { tenantId, role: 'SALON_ADMIN' as never, isActive: true },
      orderBy: { createdAt: 'asc' },
      select: { email: true },
    }).catch(() => null);
    return real(owner?.email);
  }

  /** Per salon + party: the timer that sends the party's one confirmation. */
  private readonly groupNoticeTimers = new Map<string, ReturnType<typeof setTimeout>>();

  /**
   * (Re)arm the party's confirmation. Every member written restarts the wait,
   * so the message goes out once, after the last guest — whichever order the
   * caller writes them in (the booking page writes the booker first, the chat
   * and the AI line write her last, the desk posts one by one).
   */
  private queueGroupConfirmation(tenantId: string, groupId: string, delayMs = GROUP_NOTICE_DELAY_MS) {
    const key = `${tenantId}:${groupId}`;
    const prev = this.groupNoticeTimers.get(key);
    if (prev) clearTimeout(prev);
    const t = setTimeout(() => {
      this.groupNoticeTimers.delete(key);
      this.sendGroupConfirmation(tenantId, groupId).catch((e) => this.logger.warn(`group ${groupId} confirmation failed: ${e instanceof Error ? e.message : String(e)}`));
    }, delayMs);
    (t as { unref?: () => void }).unref?.();
    this.groupNoticeTimers.set(key, t);
  }

  /**
   * The party's ONE confirmation: to the person who booked (the member with a
   * phone or email) and ONE notice to the salon, both listing everybody. Read
   * fresh, fenced to this salon, cancelled members left out.
   */
  async sendGroupConfirmation(tenantId: string, groupId: string) {
    const rows = await this.prisma.appointment.findMany({
      where: { tenantId, groupId, status: { not: AppointmentStatus.CANCELLED } },
      include: BOOKING_INCLUDE,
      orderBy: { createdAt: 'asc' },
    });
    if (!rows.length) return;
    const lead = groupLead(rows as unknown as Array<GroupMember & (typeof rows)[number]>) as (typeof rows)[number] | null;
    if (!lead) return;
    await this.sendBookingConfirmation(tenantId, lead, rows.length > 1 ? { group: rows as unknown as GroupMember[] } : {});
  }

  /**
   * Notifies the customer and/or the salon admin about a new booking with a
   * polished, branded HTML email and/or SMS, using the salon's templates.
   */
  private async sendBookingConfirmation(
    tenantId: string,
    appointment: {
      id: string;
      startTime: Date;
      endTime: Date;
      priceCents: number;
      currency: string;
      addons?: unknown;
      notes?: string | null;
      source?: string | null;
      customer: { id?: string; firstName?: string; lastName?: string | null; email: string | null; phone: string | null } | null;
      service: { name: string } | null;
      assignedStaff?: { firstName: string; lastName: string | null } | null;
    },
    /** techUpdate: the booking just got its technician — tell the customer who (customer_staff_assigned), nobody else. */
    /** group: every member of the party (this appointment is its contact) — one message lists them all. */
    opts: { techUpdate?: boolean; group?: GroupMember[] } = {},
  ) {
    const n = await this.settings.getNotificationSettings(tenantId);
    const tenant = await this.prisma.tenant.findUnique({
      where: { id: tenantId },
      select: { name: true, contactEmail: true, contactPhone: true, branding: true, timezone: true },
    });

    const tz = tenant?.timezone || 'America/New_York';
    // The customer reads this, so it is written in the salon's language and
    // clock. A US salon is unchanged: en-US still prints 5:30 PM.
    const loc = await this.customerLocale(tenantId, tenant?.timezone);
    const fmtT = (dd: Date) => dd.toLocaleTimeString(loc, { hour: 'numeric', minute: '2-digit', timeZone: tz });
    const fmtD = (dd: Date) => dd.toLocaleDateString(loc, { weekday: 'short', month: 'long', day: 'numeric', year: 'numeric', timeZone: tz });
    const start = appointment.startTime;
    const end = appointment.endTime;
    const durationMin = Math.round((end.getTime() - start.getTime()) / 60_000);
    const lineItems: Array<Record<string, unknown>> = Array.isArray(appointment.addons)
      ? (appointment.addons as unknown as Array<Record<string, unknown>>).filter(Boolean)
      : [];
    // Unchanged on purpose: salon-authored templates render %add_ons% and have
    // always seen every extra line here. The split below is used by the
    // built-in email only, so nobody's own wording loses information.
    const addonNames = lineItems.map((a) => a.name).filter(Boolean).join(', ');
    // An extra SERVICE is not an add-on. Listing "Nail Design" under Add-ons
    // when it is a service the customer booked (and a second technician will
    // do) is how the confirmation ends up describing a different visit from
    // the one on the salon's calendar.
    const serviceLines = lineItems.filter((l) => l.kind === 'service');
    const addonOnlyNames = lineItems.filter((l) => l.kind !== 'service').map((a) => a.name).filter(Boolean).join(', ');

    // Who is actually doing what. The primary service owns the calendar slot;
    // every extra service line can carry its own technician, and a visit split
    // across two people must say so — to the customer, the owner and the techs.
    // Every technician named on an extra line — this visit's, or the whole party's.
    const partyLines = (opts.group ?? []).flatMap((m) => (Array.isArray(m.addons) ? (m.addons as Array<Record<string, unknown> | null>) : []))
      .filter((l): l is Record<string, unknown> => !!l && l.kind === 'service');
    const lineStaffIds = [...new Set([...serviceLines, ...partyLines].map((l) => (l.staffMemberId ? String(l.staffMemberId) : '')).filter(Boolean))];
    const staffNameById = new Map<string, string>();
    if (lineStaffIds.length) {
      const rows = await this.prisma.staffMember
        .findMany({ where: { tenantId, id: { in: lineStaffIds } }, select: { id: true, firstName: true, lastName: true } })
        .catch(() => [] as Array<{ id: string; firstName: string; lastName: string | null }>);
      for (const r of rows) staffNameById.set(r.id, `${r.firstName} ${r.lastName ?? ''}`.trim());
    }
    const primaryTech = appointment.assignedStaff
      ? `${appointment.assignedStaff.firstName} ${appointment.assignedStaff.lastName ?? ''}`.trim()
      : '';
    const lineup = serviceLines.length
      ? [
          primaryTech ? `${appointment.service?.name ?? ''} — ${primaryTech}` : (appointment.service?.name ?? ''),
          ...serviceLines.map((l) => {
            const who = l.staffMemberId ? staffNameById.get(String(l.staffMemberId)) : '';
            const name = String(l.name ?? '');
            return who ? `${name} — ${who}` : name;
          }),
        ].filter(Boolean).join(' · ')
      : '';
    // Was `cents / 100` with a hard en-US: a 200,000₫ service was quoted to the
    // customer as ₫2,000 — a hundredth of the real price, in the message that
    // is supposed to confirm what they will pay.
    const total = formatMoney(appointment.priceCents, appointment.currency, loc);

    const vi = loc.toLowerCase().startsWith('vi');
    // Where the salon is. Optional — a salon that has not filled it in simply
    // gets no address row, exactly as before.
    const extra = await this.settings.getCompanyExtra(tenantId).catch(() => ({ address: '' } as { address?: string }));
    const custFull = `${appointment.customer?.firstName ?? ''} ${appointment.customer?.lastName ?? ''}`.trim();

    const d: BookingTemplateData = {
      salon: tenant?.name ?? 'Our salon',
      customer: appointment.customer?.firstName ?? 'there',
      service: appointment.service?.name ?? 'your appointment',
      date: fmtD(start),
      time: `${fmtT(start)} – ${fmtT(end)}`,
      technician: primaryTech || (vi ? 'Tiệm sẽ sắp xếp' : 'To be assigned'),
      total,
      duration: vi ? `${durationMin} phút` : `${durationMin} min`,
      addons: addonNames,
      accent: this.settings.brandingFrom(tenant?.branding).accentColor,
      contact: tenant?.contactEmail ?? tenant?.contactPhone ?? '',
      // --- the rest of the booking, added so a confirmation is a confirmation ---
      addonsOnly: addonOnlyNames,
      lineup,
      reference: appointment.id.slice(-6).toUpperCase(),
      notes: (appointment.notes ?? '').trim().slice(0, 400),
      address: (extra?.address ?? '').trim(),
      customerPhone: appointment.customer?.phone ?? '',
      customerEmail: appointment.customer?.email ?? '',
      source: bookingSourceLabel(appointment.source, vi),
      // Who is coming and what each person is having — the email's people
      // block and the short text are written from this (one person or a party).
      people: visitPeople((opts.group && opts.group.length > 1 ? opts.group : [appointment]) as unknown as GroupMember[], staffNameById, vi),
      dateShort: start.toLocaleDateString(loc, { weekday: 'short', month: 'short', day: 'numeric', timeZone: tz }),
      timeStart: fmtT(start),
    };
    // A party: one message for everybody — the service line says how many,
    // the lineup names each person with their services and technician, and
    // the total is the party's.
    if (opts.group && opts.group.length > 1) {
      const gs = groupSummary(opts.group, vi);
      d.service = gs.service;
      d.lineup = gs.lineup;
      d.total = formatMoney(gs.totalCents, appointment.currency, loc);
      d.addons = '';
      d.addonsOnly = '';
      // Everyone starts together; each person's length differs, so the party's
      // message gives the start, not one person's end time and duration.
      d.time = fmtT(start);
      d.duration = '';
    }

    const custEmail = appointment.customer?.email;
    const custPhone = appointment.customer?.phone;
    const related = { relatedType: 'appointment', relatedId: appointment.id };
    // Self-service link so the customer can view / confirm / cancel without login.
    const manageUrl = `${publicWebBase()}/appt/${this.apptToken(appointment.id)}`;
    // The same link at SMS size (/a/<33 chars>) — texts are billed per 153 characters.
    const smsManageUrl = this.buildApptSmsUrl(appointment.id);

    // Refer-a-friend invite in the confirmation email — only when the program is
    // ON. Best-effort: any failure here must never block the confirmation.
    let referralBlock: ReferralInvite | null = null;
    try {
      const custId = appointment.customer?.id;
      if (custId) {
        const rs = await this.referral.getForTenant(tenantId);
        if (rs.enabled) {
          const linked = await this.referral.ensureLinkForCustomer(tenantId, custId);
          if (linked) {
            const parts: string[] = [];
            if (rs.referrerPoints > 0) parts.push(`you'll earn ${rs.referrerPoints} points`);
            if (rs.refereePoints > 0) parts.push(`they'll get ${rs.refereePoints} to start`);
            const sub = parts.length
              ? `Share your personal link. When a friend books their first visit, ${parts.join(' and ')}.`
              : 'Share your personal link with friends who would love this salon.';
            referralBlock = { link: linked.link, headline: `Love ${d.salon}? Refer a friend`, sub };
          }
        }
      }
    } catch {
      // referral invite is optional — ignore and send the confirmation anyway
    }
    const smtp =
      n.smtp.user && n.smtp.pass
        ? { host: n.smtp.host, port: n.smtp.port, user: n.smtp.user, pass: n.smtp.pass, secure: n.smtp.secure, replyTo: n.replyTo || undefined, from: `${n.senderName || d.salon} <${n.senderEmail || n.smtp.user}>` }
        : undefined;
    const brevo =
      n.brevo.apiKey && n.senderEmail
        ? { apiKey: n.brevo.apiKey, senderEmail: n.senderEmail, replyTo: n.replyTo || undefined, senderName: n.brevo.senderName || n.senderName || d.salon }
        : undefined;
    // Used when sending via the platform email (Auto): show the SALON's name and
    // route replies to the salon, so the customer never sees a generic sender.
    const senderName = n.senderName || d.salon;
    const replyTo = n.replyTo || n.senderEmail || undefined;
    const gmail =
      n.gmail.clientId && n.gmail.clientSecret && n.gmail.refreshToken && n.gmail.senderEmail
        ? { clientId: n.gmail.clientId, clientSecret: n.gmail.clientSecret, refreshToken: n.gmail.refreshToken, senderEmail: n.gmail.senderEmail, senderName, replyTo }
        : undefined;

    const jobs: Promise<unknown>[] = [];

    // The "booking confirmed" customer message is driven by the editable template
    // catalog when that event is enabled; otherwise we fall back to the legacy
    // inline templates in NotificationSettings.
    const templates = await this.settings.getNotificationTemplates(tenantId);
    const confirmTpl = templates['customer_booking_confirmed'];
    const staffTpl = templates['customer_staff_assigned'];
    if (opts.techUpdate && !(staffTpl && staffTpl.enabled && appointment.assignedStaff)) return;
    // Narrowable nullable: when present + enabled, drive the message from it.
    const tpl = opts.techUpdate ? staffTpl : confirmTpl && confirmTpl.enabled ? confirmTpl : null;
    const pct: Record<string, string> = {
      salon_name: d.salon,
      customer_name: d.customer,
      service_name: d.service,
      staff_name: d.technician,
      appointment_date: d.date,
      appointment_time: d.time,
      duration: d.duration,
      total_price: d.total,
      add_ons: d.addons,
      salon_contact: d.contact,
      booking_id: appointment.id,
      // New placeholders. Existing templates never mention them, so nothing
      // a salon has already written changes; templates that want the full
      // booking can now say so.
      booking_ref: d.reference ?? '',
      customer_full_name: custFull || d.customer,
      customer_phone: d.customerPhone ?? '',
      customer_email: d.customerEmail ?? '',
      service_lineup: d.lineup ?? '',
      add_ons_only: d.addonsOnly ?? '',
      party_size: String(d.people?.length ?? 1),
      booking_notes: d.notes ?? '',
      salon_address: d.address ?? '',
      booking_source: d.source ?? '',
      manage_url: manageUrl,
    };

    // The technician update rides the channels the confirmation uses; never the
    // VN carrier SMS (its text must match a registered template).
    const confOn = confirmTpl && confirmTpl.enabled ? { email: confirmTpl.email, sms: confirmTpl.sms } : { email: n.emailCustomerOnBooking, sms: n.smsCustomerOnBooking };
    // TWO SWITCHES, ONE MEANING. Settings → Notifications has "Email / SMS the
    // customer when they book"; the "Booking confirmed" template has its own
    // Email / SMS boxes. Only the template's used to count — so an owner who
    // turned "SMS the customer" ON in Settings sent nothing, because the
    // template's SMS box was still at its default (off). Either one turned on
    // now sends it (and saving either now keeps the other in step).
    // Still the built-in wording? Then the designed email and the short text
    // are used (they carry the party and every service). A salon that wrote
    // its own words keeps them, exactly as written.
    const isVN = (n.market ?? 'US').toUpperCase() === 'VN';
    const builtIn = (v: string | undefined, ...cands: Array<string | undefined | string[]>) =>
      v != null && cands.flat().filter((c): c is string => typeof c === 'string').includes(v);
    const tplBodyBuiltIn = !!tpl && !opts.techUpdate && builtIn(tpl.body,
      DEFAULT_NOTIFICATION_TEMPLATES.customer_booking_confirmed?.body, VN_TEMPLATE_TEXTS.customer_booking_confirmed?.body, LEGACY_TEMPLATE_DEFAULTS.customer_booking_confirmed?.body ?? []);
    const custSmsBuiltIn = !isVN && !opts.techUpdate && (tpl
      ? builtIn(tpl.smsBody, DEFAULT_NOTIFICATION_TEMPLATES.customer_booking_confirmed?.smsBody, VN_TEMPLATE_TEXTS.customer_booking_confirmed?.smsBody, LEGACY_TEMPLATE_DEFAULTS.customer_booking_confirmed?.smsBody ?? [])
      : builtIn(n.smsCustomer, DEFAULT_NOTIFICATION_SETTINGS.smsCustomer, VN_NOTIFICATION_TEXTS.smsCustomer, LEGACY_NOTIFICATION_DEFAULTS.smsCustomer ?? []));
    const adminSmsBuiltIn = !isVN && builtIn(n.smsAdmin, DEFAULT_NOTIFICATION_SETTINGS.smsAdmin, VN_NOTIFICATION_TEXTS.smsAdmin, LEGACY_NOTIFICATION_DEFAULTS.smsAdmin ?? []);
    const smsPeople = (d.people ?? []).map((p) => ({ name: p.name, services: p.lines.map((l) => l.service) }));

    const emailCustomer = opts.techUpdate ? Boolean(tpl?.email && confOn.email) : tpl ? Boolean(tpl.email || n.emailCustomerOnBooking) : n.emailCustomerOnBooking;
    const smsCustomer = opts.techUpdate ? Boolean(tpl?.sms && confOn.sms && (n.market ?? 'US').toUpperCase() !== 'VN') : tpl ? Boolean(tpl.sms || n.smsCustomerOnBooking) : n.smsCustomerOnBooking;

    if (emailCustomer && custEmail) {
      if (tpl && !tplBodyBuiltIn) {
        const refHtml = referralBlock ? referralBlockHtml(referralBlock, d.accent) : '';
        const manageHtml = `<p style="margin:16px 0 0"><a href="${manageUrl}" style="color:${d.accent};font-weight:600">Manage or cancel your appointment →</a></p>`;
        const bodyFilled = fillPct(tpl.body, pct) + manageHtml + refHtml; // HTML
        jobs.push(this.notifications.send({
          tenantId, channel: NotificationChannel.EMAIL, recipient: custEmail,
          subject: fillPct(tpl.subject, pct),
          body: htmlToText(bodyFilled),
          html: renderTemplatedEmailHtml({ salon: d.salon, accent: d.accent, contact: d.contact, bodyText: bodyFilled }),
          smtp, brevo, gmail, mailService: n.mailService, senderName, replyTo, ...related,
        }));
      } else {
        // Only the customer's own copy carries the self-service link.
        const dc: BookingTemplateData = { ...d, manageUrl };
        const intro = fill(n.emailIntroCustomer, dc);
        const footer = fill(n.emailFooter, dc);
        const heading = vi ? 'Lịch hẹn đã được xác nhận' : 'Booking confirmed';
        jobs.push(this.notifications.send({
          tenantId, channel: NotificationChannel.EMAIL, recipient: custEmail,
          subject: fill(n.emailSubjectCustomer, dc),
          body: renderBookingEmailText(heading, intro, footer, dc, referralBlock, 'customer', vi ? 'vi' : 'en'),
          html: renderBookingEmailHtml({ heading, intro, footer, d: dc, referral: referralBlock, audience: 'customer', lang: vi ? 'vi' : 'en' }),
          smtp, brevo, gmail, mailService: n.mailService, senderName, replyTo, ...related,
        }));
      }
    }
    if (smsCustomer && custPhone) {
      // VN: the SMS must match the CSKH mau tin registered with the carriers,
      // and carriers there allowlist template AND urls — a per-booking manage
      // link is exactly the shape that gets a message silently dropped. So the
      // registered text goes out alone; the manage link still rides the email.
      const smsBase = custSmsBuiltIn
        ? customerBookingSms({ salon: d.salon, dateShort: d.dateShort ?? d.date, timeStart: d.timeStart ?? d.time, people: smsPeople, tech: primaryTech || undefined, total: d.total, link: smsManageUrl, vi })
        : tpl ? fillPct(tpl.smsBody, { ...pct, manage_url: smsManageUrl }) : fill(n.smsCustomer, d);
      // A template that already placed %manage_url% itself gets no second copy.
      const smsText = (n.market ?? 'US').toUpperCase() === 'VN' || smsBase.includes(smsManageUrl)
        ? smsBase
        : `${smsBase}\nManage/cancel: ${smsManageUrl}`;
      jobs.push(this.notifications.send({
        tenantId, channel: NotificationChannel.SMS, recipient: custPhone, body: smsText, twilio: n.twilio,
        // Zalo ZNS first for a configured VN salon (send() decides; everyone
        // else ignores this). Params are Lumio's canonical five — the names
        // the salon registered its ZNS template with.
        zns: {
          kind: 'booking_confirmed',
          params: {
            customer_name: d.customer, salon_name: d.salon, service_name: d.service,
            appointment_date: d.date, appointment_time: d.time,
          },
        },
        ...related,
      }));
    }
    // The technician update is for the customer only: the salon made the change.
    if (opts.techUpdate) { await Promise.allSettled(jobs); return; }
    // Admin notification: the Admin email, then the sender, the salon's contact
    // email and the owner's own login — never a no-reply address (an owner who
    // never filled in "Admin email" had alerts mailed to noreply@lumiobooking.com).
    const adminTo = await this.ownerAlertEmail(tenantId, [n.adminEmail, n.senderEmail, n.gmail.senderEmail, tenant?.contactEmail]);
    if (n.emailAdminOnBooking && adminTo) {
      // The owner's copy is a work order, not a courtesy note: it carries the
      // customer's phone and email, the technician on each service, the note
      // the customer left and where the booking came from. Without those the
      // salon has to open the app to do anything about it.
      const size = d.people?.length ?? 1;
      const da: BookingTemplateData = { ...d, customer: `${custFull || d.customer}${size > 1 ? ` (+${size - 1})` : ''}` };
      const intro = fill(n.emailIntroAdmin, da);
      const heading = vi ? 'Lịch đặt mới' : 'New booking';
      jobs.push(this.notifications.send({
        tenantId, channel: NotificationChannel.EMAIL, recipient: adminTo,
        subject: fill(n.emailSubjectAdmin, da),
        body: renderBookingEmailText(heading, intro, '', da, null, 'owner', vi ? 'vi' : 'en'),
        html: renderBookingEmailHtml({ heading, intro, footer: '', d: da, audience: 'owner', lang: vi ? 'vi' : 'en' }),
        smtp, brevo, gmail, mailService: n.mailService, senderName, replyTo, ...related,
      }));
    }
    if (n.smsAdminOnBooking && n.adminPhone) {
      const ownerText = adminSmsBuiltIn
        ? ownerBookingSms({ salon: d.salon, dateShort: d.dateShort ?? d.date, timeStart: d.timeStart ?? d.time, people: smsPeople, tech: primaryTech || undefined, total: d.total, customer: custFull || d.customer, customerPhone: d.customerPhone || undefined, vi })
        : fill(n.smsAdmin, d);
      jobs.push(this.notifications.send({ tenantId, channel: NotificationChannel.SMS, recipient: n.adminPhone, body: ownerText, twilio: n.twilio, ...related }));
    }
    // Web push to the owner's phone (fire-and-forget; no-op unless VAPID is set).
    // Who, what, when and with whom — the owner can act on the lock screen.
    this.push.sendToTenant(tenantId, { title: 'Booking mới 🗓️', body: `${d.customer} • ${d.service}${d.addonsOnly ? ` + ${d.addonsOnly}` : ''} • ${fmtD(start)} ${fmtT(start)} • 👤 ${d.technician}`, url: '/salon/activity' }).catch(() => undefined);
    await Promise.allSettled(jobs);
  }

  /**
   * Emails the assigned technician about a booking (the `staff_new_booking`
   * template). Fire-and-forget; safe no-op when the staff has no email or the
   * template is disabled. Uses the salon's SMTP connection.
   */
  /**
   * Scan upcoming appointments and send any due automated reminders (no-show
   * reduction). Safe to call repeatedly: each window's reminder fires at most
   * once (guarded by remind1SentAt / remind2SentAt). Only runs for salons that
   * have turned reminders ON. Called on an interval by ReminderService.
   */
  async processDueReminders(): Promise<{ sent: number }> {
    const now = new Date();
    // As far ahead as any salon may ask (168h); each salon's own windows are
    // checked below. It was 26h, so a "3 days before" reminder never went out.
    const maxAhead = new Date(now.getTime() + 170 * 3600 * 1000);
    const appts = await this.prisma.appointment.findMany({
      where: {
        status: { in: [AppointmentStatus.ASSIGNED, AppointmentStatus.ACCEPTED, AppointmentStatus.CONFIRMED, AppointmentStatus.PENDING] },
        startTime: { gt: now, lt: maxAhead },
        OR: [{ remind1SentAt: null }, { remind2SentAt: null }],
      },
      include: {
        customer: { select: { id: true, firstName: true, email: true, phone: true } },
        service: { select: { name: true } },
        assignedStaff: { select: { firstName: true, lastName: true } },
      },
      // Soonest first: when there are more than fit, the ones about to happen go out.
      orderBy: { startTime: 'asc' },
      take: 2000,
    });
    if (appts.length === 0) return { sent: 0 };

    const cache = new Map<string, ReminderSettings>();
    let sent = 0;
    for (const a of appts) {
      let rs = cache.get(a.tenantId);
      if (!rs) { rs = await this.settings.getReminderSettings(a.tenantId); cache.set(a.tenantId, rs); }
      if (!rs.enabled) continue;
      const hoursToStart = (a.startTime.getTime() - now.getTime()) / 3_600_000;
      // Earlier reminder: between the two windows (so a last-minute booking gets
      // only the later one, not both at once).
      if (!a.remind1SentAt && rs.hoursBefore1 > 0 && hoursToStart <= rs.hoursBefore1 && hoursToStart > rs.hoursBefore2) {
        await this.sendReminderFor(a.tenantId, a, rs).catch(() => undefined);
        await this.prisma.appointment.updateMany({ where: { id: a.id, tenantId: a.tenantId }, data: { remind1SentAt: new Date() } });
        sent++;
      } else if (!a.remind2SentAt && rs.hoursBefore2 > 0 && hoursToStart <= rs.hoursBefore2) {
        await this.sendReminderFor(a.tenantId, a, rs).catch(() => undefined);
        await this.prisma.appointment.updateMany({ where: { id: a.id, tenantId: a.tenantId }, data: { remind2SentAt: new Date() } });
        sent++;
      }
    }
    return { sent };
  }

  /** Send a single reminder (email + SMS, per the salon's reminder channels). */
  private async sendReminderFor(
    tenantId: string,
    appt: { id: string; startTime: Date; customer: { id?: string; firstName: string | null; email: string | null; phone: string | null } | null; service: { name: string } | null },
    rs: ReminderSettings,
  ) {
    const custEmail = appt.customer?.email;
    const custPhone = appt.customer?.phone;
    if (!custEmail && !custPhone) return;
    const n = await this.settings.getNotificationSettings(tenantId);
    const tenant = await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { name: true, contactEmail: true, contactPhone: true, timezone: true } });
    const tz = tenant?.timezone || 'America/New_York';
    const loc = await this.customerLocale(tenantId, tenant?.timezone);
    const fmtT = (dd: Date) => dd.toLocaleTimeString(loc, { hour: 'numeric', minute: '2-digit', timeZone: tz });
    const fmtD = (dd: Date) => dd.toLocaleDateString(loc, { weekday: 'short', month: 'long', day: 'numeric', timeZone: tz });
    const salon = tenant?.name ?? 'Our salon';
    const cust = appt.customer?.firstName ?? 'there';
    const svc = appt.service?.name ?? 'your appointment';
    const when = `${fmtD(appt.startTime)} at ${fmtT(appt.startTime)}`;
    const contact = tenant?.contactPhone || tenant?.contactEmail || '';
    // One-tap self-service link (Confirm / Cancel) — no login needed.
    const actionUrl = `${publicWebBase()}/appt/${this.apptToken(appt.id)}`;
    const smsActionUrl = this.buildApptSmsUrl(appt.id);
    const subject = `Reminder: your ${svc} at ${salon} — ${when}`;
    const text = `Hi ${cust}, a friendly reminder of your ${svc} at ${salon} on ${when}. Confirm or cancel: ${actionUrl}` + (contact ? ` — or call ${contact}.` : '') + ' See you soon!';
    const html = `<p>Hi ${cust},</p><p>This is a friendly reminder of your <strong>${svc}</strong> at <strong>${salon}</strong>:</p><p style="font-size:16px"><strong>${when}</strong></p>`
      + `<p style="margin:18px 0"><a href="${actionUrl}" style="background:#16a34a;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:600;margin-right:8px">✓ Confirm</a> <a href="${actionUrl}" style="background:#fff;color:#dc2626;border:1px solid #dc2626;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:600">Can't make it?</a></p>`
      + (contact ? `<p style="color:#64748b;font-size:13px">Or call us at ${contact}.</p>` : '') + '<p>See you soon! 💅</p>';
    // VN: the registered CSKH mau tin has no room for a per-booking link (the
    // carriers allowlist template AND urls), and STOP is a US convention.
    const smsText = (n.market ?? 'US').toUpperCase() === 'VN'
      ? `${salon}: Nhac ban lich hen ${svc} ngay ${when}. Hen gap ban!`
      : `${salon}: reminder - ${svc} on ${when}. Confirm/cancel: ${smsActionUrl}\nReply STOP to opt out.`;

    const senderName = n.senderName || salon;
    const replyTo = n.replyTo || n.senderEmail || undefined;
    const smtp = n.smtp.user && n.smtp.pass
      ? { host: n.smtp.host, port: n.smtp.port, user: n.smtp.user, pass: n.smtp.pass, secure: n.smtp.secure, replyTo: n.replyTo || undefined, from: `${senderName} <${n.senderEmail || n.smtp.user}>` }
      : undefined;
    const brevo = n.brevo.apiKey && n.senderEmail
      ? { apiKey: n.brevo.apiKey, senderEmail: n.senderEmail, replyTo: n.replyTo || undefined, senderName: n.brevo.senderName || senderName }
      : undefined;
    const gmail = n.gmail.clientId && n.gmail.clientSecret && n.gmail.refreshToken && n.gmail.senderEmail
      ? { clientId: n.gmail.clientId, clientSecret: n.gmail.clientSecret, refreshToken: n.gmail.refreshToken, senderEmail: n.gmail.senderEmail, senderName, replyTo }
      : undefined;
    const related = { relatedType: 'appointment', relatedId: appt.id };

    // Refer-a-friend footer — EMAIL ONLY (never the SMS, which stays transactional
    // to keep 10DLC/toll-free traffic clean). Best-effort + only when the program is on.
    let refHtml = '';
    let refText = '';
    try {
      const custId = appt.customer?.id;
      if (custId) {
        const refs = await this.referral.getForTenant(tenantId);
        if (refs.enabled) {
          const linked = await this.referral.ensureLinkForCustomer(tenantId, custId);
          if (linked) {
            const parts: string[] = [];
            if (refs.referrerPoints > 0) parts.push(`you'll earn ${refs.referrerPoints} points`);
            if (refs.refereePoints > 0) parts.push(`they'll get ${refs.refereePoints} to start`);
            const sub = parts.length
              ? `Share your personal link. When a friend books their first visit, ${parts.join(' and ')}.`
              : 'Share your personal link with friends who would love this salon.';
            const invite = { link: linked.link, headline: `Love ${salon}? Refer a friend`, sub };
            refHtml = referralBlockHtml(invite, '#4f46e5');
            refText = `\n\n${referralBlockText(invite)}`;
          }
        }
      }
    } catch { /* referral is optional — never block a reminder */ }

    const jobs: Promise<unknown>[] = [];
    if (rs.channelEmail && custEmail) {
      jobs.push(this.notifications.send({ tenantId, channel: NotificationChannel.EMAIL, recipient: custEmail, subject, body: text + refText, html: html + refHtml, smtp, brevo, gmail, mailService: n.mailService, senderName, replyTo, ...related }));
    }
    if (rs.channelSms && custPhone) {
      jobs.push(this.notifications.send({
        tenantId, channel: NotificationChannel.SMS, recipient: custPhone, body: smsText, twilio: n.twilio,
        zns: {
          kind: 'reminder',
          params: {
            customer_name: cust, salon_name: salon, service_name: svc,
            appointment_date: fmtD(appt.startTime), appointment_time: fmtT(appt.startTime),
          },
        },
        ...related,
      }));
    }
    await Promise.allSettled(jobs);
  }

  /**
   * Post-visit review nudge (appointments + walk-ins): while the customer is STILL in
   * the chair, send a warm thank-you + a one-tap Google review link. The link goes
   * through the salon's review page so the tap is TRACKED and credits the right tech
   * (reusing the existing anti-fraud send log). Fires once, honours a per-customer
   * cooldown, and a short message-frequency cap so we never pile onto a reminder.
   */
  async processDueReviewRequests(): Promise<{ sent: number }> {
    const now = new Date();
    const cache = new Map<string, ReviewSettings>();
    // A salon that switched on Feedback (the two-button "how was your visit?"
    // after payment) is already asking every paid visit — this older mid-service
    // Google nudge stands aside there, so nobody is asked twice.
    const fbOn = new Map<string, boolean>();
    const getRs = async (t: string) => {
      let rs = cache.get(t);
      if (!rs) {
        rs = await this.settings.getReviewSettings(t);
        if (!fbOn.has(t)) {
          const row = await this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId: t, key: 'feedback_settings' } }, select: { value: true } }).catch(() => null);
          fbOn.set(t, !!(row?.value as { enabled?: boolean } | null)?.enabled);
        }
        if (fbOn.get(t)) rs = { ...rs, postVisitEnabled: false };
        cache.set(t, rs);
      }
      return rs;
    };
    let sent = 0;

    // 1) Booked customers who checked in.
    const appts = await this.prisma.appointment.findMany({
      where: { status: AppointmentStatus.ARRIVED, arrivedAt: { not: null }, reviewReqSentAt: null },
      include: { customer: { select: { id: true, firstName: true, email: true, phone: true } }, assignedStaff: { select: { firstName: true } } },
      take: 300,
    });
    for (const a of appts) {
      if (!a.arrivedAt) continue;
      const rs = await getRs(a.tenantId);
      if (!rs.postVisitEnabled) continue;
      if (now.getTime() < a.arrivedAt.getTime() + Math.max(1, rs.postVisitDelayMinutes) * 60_000) continue;
      if (a.customerId && rs.postVisitCooldownDays > 0 && await this.reviewedRecently(a.tenantId, a.customerId, rs.postVisitCooldownDays, a.id)) {
        await this.prisma.appointment.updateMany({ where: { id: a.id, tenantId: a.tenantId }, data: { reviewReqSentAt: now } }); continue;
      }
      const ok = await this.sendReviewRequestFor(rs, { tenantId: a.tenantId, refId: a.id, firstName: a.customer?.firstName ?? null, email: a.customer?.email ?? null, phone: a.customer?.phone ?? null, staffId: a.assignedStaffId ?? null, staffFirstName: a.assignedStaff?.firstName ?? null }).catch(() => false);
      await this.prisma.appointment.updateMany({ where: { id: a.id, tenantId: a.tenantId }, data: { reviewReqSentAt: new Date() } });
      if (ok !== false) sent++;
    }

    // 2) Walk-ins currently being served (no appointment needed).
    const walkins = await this.prisma.walkIn.findMany({
      where: { status: 'SERVING', reviewReqSentAt: null },
      include: { customer: { select: { id: true, firstName: true, email: true, phone: true } }, assignedStaff: { select: { firstName: true } } },
      take: 300,
    });
    for (const w of walkins) {
      const rs = await getRs(w.tenantId);
      if (!rs.postVisitEnabled) continue;
      if (now.getTime() < w.createdAt.getTime() + Math.max(1, rs.postVisitDelayMinutes) * 60_000) continue;
      const cid = w.customerId ?? null;
      if (cid && rs.postVisitCooldownDays > 0 && await this.reviewedRecently(w.tenantId, cid, rs.postVisitCooldownDays, null)) {
        await this.prisma.walkIn.updateMany({ where: { id: w.id, tenantId: w.tenantId }, data: { reviewReqSentAt: now } }); continue;
      }
      const ok = await this.sendReviewRequestFor(rs, { tenantId: w.tenantId, refId: w.id, firstName: w.customer?.firstName ?? w.customerName ?? null, email: w.customer?.email ?? null, phone: w.phone ?? w.customer?.phone ?? null, staffId: w.assignedStaffId ?? null, staffFirstName: w.assignedStaff?.firstName ?? null }).catch(() => false);
      await this.prisma.walkIn.updateMany({ where: { id: w.id, tenantId: w.tenantId }, data: { reviewReqSentAt: new Date() } });
      if (ok !== false) sent++;
    }
    return { sent };
  }

  /** Was this customer sent a review request (appt or walk-in) within N days? */
  private async reviewedRecently(tenantId: string, customerId: string, days: number, excludeApptId: string | null): Promise<boolean> {
    const since = new Date(Date.now() - days * 86_400_000);
    const a = await this.prisma.appointment.findFirst({ where: { tenantId, customerId, reviewReqSentAt: { gte: since }, ...(excludeApptId ? { id: { not: excludeApptId } } : {}) }, select: { id: true } });
    if (a) return true;
    const w = await this.prisma.walkIn.findFirst({ where: { tenantId, customerId, reviewReqSentAt: { gte: since } }, select: { id: true } });
    return !!w;
  }

  /** Message-frequency guard: has ANY of these recipients been messaged in the last N hours? */
  private async messagedWithin(tenantId: string, recipients: Array<string | null | undefined>, hours: number): Promise<boolean> {
    const rec = recipients.filter((r): r is string => !!r && !!r.trim());
    if (rec.length === 0) return false;
    const since = new Date(Date.now() - hours * 3_600_000);
    const c = await this.prisma.notification.count({ where: { tenantId, recipient: { in: rec }, createdAt: { gte: since } } });
    return c > 0;
  }

  /** Send one review request (SMS + email) to a normalized appt/walk-in target. */
  private async sendReviewRequestFor(
    rs: ReviewSettings,
    tgt: { tenantId: string; refId: string; firstName: string | null; email: string | null; phone: string | null; staffId: string | null; staffFirstName: string | null },
  ): Promise<boolean> {
    const tenantId = tgt.tenantId;
    const custEmail = tgt.email;
    const custPhone = tgt.phone;
    if (!custEmail && !custPhone) return false;
    // Frequency cap: don't stack a review nudge on top of a message sent in the last 6h.
    if (await this.messagedWithin(tenantId, [custEmail, custPhone], 6)) return false;

    const tenant = await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { name: true, slug: true, branding: true } });
    // Prefer the TRACKED review-page link (credits the tech, iOS-safe deep link); fall
    // back to the raw Google link only when we have no tech to credit.
    const placeId = (rs.googlePlaceId ?? '').trim();
    let rawGoogle: string | null = null;
    if (placeId) rawGoogle = /^https?:\/\//i.test(placeId) ? placeId : `https://search.google.com/local/writereview?placeid=${encodeURIComponent(placeId)}`;
    else if ((rs.googleReviewUrl ?? '').trim()) rawGoogle = (rs.googleReviewUrl ?? '').trim();
    const url = (tgt.staffId && tenant?.slug) ? `${publicWebBase()}/review/${tenant.slug}/${tgt.staffId}` : rawGoogle;
    if (!url) return false; // no Google link configured at all — nothing to send

    const n = await this.settings.getNotificationSettings(tenantId);
    const salon = tenant?.name ?? 'our salon';
    const cust = tgt.firstName ?? 'there';
    const tech = tgt.staffFirstName ?? '';
    const brand = this.settings.brandingFrom(tenant?.branding);
    const accent = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(brand.accentColor || '') ? brand.accentColor : '#6d5efc';
    const sh = (hex: string) => { const h = hex.replace('#', ''); const nn = h.length === 3 ? h.split('').map((c) => c + c).join('') : h; const f = (i: number) => Math.max(0, Math.round((parseInt(nn.slice(i, i + 2), 16) || 0) * 0.72)); return `rgb(${f(0)}, ${f(2)}, ${f(4)})`; };
    const accentDark = sh(accent);
    const withTech = tech ? `${tech} and the team` : 'the team';

    const subject = `${cust}, how's your visit going? ⭐`;
    const html = `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;max-width:520px;margin:0 auto;padding:8px">`
      + `<div style="background:linear-gradient(120deg,${accent},${accentDark});padding:28px 24px;border-radius:16px 16px 0 0;text-align:center">`
      + `<div style="color:#fff;font-size:22px;font-weight:800;letter-spacing:-0.2px">${salon}</div>`
      + `<div style="color:rgba(255,255,255,0.88);font-size:14px;margin-top:6px">Thank you for spending time with us today 💕</div></div>`
      + `<div style="background:#fff;padding:26px 24px;border:1px solid #eef1f6;border-top:none;border-radius:0 0 16px 16px;text-align:center">`
      + `<div style="font-size:30px;letter-spacing:5px">⭐⭐⭐⭐⭐</div>`
      + `<p style="font-size:17px;color:#0f2a52;margin:14px 0 6px;font-weight:800">Hi ${cust}, are you loving it so far?</p>`
      + `<p style="font-size:14px;color:#5b6b85;line-height:1.65;margin:0 0 22px">If ${withTech} made you smile, a quick Google review would mean the world to a small salon like ours — it takes about 30 seconds and helps other clients find us. Thank you! 🙏</p>`
      + `<a href="${url}" style="display:inline-block;background:${accent};color:#fff;text-decoration:none;padding:15px 30px;border-radius:999px;font-weight:800;font-size:15px">⭐ Leave a Google review</a>`
      + `<p style="font-size:12px;color:#94a3b8;margin-top:18px">One tap opens Google — you're already signed in.</p></div></div>`;
    const text = `Hi ${cust}! Thank you for visiting ${salon} today. If ${withTech} made you smile, a quick Google review would mean the world (about 30 seconds): ${url} — thank you! 🙏`;
    const smsText = `${salon}: Hi ${cust}! Enjoying your visit? 💕 A 30-second Google review would make our day: ${url} Thank you! Reply STOP to opt out.`;

    const senderName = n.senderName || salon;
    const replyTo = n.replyTo || n.senderEmail || undefined;
    const smtp = n.smtp.user && n.smtp.pass
      ? { host: n.smtp.host, port: n.smtp.port, user: n.smtp.user, pass: n.smtp.pass, secure: n.smtp.secure, replyTo: n.replyTo || undefined, from: `${senderName} <${n.senderEmail || n.smtp.user}>` }
      : undefined;
    const brevo = n.brevo.apiKey && n.senderEmail
      ? { apiKey: n.brevo.apiKey, senderEmail: n.senderEmail, replyTo: n.replyTo || undefined, senderName: n.brevo.senderName || senderName }
      : undefined;
    const gmail = n.gmail.clientId && n.gmail.clientSecret && n.gmail.refreshToken && n.gmail.senderEmail
      ? { clientId: n.gmail.clientId, clientSecret: n.gmail.clientSecret, refreshToken: n.gmail.refreshToken, senderEmail: n.gmail.senderEmail, senderName, replyTo }
      : undefined;
    const related = { relatedType: 'review_request', relatedId: tgt.refId };

    const jobs: Promise<unknown>[] = [];
    if (rs.postVisitEmail && custEmail) {
      jobs.push(this.notifications.send({ tenantId, channel: NotificationChannel.EMAIL, recipient: custEmail, subject, body: text, html, smtp, brevo, gmail, mailService: n.mailService, senderName, replyTo, ...related }));
    }
    if (rs.postVisitSms && custPhone) {
      jobs.push(this.notifications.send({ tenantId, channel: NotificationChannel.SMS, recipient: custPhone, body: smsText, twilio: n.twilio, ...related }));
    }
    await Promise.allSettled(jobs);
    return true;
  }

  /** A tenant's industry (common/industry) — decides the reminder's wording. */
  private async industryOfTenant(tenantId: string): Promise<string> {
    try {
      const [t, row] = await Promise.all([
        this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { businessType: true } }),
        this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: INDUSTRY_KEY } } }),
      ]);
      return resolveIndustry(row?.value ?? null, (t as { businessType?: string } | null)?.businessType ?? null);
    } catch { return 'NAIL'; }
  }

  /**
   * RECALL for patients whose record says "recall every N months" (dental
   * clinics, see bookings/recall.ts). Uses the salon's own "rebooking
   * reminder" switch and channels — off unless the clinic turned it on —
   * and the same once-per-visit stamp (rebookRemindedAt). One clinic at a
   * time; every read and write carries its tenantId.
   */
  async processDueRecalls(now = new Date()): Promise<{ sent: number }> {
    const rows = await this.prisma.setting.findMany({ where: { key: INDUSTRY_KEY }, select: { tenantId: true, value: true } }).catch(() => [] as { tenantId: string; value: unknown }[]);
    const clinics = rows.filter((r) => String((r.value as { key?: string } | null)?.key ?? '').toUpperCase() === 'DENTAL').map((r) => r.tenantId);
    let sent = 0;
    for (const tenantId of clinics) {
      try {
        if ((await this.industryOfTenant(tenantId)) !== 'DENTAL') continue;
        const rb = await this.settings.getRebookingSettings(tenantId);
        if (!rb.enabled || (!rb.email && !rb.sms)) continue;
        const custs = (await this.prisma.customer.findMany({
          where: { tenantId },
          select: { id: true, firstName: true, email: true, phone: true, rebookRemindedAt: true, industryFields: true } as never,
          take: 5000,
        })) as unknown as { id: string; firstName: string; email: string | null; phone: string | null; rebookRemindedAt: Date | null; industryFields: unknown }[];
        let perTenant = 0;
        for (const c of custs) {
          if (perTenant >= 200) break;
          const months = recallMonthsOf(c.industryFields);
          if (!months || (!c.email && !c.phone)) continue;
          const last = await this.prisma.appointment.findFirst({
            where: { tenantId, customerId: c.id, status: AppointmentStatus.COMPLETED },
            orderBy: { endTime: 'desc' }, select: { id: true, endTime: true, service: { select: { name: true } } },
          });
          if (!last) continue;
          const upcoming = await this.prisma.appointment.findFirst({
            where: { tenantId, customerId: c.id, startTime: { gt: now }, status: { in: [AppointmentStatus.PENDING, AppointmentStatus.ASSIGNED, AppointmentStatus.ACCEPTED, AppointmentStatus.CONFIRMED, AppointmentStatus.ARRIVED] } },
            select: { id: true },
          });
          if (!recallDue({ lastVisitEnd: last.endTime, months, remindedAt: c.rebookRemindedAt, hasUpcoming: !!upcoming, now })) continue;
          if (await this.messagedWithin(tenantId, [c.email, c.phone], 48)) continue;
          const ok = await this.sendRebookingFor(tenantId, rb, { firstName: c.firstName ?? null, email: c.email, phone: c.phone, service: last.service?.name ?? null, refId: last.id }, { industry: 'DENTAL', months }).catch(() => false);
          await this.prisma.customer.updateMany({ where: { id: c.id, tenantId }, data: { rebookRemindedAt: new Date() } });
          if (ok !== false) { sent++; perTenant++; }
        }
      } catch (e) {
        this.logger.warn(`Recall pass failed for ${tenantId}: ${String(e).slice(0, 120)}`);
      }
    }
    return { sent };
  }

  /**
   * Rebooking reminder: N days after a visit (default ~3 weeks for nails), if the
   * customer has NOT already booked their next visit, send a warm "time for a refill"
   * nudge with a one-tap booking link. One reminder per visit-cycle; frequency-capped.
   */
  async processDueRebookingReminders(): Promise<{ sent: number }> {
    const now = new Date();
    const from = new Date(now.getTime() - 95 * 86_400_000);
    const to = new Date(now.getTime() - 7 * 86_400_000);
    const appts = await this.prisma.appointment.findMany({
      where: { status: AppointmentStatus.COMPLETED, endTime: { gte: from, lte: to } },
      include: { customer: { select: { id: true, firstName: true, email: true, phone: true, rebookRemindedAt: true } }, service: { select: { name: true } } },
      orderBy: { endTime: 'desc' },
      take: 500,
    });
    const cache = new Map<string, RebookingSettings>();
    const getRb = async (t: string) => { let rb = cache.get(t); if (!rb) { rb = await this.settings.getRebookingSettings(t); cache.set(t, rb); } return rb; };
    const indCache = new Map<string, string>();
    const getInd = async (t: string) => { let k = indCache.get(t); if (!k) { k = await this.industryOfTenant(t); indCache.set(t, k); } return k; };
    const seen = new Set<string>(); // only the LATEST completed visit per customer (desc order)
    let sent = 0;
    for (const a of appts) {
      if (!a.customerId) continue;
      const key = `${a.tenantId}:${a.customerId}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const rb = await getRb(a.tenantId);
      if (!rb.enabled) continue;
      if (now.getTime() < a.endTime.getTime() + rb.daysAfter * 86_400_000) continue; // not due yet
      if (a.customer?.rebookRemindedAt && a.customer.rebookRemindedAt.getTime() >= a.endTime.getTime()) continue; // already reminded for this visit
      const upcoming = await this.prisma.appointment.findFirst({
        where: { tenantId: a.tenantId, customerId: a.customerId, startTime: { gt: now }, status: { in: [AppointmentStatus.PENDING, AppointmentStatus.ASSIGNED, AppointmentStatus.ACCEPTED, AppointmentStatus.CONFIRMED, AppointmentStatus.ARRIVED] } },
        select: { id: true },
      });
      if (upcoming) continue; // already rebooked
      if (await this.messagedWithin(a.tenantId, [a.customer?.email, a.customer?.phone], 48)) continue;
      const industry = await getInd(a.tenantId);
      if (industry === 'DENTAL') {
        // A patient with a recall interval is handled by processDueRecalls, on their own schedule.
        const rec = await this.prisma.customer.findFirst({ where: { id: a.customerId, tenantId: a.tenantId }, select: { industryFields: true } as never }).catch(() => null) as { industryFields?: unknown } | null;
        if (recallMonthsOf(rec?.industryFields)) continue;
      }
      const ok = await this.sendRebookingFor(a.tenantId, rb, { firstName: a.customer?.firstName ?? null, email: a.customer?.email ?? null, phone: a.customer?.phone ?? null, service: a.service?.name ?? null, refId: a.id }, { industry, months: null }).catch(() => false);
      await this.prisma.customer.updateMany({ where: { id: a.customerId, tenantId: a.tenantId }, data: { rebookRemindedAt: new Date() } });
      if (ok !== false) sent++;
    }
    return { sent };
  }

  /** Send one rebooking nudge (SMS + email) with a one-tap booking link. */
  private async sendRebookingFor(
    tenantId: string,
    rb: RebookingSettings,
    tgt: { firstName: string | null; email: string | null; phone: string | null; service: string | null; refId: string },
    trade: { industry: string; months: number | null } = { industry: 'NAIL', months: null },
  ): Promise<boolean> {
    const custEmail = tgt.email;
    const custPhone = tgt.phone;
    if (!custEmail && !custPhone) return false;
    const n = await this.settings.getNotificationSettings(tenantId);
    const tenant = await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { name: true, slug: true, branding: true } });
    const salon = tenant?.name ?? 'our salon';
    const cust = tgt.firstName ?? 'there';
    const bookUrl = tenant?.slug ? `${publicWebBase()}/${tenant.slug}` : publicWebBase();
    const brand = this.settings.brandingFrom(tenant?.branding);
    const accent = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(brand.accentColor || '') ? brand.accentColor : '#6d5efc';
    const sh = (hex: string) => { const h = hex.replace('#', ''); const nn = h.length === 3 ? h.split('').map((c) => c + c).join('') : h; const f = (i: number) => Math.max(0, Math.round((parseInt(nn.slice(i, i + 2), 16) || 0) * 0.72)); return `rgb(${f(0)}, ${f(2)}, ${f(4)})`; };
    const accentDark = sh(accent);
    const svcLine = tgt.service ? ` for another ${tgt.service}` : '';

    const subject = `${cust}, time to treat yourself again? 💅`;
    const html = `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;max-width:520px;margin:0 auto;padding:8px">`
      + `<div style="background:linear-gradient(120deg,${accent},${accentDark});padding:28px 24px;border-radius:16px 16px 0 0;text-align:center">`
      + `<div style="color:#fff;font-size:22px;font-weight:800;letter-spacing:-0.2px">${salon}</div>`
      + `<div style="color:rgba(255,255,255,0.9);font-size:14px;margin-top:6px">We miss you already 💕</div></div>`
      + `<div style="background:#fff;padding:26px 24px;border:1px solid #eef1f6;border-top:none;border-radius:0 0 16px 16px;text-align:center">`
      + `<p style="font-size:17px;color:#0f2a52;margin:6px 0 6px;font-weight:800">Hi ${cust}, it's been a few weeks!</p>`
      + `<p style="font-size:14px;color:#5b6b85;line-height:1.65;margin:0 0 22px">Your nails are probably ready for a little refresh${svcLine}. Book your next visit in a few taps — we'd love to pamper you again. 💅</p>`
      + `<a href="${bookUrl}" style="display:inline-block;background:${accent};color:#fff;text-decoration:none;padding:15px 30px;border-radius:999px;font-weight:800;font-size:15px">Book my next visit</a>`
      + `<p style="font-size:12px;color:#94a3b8;margin-top:18px">See you soon! ✨</p></div></div>`;
    const text = `Hi ${cust}! It's been a few weeks — your nails are probably ready for a refresh${svcLine}. Book your next visit at ${salon}: ${bookUrl} — see you soon! 💅`;
    const smsText = `${salon}: Hi ${cust}! 💅 Ready for a refresh? Book your next visit in a few taps: ${bookUrl} Reply STOP to opt out.`;
    // Not a nail salon: the trade's own words (a clinic's check-up, a neutral next visit).
    const copy = rebookCopy(trade.industry, { salon, cust, service: tgt.service, months: trade.months, url: bookUrl });
    const esc = (x: string) => x.replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch] as string));
    const mail = copy
      ? {
        subject: copy.subject, text: copy.text, sms: copy.sms,
        html: `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;max-width:520px;margin:0 auto;padding:8px">`
          + `<div style="background:linear-gradient(120deg,${accent},${accentDark});padding:28px 24px;border-radius:16px 16px 0 0;text-align:center">`
          + `<div style="color:#fff;font-size:22px;font-weight:800;letter-spacing:-0.2px">${esc(salon)}</div>`
          + `<div style="color:rgba(255,255,255,0.9);font-size:14px;margin-top:6px">${esc(copy.tagline)}</div></div>`
          + `<div style="background:#fff;padding:26px 24px;border:1px solid #eef1f6;border-top:none;border-radius:0 0 16px 16px;text-align:center">`
          + `<p style="font-size:17px;color:#0f2a52;margin:6px 0 6px;font-weight:800">${esc(copy.headline)}</p>`
          + `<p style="font-size:14px;color:#5b6b85;line-height:1.65;margin:0 0 22px">${esc(copy.body)}</p>`
          + `<a href="${bookUrl}" style="display:inline-block;background:${accent};color:#fff;text-decoration:none;padding:15px 30px;border-radius:999px;font-weight:800;font-size:15px">${esc(copy.button)}</a></div></div>`,
      }
      : { subject, text, sms: smsText, html };

    const senderName = n.senderName || salon;
    const replyTo = n.replyTo || n.senderEmail || undefined;
    const smtp = n.smtp.user && n.smtp.pass
      ? { host: n.smtp.host, port: n.smtp.port, user: n.smtp.user, pass: n.smtp.pass, secure: n.smtp.secure, replyTo: n.replyTo || undefined, from: `${senderName} <${n.senderEmail || n.smtp.user}>` }
      : undefined;
    const brevo = n.brevo.apiKey && n.senderEmail
      ? { apiKey: n.brevo.apiKey, senderEmail: n.senderEmail, replyTo: n.replyTo || undefined, senderName: n.brevo.senderName || senderName }
      : undefined;
    const gmail = n.gmail.clientId && n.gmail.clientSecret && n.gmail.refreshToken && n.gmail.senderEmail
      ? { clientId: n.gmail.clientId, clientSecret: n.gmail.clientSecret, refreshToken: n.gmail.refreshToken, senderEmail: n.gmail.senderEmail, senderName, replyTo }
      : undefined;
    const related = { relatedType: 'rebooking', relatedId: tgt.refId };

    const jobs: Promise<unknown>[] = [];
    if (rb.email && custEmail) {
      jobs.push(this.notifications.send({ tenantId, channel: NotificationChannel.EMAIL, recipient: custEmail, subject: mail.subject, body: mail.text, html: mail.html, smtp, brevo, gmail, mailService: n.mailService, senderName, replyTo, ...related }));
    }
    if (rb.sms && custPhone) {
      jobs.push(this.notifications.send({ tenantId, channel: NotificationChannel.SMS, kind: 'marketing', recipient: custPhone, body: mail.sms, twilio: n.twilio, ...related }));
    }
    await Promise.allSettled(jobs);
    return true;
  }

  private async sendStaffAssignmentEmail(tenantId: string, appointmentId: string) {
    const appt = await this.prisma.appointment.findFirst({
      where: { id: appointmentId, tenantId },
      select: {
        id: true, startTime: true, endTime: true, priceCents: true, currency: true, addons: true,
        notes: true,
        customer: { select: { firstName: true, lastName: true, phone: true, email: true } },
        service: { select: { name: true } },
        assignedStaff: {
          select: { firstName: true, lastName: true, email: true, phone: true, user: { select: { email: true } } },
        },
      },
    });
    if (!appt || !appt.assignedStaff) return;
    const staffEmail = appt.assignedStaff.email || appt.assignedStaff.user?.email;
    const staffPhone = appt.assignedStaff.phone || '';

    const templates = await this.settings.getNotificationTemplates(tenantId);
    const tpl = templates['staff_new_booking'];
    if (!tpl || !tpl.enabled) return;
    // Email needs an address, SMS needs a number. Either one alone is a reason
    // to keep going — a tech with no work email used to be told nothing at all.
    const wantEmail = tpl.email && Boolean(staffEmail);
    const wantSms = tpl.sms && Boolean(staffPhone);
    if (!wantEmail && !wantSms) return;

    const n = await this.settings.getNotificationSettings(tenantId);
    const tenant = await this.prisma.tenant.findUnique({
      where: { id: tenantId },
      select: { name: true, contactEmail: true, contactPhone: true, branding: true, timezone: true },
    });

    const tz = tenant?.timezone || 'America/New_York';
    const loc = await this.customerLocale(tenantId, tenant?.timezone);
    const fmtT = (dd: Date) => dd.toLocaleTimeString(loc, { hour: 'numeric', minute: '2-digit', timeZone: tz });
    const fmtD = (dd: Date) => dd.toLocaleDateString(loc, { weekday: 'short', month: 'long', day: 'numeric', year: 'numeric', timeZone: tz });
    const start = appt.startTime;
    const end = appt.endTime;
    const durationMin = Math.round((end.getTime() - start.getTime()) / 60_000);
    const lineItems: Array<Record<string, unknown>> = Array.isArray(appt.addons)
      ? (appt.addons as unknown as Array<Record<string, unknown>>).filter(Boolean)
      : [];
    const addonNames = lineItems.map((a) => a.name).filter(Boolean).join(', ');
    const serviceLines = lineItems.filter((l) => l.kind === 'service');
    const addonOnlyNames = lineItems.filter((l) => l.kind !== 'service').map((a) => a.name).filter(Boolean).join(', ');
    const total = formatMoney(appt.priceCents, appt.currency, loc);
    const salon = tenant?.name ?? 'Our salon';
    const accent = this.settings.brandingFrom(tenant?.branding).accentColor;
    const contact = tenant?.contactEmail ?? tenant?.contactPhone ?? '';
    const customerName = `${appt.customer?.firstName ?? ''} ${appt.customer?.lastName ?? ''}`.trim() || 'A customer';
    const staffName = `${appt.assignedStaff.firstName} ${appt.assignedStaff.lastName ?? ''}`.trim();

    // Who else is on this visit. A tech walking to the chair needs to know that
    // the second service is someone else's, and which one is theirs.
    const lineStaffIds = [...new Set(serviceLines.map((l) => (l.staffMemberId ? String(l.staffMemberId) : '')).filter(Boolean))];
    const staffNameById = new Map<string, string>();
    if (lineStaffIds.length) {
      const rows = await this.prisma.staffMember
        .findMany({ where: { tenantId, id: { in: lineStaffIds } }, select: { id: true, firstName: true, lastName: true } })
        .catch(() => [] as Array<{ id: string; firstName: string; lastName: string | null }>);
      for (const r of rows) staffNameById.set(r.id, `${r.firstName} ${r.lastName ?? ''}`.trim());
    }
    const lineup = serviceLines.length
      ? [
          `${appt.service?.name ?? ''} — ${staffName}`,
          ...serviceLines.map((l) => {
            const who = l.staffMemberId ? staffNameById.get(String(l.staffMemberId)) : '';
            const nm = String(l.name ?? '');
            return who ? `${nm} — ${who}` : nm;
          }),
        ].filter(Boolean).join(' · ')
      : '';

    const pct: Record<string, string> = {
      salon_name: salon,
      customer_name: customerName,
      service_name: appt.service?.name ?? 'a service',
      staff_name: staffName,
      appointment_date: fmtD(start),
      appointment_time: `${fmtT(start)} – ${fmtT(end)}`,
      duration: `${durationMin} min`,
      total_price: total,
      add_ons: addonNames,
      salon_contact: contact,
      booking_id: appt.id,
      booking_ref: appt.id.slice(-6).toUpperCase(),
      customer_full_name: customerName,
      customer_phone: appt.customer?.phone ?? '',
      customer_email: appt.customer?.email ?? '',
      service_lineup: lineup,
      add_ons_only: addonOnlyNames,
      booking_notes: (appt.notes ?? '').trim().slice(0, 400),
      salon_address: ((await this.settings.getCompanyExtra(tenantId).catch(() => ({ address: '' } as { address?: string })))?.address ?? '').trim(),
      booking_source: '',
      manage_url: '',
    };

    const smtp =
      n.smtp.user && n.smtp.pass
        ? { host: n.smtp.host, port: n.smtp.port, user: n.smtp.user, pass: n.smtp.pass, secure: n.smtp.secure, replyTo: n.replyTo || undefined, from: `${n.senderName || salon} <${n.senderEmail || n.smtp.user}>` }
        : undefined;
    const brevo =
      n.brevo.apiKey && n.senderEmail
        ? { apiKey: n.brevo.apiKey, senderEmail: n.senderEmail, replyTo: n.replyTo || undefined, senderName: n.brevo.senderName || n.senderName || salon }
        : undefined;
    const gmail =
      n.gmail.clientId && n.gmail.clientSecret && n.gmail.refreshToken && n.gmail.senderEmail
        ? { clientId: n.gmail.clientId, clientSecret: n.gmail.clientSecret, refreshToken: n.gmail.refreshToken, senderEmail: n.gmail.senderEmail, senderName: n.senderName || salon, replyTo: n.replyTo || n.senderEmail || undefined }
        : undefined;

    const bodyFilled = fillPct(tpl.body, pct);
    const jobs: Promise<unknown>[] = [];
    if (wantEmail) {
      jobs.push(this.notifications.send({
        tenantId,
        channel: NotificationChannel.EMAIL,
        recipient: staffEmail as string,
        subject: fillPct(tpl.subject, pct),
        body: htmlToText(bodyFilled),
        html: renderTemplatedEmailHtml({ salon, accent, contact, bodyText: bodyFilled }),
        smtp,
        brevo,
        gmail,
        mailService: n.mailService,
        senderName: n.senderName || salon,
        replyTo: n.replyTo || n.senderEmail || undefined,
        relatedType: 'appointment',
        relatedId: appt.id,
      }));
    }
    // The tech is usually on the floor, not in an inbox. When the salon has
    // turned SMS on for this event, text them too.
    if (wantSms) {
      jobs.push(this.notifications.send({
        tenantId,
        channel: NotificationChannel.SMS,
        recipient: staffPhone,
        body: fillPct(tpl.smsBody, pct),
        twilio: n.twilio,
        relatedType: 'appointment',
        relatedId: appt.id,
      }));
    }
    await Promise.allSettled(jobs);
  }

  /** Active services for a tenant, with their active add-ons (public flow) —
   *  their own extras plus the shared ones their category / the whole menu
   *  offers ("Take Off $5"), so the booking page needs no idea of either. */
  async publicServices(tenantId: string) {
    const [rows, shared] = await Promise.all([
      this.publicServiceRows(tenantId),
      this.prisma.serviceAddon.findMany({
        where: { tenantId, isActive: true, serviceId: null } as never,
        select: { id: true, name: true, durationMinutes: true, priceCents: true, currency: true, categoryId: true, askAtBooking: true } as never,
        orderBy: { createdAt: 'asc' },
      }).catch(() => []) as Promise<unknown>,
    ]);
    const extras = shared as Array<{ id: string; name: string; durationMinutes: number; priceCents: number; currency: string; categoryId: string | null; askAtBooking?: boolean }>;
    // First come, first served: a walk-in-only line is not on the booking page.
    const bookable = rows.filter((s) => !(s as { walkInOnly?: boolean }).walkInOnly);
    if (!extras.length) return bookable;
    return bookable.map((s) => {
      const cat = (s as { categoryId?: string | null }).categoryId ?? null;
      const mine = extras.filter((a) => !a.categoryId || a.categoryId === cat).map(({ categoryId: _c, ...a }) => a);
      return mine.length ? { ...s, addons: [...(s.addons ?? []), ...mine] } : s;
    });
  }

  /** The menu lines the salon takes walk-in only (never an appointment) — the booking page says so. */
  async walkInOnlyServices(tenantId: string): Promise<{ id: string; name: string }[]> {
    try {
      return await this.prisma.service.findMany({ where: { tenantId, isActive: true, walkInOnly: true } as never, select: { id: true, name: true }, orderBy: { name: 'asc' } });
    } catch { return []; }
  }

  private publicServiceRows(tenantId: string): Promise<PublicServiceRow[]> {
    return this.prisma.service.findMany({
      where: { tenantId, isActive: true },
      select: {
        id: true,
        name: true,
        description: true,
        durationMinutes: true,
        priceCents: true,
        discountPercent: true,
        currency: true,
        categoryId: true,
        isFeatured: true,
        priceFrom: true,
        imageUrl: true,
        sortOrder: true,
        ...({ walkInOnly: true } as object),
        addons: {
          where: { isActive: true },
          select: { id: true, name: true, durationMinutes: true, priceCents: true, currency: true, ...({ askAtBooking: true } as object) },
          orderBy: { createdAt: 'asc' },
        },
      } as never,
      orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    }) as unknown as Promise<PublicServiceRow[]>;
  }

  /** Active menu categories for the public booking page (ordered). */
  publicCategories(tenantId: string) {
    return this.prisma.serviceCategory.findMany({
      where: { tenantId, isActive: true },
      select: { id: true, name: true, icon: true },
      orderBy: [{ sortOrder: 'asc' }, { createdAt: 'asc' }],
    });
  }

  /**
   * Availability for the public booking page: which technicians can do this
   * service, and each one's already-booked (blocking) time ranges around the
   * given date — so the UI can grey out slots a technician is already taken.
   */
  /**
   * Restaurant reservation availability: for a party of `partySize`, returns the
   * number of fitting tables and the busy intervals occupying them on the date.
   * The frontend generates candidate slots and marks a slot open when fewer than
   * `tableCount` fitting tables overlap it.
   */
  async publicTableAvailability(tenantId: string, dateStr: string, partySize: number, area?: string) {
    const size = Math.max(1, Math.min(50, Math.round(partySize || 1)));
    const tables = await this.prisma.restaurantTable.findMany({
      where: { tenantId, isActive: true, seats: { gte: size }, ...(area ? { area } : {}) },
      select: { id: true },
    });
    const svc = await this.prisma.service.findFirst({
      where: { tenantId, isActive: true },
      select: { durationMinutes: true },
      orderBy: { createdAt: 'asc' },
    });
    const durationMinutes = svc?.durationMinutes ?? 90;
    if (tables.length === 0) return { tableCount: 0, durationMinutes, busy: [] as { start: string; end: string }[] };
    const day = new Date(`${dateStr}T00:00:00`);
    const from = new Date(day.getTime() - 24 * 3_600_000);
    const to = new Date(day.getTime() + 48 * 3_600_000);
    const appts = await this.prisma.appointment.findMany({
      where: {
        tenantId,
        tableId: { in: tables.map((t: { id: string }) => t.id) },
        status: { notIn: [AppointmentStatus.CANCELLED, AppointmentStatus.NO_SHOW] },
        startTime: { lt: to },
        endTime: { gt: from },
      },
      select: { startTime: true, endTime: true },
    });
    return {
      tableCount: tables.length,
      durationMinutes,
      busy: appts.map((a: { startTime: Date; endTime: Date }) => ({ start: a.startTime.toISOString(), end: a.endTime.toISOString() })),
    };
  }

  /**
   * The start times still open on one day, for the till's "book the next
   * visit" sheet. With a technician: that tech's bookings and off-shift hours
   * are taken out. Without one: the salon's hours alone (the booking lands
   * PENDING and the desk assigns, exactly like a phone booking).
   */
  async openTimes(user: AuthenticatedUser, q: { date: string; staffId?: string; minutes?: number }) {
    const tenantId = this.tenantId(user);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(q.date || '')) throw new BadRequestException('date must be YYYY-MM-DD');
    const [rules, tenant] = await Promise.all([
      this.settings.getBookingRules(tenantId),
      this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }),
    ]);
    const tz = tenant?.timezone || 'UTC';
    const dayOfWeek = new Date(`${q.date}T12:00:00Z`).getUTCDay();
    const busy: BusyBlock[] = [];
    if (q.staffId) {
      const st = await this.prisma.staffMember.findFirst({
        where: { id: q.staffId, tenantId },
        select: { id: true, workingHours: { where: { isActive: true }, select: { dayOfWeek: true, startTime: true, endTime: true } } },
      });
      if (!st) throw new NotFoundException('Staff member not found');
      const dayStart = wallTimeToUtc(q.date, '00:00', tz);
      const dayEnd = new Date(dayStart.getTime() + 24 * 3_600_000);
      const appts = await this.prisma.appointment.findMany({
        where: { tenantId, assignedStaffId: st.id, status: { in: [...BLOCKING_STATUSES, AppointmentStatus.ARRIVED] }, startTime: { lt: dayEnd }, endTime: { gt: dayStart } },
        select: { startTime: true, endTime: true },
      });
      for (const a of appts) busy.push({ start: a.startTime, end: a.endTime });
      // Approved time off blocks the day the same way it does on the online page.
      for (const b of busySpansFor(await loadApprovedTimeOff(this.prisma, tenantId, q.date, q.date, [st.id]), st.id, q.date, tz)) busy.push(b);
      // Off-shift hours block the day the same way they do on the online page
      // (extra hours opened on the Calendar count as on shift — staff/extra-hours.ts).
      const hours = withExtraHours(st.workingHours ?? [], await loadExtraHours(this.prisma, tenantId, q.date, q.date, [st.id]), st.id, q.date);
      if (hours.length > 0) {
        const today = hours.filter((h) => h.dayOfWeek === dayOfWeek)
          .map((h) => ({ s: wallTimeToUtc(q.date, h.startTime, tz), e: wallTimeToUtc(q.date, h.endTime, tz) }))
          .filter((x) => x.e.getTime() > x.s.getTime())
          .sort((a, b) => a.s.getTime() - b.s.getTime());
        if (today.length === 0) busy.push({ start: dayStart, end: dayEnd });
        else {
          let cursor = dayStart;
          for (const sp of today) {
            if (sp.s.getTime() > cursor.getTime()) busy.push({ start: cursor, end: sp.s });
            if (sp.e.getTime() > cursor.getTime()) cursor = sp.e;
          }
          if (cursor.getTime() < dayEnd.getTime()) busy.push({ start: cursor, end: dayEnd });
        }
      }
    } else {
      // No technician: a whole-salon block still closes the time.
      for (const b of busySpansFor(await loadApprovedTimeOff(this.prisma, tenantId, q.date, q.date, []), null, q.date, tz)) busy.push(b);
    }
    const times = openTimesFor({
      dateStr: q.date, tz, day: rules.businessHours[dayOfWeek] ?? null,
      closedToday: (rules.daysOff ?? []).includes(q.date),
      stepMinutes: rules.slotStepMinutes, durationMinutes: q.minutes ?? 30, busy, now: new Date(),
    });
    return { tz, times: times.map((d) => d.toISOString()) };
  }

  async publicAvailability(tenantId: string, serviceId: string, dateStr: string) {
    // Skills are read PER TECHNICIAN: a tech who registered a skill list only
    // performs what is on it; a tech with no list configured performs anything.
    // (The old rule was per service — "nobody linked to this service, so anyone
    // can do it" — which let a tech with 12 registered skills be booked for a
    // 13th they never claimed.)
    const allStaff = await this.prisma.staffMember.findMany({
      where: { tenantId, isActive: true, takesAppointments: true },
      select: {
        id: true,
        staffServices: { select: { serviceId: true } },
        workingHours: {
          where: { isActive: true },
          select: { dayOfWeek: true, startTime: true, endTime: true },
        },
      },
    });
    // A service nobody lists is anybody's — the same rule the assignment engine
    // uses (assignment.util skilledFor), so what the page offers is what gets assigned.
    const eligible = skilledFor(allStaff, serviceId);
    const ids = eligible.map((s) => s.id);
    if (ids.length === 0) {
      // Two very different situations, and they used to look identical to the booking
      // page — which silently showed "no times left" on every single day:
      //
      //  · The salon has NO bookable technician at all (a brand-new shop, or a solo
      //    owner who never created a staff record). Bookings are still perfectly
      //    valid — they come in as PENDING and the salon assigns someone later. So
      //    every open slot must be offered. `noStaff` tells the form exactly that.
      //
      //  · The salon HAS technicians, but none of them is linked to this service.
      //    That is a setup mistake; the form says so instead of pretending the day
      //    is full.
      return {
        eligibleStaffIds: [],
        staffBusy: {} as Record<string, { start: string; end: string }[]>,
        salonBusy: await this.salonBlockSpans(tenantId, dateStr),
        noStaff: allStaff.length === 0,
        // The salon HAS technicians but none of them lists this service. The
        // menu still sells it, so "Any tech" stays bookable (the booking lands
        // PENDING and the front desk assigns by hand) — only a specific-tech
        // pick is refused. Blocking the customer entirely would turn a config
        // gap into lost revenue.
        unstaffed: allStaff.length > 0,
      };
    }

    // Wide window around the date so we catch the whole local day regardless of
    // timezone; the frontend does exact overlap by absolute time.
    const day = new Date(`${dateStr}T00:00:00`);
    const from = new Date(day.getTime() - 24 * 3_600_000);
    const to = new Date(day.getTime() + 48 * 3_600_000);

    const appts = await this.prisma.appointment.findMany({
      where: {
        tenantId,
        assignedStaffId: { in: ids },
        status: { in: BLOCKING_STATUSES },
        startTime: { lt: to },
        endTime: { gt: from },
      },
      select: { assignedStaffId: true, startTime: true, endTime: true },
    });

    const staffBusy: Record<string, { start: string; end: string }[]> = {};
    for (const id of ids) staffBusy[id] = [];
    // Each booking blocks its technician for its own time plus the salon's
    // rest gap on either side (bookings/buffer.ts), so what is offered keeps it.
    const gap = await this.bufferMinutes(tenantId);
    const busyOf = (s: Date, e: Date) => { const p = padSpan({ start: s, end: e }, gap); return { start: p.start.toISOString(), end: p.end.toISOString() }; };
    for (const a of appts) {
      if (a.assignedStaffId) {
        staffBusy[a.assignedStaffId].push(busyOf(a.startTime, a.endTime));
      }
    }
    // A technician on another visit's extra service line (a group) is busy then too.
    const withLines = await this.prisma.appointment.findMany({
      where: { tenantId, status: { in: BLOCKING_STATUSES }, startTime: { lt: to }, endTime: { gt: from } },
      select: { assignedStaffId: true, startTime: true, endTime: true, addons: true },
    }).catch(() => [] as { assignedStaffId: string | null; startTime: Date; endTime: Date; addons: unknown }[]);
    for (const a of withLines) {
      for (const sid of lineStaffIds(a.addons, a.assignedStaffId)) {
        if (staffBusy[sid]) staffBusy[sid].push(busyOf(a.startTime, a.endTime));
      }
    }

    // Per-technician shifts, expressed as BUSY blocks outside the shift. The
    // salon's own timezone anchors the day: a Saturday-only tech must block
    // Monday in Chicago even when the customer is browsing from Vietnam.
    const tz = (await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }))?.timezone || 'UTC';
    const dayStartUtc = wallTimeToUtc(dateStr, '00:00', tz);
    const dayEndUtc = new Date(dayStartUtc.getTime() + 24 * 3_600_000);
    const dayOfWeek = new Date(`${dateStr}T12:00:00Z`).getUTCDay();
    // Approved time off (nghỉ phép): the day, or the part of it, is busy.
    const leave = await loadApprovedTimeOff(this.prisma, tenantId, dateStr, dateStr, ids);
    const extra = await loadExtraHours(this.prisma, tenantId, dateStr, dateStr, ids);
    for (const st of eligible) {
      for (const b of busySpansFor(leave, st.id, dateStr, tz)) staffBusy[st.id].push({ start: b.start.toISOString(), end: b.end.toISOString() });
      const hours = withExtraHours(st.workingHours ?? [], extra, st.id, dateStr);
      if (hours.length === 0) continue; // unconfigured -> follows salon hours only
      const today = hours.filter((h) => h.dayOfWeek === dayOfWeek);
      if (today.length === 0) {
        // Has a schedule, but not on this day: the whole day is off.
        staffBusy[st.id].push({ start: dayStartUtc.toISOString(), end: dayEndUtc.toISOString() });
        continue;
      }
      // Block everything before the first shift, between shifts, after the last.
      const spans = today
        .map((h) => ({ s: wallTimeToUtc(dateStr, h.startTime, tz), e: wallTimeToUtc(dateStr, h.endTime, tz) }))
        .filter((x) => x.e.getTime() > x.s.getTime())
        .sort((a, b) => a.s.getTime() - b.s.getTime());
      if (spans.length === 0) {
        staffBusy[st.id].push({ start: dayStartUtc.toISOString(), end: dayEndUtc.toISOString() });
        continue;
      }
      let cursor = dayStartUtc;
      for (const sp of spans) {
        if (sp.s.getTime() > cursor.getTime()) {
          staffBusy[st.id].push({ start: cursor.toISOString(), end: sp.s.toISOString() });
        }
        if (sp.e.getTime() > cursor.getTime()) cursor = sp.e;
      }
      if (cursor.getTime() < dayEndUtc.getTime()) {
        staffBusy[st.id].push({ start: cursor.toISOString(), end: dayEndUtc.toISOString() });
      }
    }

    return { eligibleStaffIds: ids, staffBusy, salonBusy: busySpansFor(leave.filter((o) => o.staffId == null), null, dateStr, tz).map((b) => ({ start: b.start.toISOString(), end: b.end.toISOString() })) };
  }

  /** The whole-salon blocks on one salon day, as UTC spans (the booking page hides them for "any tech" too). */
  private async salonBlockSpans(tenantId: string, dateStr: string): Promise<{ start: string; end: string }[]> {
    try {
      const tz = (await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }))?.timezone || 'UTC';
      return busySpansFor(await loadApprovedTimeOff(this.prisma, tenantId, dateStr, dateStr, []), null, dateStr, tz)
        .map((b) => ({ start: b.start.toISOString(), end: b.end.toISOString() }));
    } catch { return []; }
  }

  /**
   * Active staff for a tenant, ordered FAIRLY for the booking page:
   *  1) Admin-pinned staff first (bookingPriority > 0, highest first).
   *  2) Everyone else by a WEIGHTED RANDOM shuffle — more reward points gives
   *     better odds of a top spot, but base weight + randomness guarantee every
   *     technician still gets a fair chance to appear first on each visit.
   * This rotates exposure so walk-in/"first choice" bookings spread across the
   * team, while still rewarding high performers and honoring admin priority.
   */
  async publicStaff(tenantId: string) {
    const staff = await this.prisma.staffMember.findMany({
      where: { tenantId, isActive: true, takesAppointments: true },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        avatarUrl: true,
        bookingPriority: true,
        rewardPoints: true,
        staffServices: { select: { serviceId: true } },
        // Which days this tech works — the booking page shows it as a hint
        // ("Sat only") next to the name so customers understand availability
        // before they even reach the time step.
        workingHours: { where: { isActive: true }, select: { dayOfWeek: true } },
      },
    });

    const pinned = staff.filter((s) => (s.bookingPriority ?? 0) > 0)
      .sort((a, b) => (b.bookingPriority ?? 0) - (a.bookingPriority ?? 0));

    // Weighted random: weight = 1 + capped points bonus (max ~4x). Each render
    // gives a fresh random key so the order rotates fairly per customer/visit.
    const auto = staff.filter((s) => (s.bookingPriority ?? 0) <= 0)
      .map((s) => {
        const weight = 1 + Math.min(s.rewardPoints ?? 0, 300) / 100; // 1x → 4x
        return { s, key: Math.random() * weight };
      })
      .sort((a, b) => b.key - a.key)
      .map((x) => x.s);

    // Strip the internal ordering fields before returning to the public.
    return [...pinned, ...auto].map(({ bookingPriority, rewardPoints, ...rest }) => rest);
  }

  async list(user: AuthenticatedUser, filters: ListBookingsDto) {
    const tenantId = this.tenantId(user);
    const where: Prisma.AppointmentWhereInput = { tenantId };
    if (filters.status) where.status = filters.status;
    if (filters.staffId) where.assignedStaffId = filters.staffId;
    if (filters.from || filters.to) {
      where.startTime = {};
      if (filters.from) where.startTime.gte = new Date(filters.from);
      if (filters.to) where.startTime.lte = new Date(filters.to);
    }
    return this.prisma.appointment.findMany({
      where,
      include: BOOKING_INCLUDE,
      orderBy: { startTime: 'asc' },
    });
  }

  async getById(user: AuthenticatedUser, id: string) {
    // A platform admin has no tenantId of their own; scoping by one would throw
    // "No tenant context" and the caller would see a 404 for a booking that
    // exists. Salon users stay pinned to their own tenant, as always.
    const scope = resolveTenantScope(user);
    const appointment = await this.prisma.appointment.findFirst({
      where: scope ? { id, tenantId: scope } : { id },
      include: BOOKING_INCLUDE,
    });
    if (!appointment) {
      throw new NotFoundException('Booking not found');
    }
    return appointment;
  }

  /** Assign (or re-assign) a booking to a staff member, race-safe. */
  async assign(user: AuthenticatedUser, id: string, staffId: string) {
    const tenantId = this.tenantId(user);
    const booking = await this.getById(user, id);
    await this.assertStaffActive(tenantId, staffId);

    const updated = await this.prisma.$transaction(async (tx) => {
      await this.lockStaffSlot(tx, tenantId, staffId);
      await this.assertNoOverlap(tx, tenantId, staffId, booking.startTime, booking.endTime, id);
      // Changing the tech on an already-confirmed/arrived visit must NOT restart
      // the accept/confirm workflow — keep the status, just swap the person.
      const keepStatus =
        booking.status === AppointmentStatus.CONFIRMED || booking.status === AppointmentStatus.ARRIVED;
      await tx.appointment.updateMany({
        where: { id, tenantId },
        data: {
          assignedStaffId: staffId,
          assignedAt: new Date(),
          rejectedAt: null,
          ...(keepStatus
            ? {}
            : { status: AppointmentStatus.ASSIGNED, responseDeadline: addMinutes(new Date(), 30) }),
        },
      });
      return tx.appointment.findFirst({ where: { id, tenantId }, include: BOOKING_INCLUDE });
    });

    await this.audit.log({
      tenantId,
      userId: user.userId,
      action: 'booking.assigned',
      resourceType: 'appointment',
      resourceId: id,
      metadata: { staffId },
    });

    await this.followOnFloor(tenantId, id, booking.assignedStaffId, staffId);
    // Notify the assigned technician (fire-and-forget).
    this.sendStaffAssignmentEmail(tenantId, id).catch(() => undefined);
    // The customer was told "to be assigned": now tell them who.
    if (!booking.assignedStaffId && updated) this.tellCustomerTech(tenantId, updated as never);

    return updated;
  }

  /** customer_staff_assigned, for an upcoming live booking that had nobody on it. Fire-and-forget. */
  private tellCustomerTech(tenantId: string, b: Parameters<BookingsService['sendBookingConfirmation']>[1] & { status?: string }) {
    const live = ['PENDING', 'ASSIGNED', 'ACCEPTED', 'CONFIRMED'].includes(String(b.status ?? ''));
    if (!live || b.startTime.getTime() < Date.now() || !b.assignedStaff) return;
    this.sendBookingConfirmation(tenantId, b, { techUpdate: true }).catch(() => undefined);
  }

  /**
   * The calendar's drag: a new start time and, optionally, a different
   * technician, in ONE transaction. Two calls (reschedule, then assign) could
   * leave the booking half-moved when the second one hits a clash; here the
   * target tech's calendar is locked and checked before anything changes.
   * Same rules as reschedule() (finished bookings stay put) and assign()
   * (a confirmed/arrived visit keeps its status).
   */
  async move(user: AuthenticatedUser, id: string, startTimeIso: string, staffId?: string | null, outsideHours = false) {
    const booking = await this.getById(user, id);
    if (!staffId || staffId === booking.assignedStaffId) return this.reschedule(user, id, startTimeIso, outsideHours);
    const tenantId = this.tenantId(user);
    const finalStates: AppointmentStatus[] = [
      AppointmentStatus.CANCELLED, AppointmentStatus.COMPLETED,
      AppointmentStatus.NO_SHOW, AppointmentStatus.REJECTED,
    ];
    if (finalStates.includes(booking.status)) {
      throw new BadRequestException('This booking is finished and can no longer be moved.');
    }
    const newStart = new Date(startTimeIso);
    if (Number.isNaN(newStart.getTime())) throw new BadRequestException('Invalid start time');
    await this.assertDeskHours(user, tenantId, booking.startTime, newStart, outsideHours);
    await this.assertStaffActive(tenantId, staffId);
    const newEnd = new Date(newStart.getTime() + (booking.endTime.getTime() - booking.startTime.getTime()));
    const keepStatus = booking.status === AppointmentStatus.CONFIRMED || booking.status === AppointmentStatus.ARRIVED;

    const updated = await this.prisma.$transaction(async (tx) => {
      await this.lockStaffSlot(tx, tenantId, staffId);
      await this.assertNoOverlap(tx, tenantId, staffId, newStart, newEnd, id);
      await tx.appointment.updateMany({
        where: { id, tenantId },
        data: {
          startTime: newStart,
          endTime: newEnd,
          assignedStaffId: staffId,
          assignedAt: new Date(),
          rejectedAt: null,
          ...(keepStatus ? {} : { status: AppointmentStatus.ASSIGNED, responseDeadline: addMinutes(new Date(), 30) }),
        },
      });
      return tx.appointment.findFirst({ where: { id, tenantId }, include: BOOKING_INCLUDE });
    });

    await this.audit.log({
      tenantId,
      userId: user.userId,
      action: 'booking.moved',
      resourceType: 'appointment',
      resourceId: id,
      metadata: { from: booking.startTime.toISOString(), to: newStart.toISOString(), fromStaffId: booking.assignedStaffId, staffId },
    });
    await this.followOnFloor(tenantId, id, booking.assignedStaffId, staffId);
    this.sendStaffAssignmentEmail(tenantId, id).catch(() => undefined);
    return updated;
  }

  /**
   * The desk's opening-hours rule for a MOVE (same as for a new booking, see
   * createForTenant): before opening or after closing is fine on an open day;
   * a closed day or a day off needs the owner, on purpose. Only a change of
   * time is checked. If the hours cannot be read, the move goes through.
   */
  private async assertDeskHours(user: AuthenticatedUser, tenantId: string, from: Date, to: Date, outsideHours: boolean): Promise<void> {
    if (from.getTime() === to.getTime()) return;
    const owner = user.role === 'SALON_ADMIN' || user.role === 'SUPER_ADMIN';
    if (owner && outsideHours) return;
    let read: { tz: string; rules: { businessHours?: unknown[]; daysOff?: string[] } } | null = null;
    try {
      const [t, rules] = await Promise.all([
        this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }),
        this.settings.getBookingRules(tenantId),
      ]);
      read = { tz: t?.timezone || 'UTC', rules: rules as never };
    } catch { return; }
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: read.tz, weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false,
      year: 'numeric', month: '2-digit', day: '2-digit',
    }).formatToParts(to);
    const g = (k: string) => parts.find((x) => x.type === k)?.value ?? '';
    const wd = g('weekday');
    const hh = Number(g('hour')) % 24; const mm = Number(g('minute'));
    const dateStr = `${g('year')}-${g('month')}-${g('day')}`;
    const at = `${wd} ${dateStr} ${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
    if ((read.rules.daysOff ?? []).includes(dateStr)) {
      throw new BadRequestException(`OUTSIDE_HOURS: ${dateStr} is marked as a day off. Pick another date (the owner can still move it there on purpose).`);
    }
    const dayIndex = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(wd);
    const day = dayIndex >= 0 ? (read.rules.businessHours ?? [])[dayIndex] as never : undefined;
    if (dayIndex < 0 || !Number.isFinite(hh) || !Number.isFinite(mm) || !Array.isArray(read.rules.businessHours)) return;
    if (!windowsForDay(day).length) {
      throw new BadRequestException(`OUTSIDE_HOURS: the salon is closed on ${wd} (${at}). Pick another day (the owner can still move it there on purpose).`);
    }
  }

  /** Move a booking to a new date & time (admin reschedule). Duration and
   *  status are preserved; the assigned technician's calendar is re-checked
   *  race-safely so the move can never create a double booking. */
  async reschedule(user: AuthenticatedUser, id: string, startTimeIso: string, outsideHours = false) {
    const tenantId = this.tenantId(user);
    const booking = await this.getById(user, id);
    const finalStates: AppointmentStatus[] = [
      AppointmentStatus.CANCELLED, AppointmentStatus.COMPLETED,
      AppointmentStatus.NO_SHOW, AppointmentStatus.REJECTED,
    ];
    if (finalStates.includes(booking.status)) {
      throw new BadRequestException('This booking is finished and can no longer be rescheduled.');
    }
    const newStart = new Date(startTimeIso);
    if (Number.isNaN(newStart.getTime())) throw new BadRequestException('Invalid start time');
    await this.assertDeskHours(user, tenantId, booking.startTime, newStart, outsideHours);
    const durationMs = booking.endTime.getTime() - booking.startTime.getTime();
    const newEnd = new Date(newStart.getTime() + durationMs);
    const staffId = booking.assignedStaffId;

    const updated = await this.prisma.$transaction(async (tx) => {
      if (staffId) {
        await this.lockStaffSlot(tx, tenantId, staffId);
        await this.assertNoOverlap(tx, tenantId, staffId, newStart, newEnd, id);
      } else {
        await this.assertNotOff(tx, tenantId, null, newStart, newEnd);
      }
      await tx.appointment.updateMany({
        where: { id, tenantId },
        data: { startTime: newStart, endTime: newEnd },
      });
      return tx.appointment.findFirst({ where: { id, tenantId }, include: BOOKING_INCLUDE });
    });

    await this.audit.log({
      tenantId,
      userId: user.userId,
      action: 'booking.rescheduled',
      resourceType: 'appointment',
      resourceId: id,
      metadata: { from: booking.startTime.toISOString(), to: newStart.toISOString() },
    });
    // The customer's written record must match the calendar; the technician's
    // day just changed. The "rescheduled" template, not the confirmation.
    this.sendChangeNotice(tenantId, id, 'rescheduled', { by: 'staff', from: booking.startTime }).catch(() => undefined);

    return updated;
  }

  /**
   * Restaurant: move a reservation to a different table (host re-seating). Scoped
   * to the tenant, and blocked if the target table already has an overlapping
   * reservation, so a table is never double-booked.
   */
  // ------------------------------------------------------------ no-show policy

  async noShowPolicyFor(tenantId: string): Promise<NoShowPolicy> {
    try {
      const row = await this.prisma.setting.findUnique({ where: { tenantId_key: { tenantId, key: NO_SHOW_POLICY_KEY } } });
      return cleanNoShowPolicy(row?.value ?? {});
    } catch { return cleanNoShowPolicy({}); }
  }

  getNoShowPolicy(user: AuthenticatedUser) {
    return this.noShowPolicyFor(this.tenantId(user));
  }

  async updateNoShowPolicy(user: AuthenticatedUser, dto: Partial<NoShowPolicy>) {
    const tenantId = this.tenantId(user);
    const next = cleanNoShowPolicy(dto, await this.noShowPolicyFor(tenantId));
    await this.prisma.setting.upsert({
      where: { tenantId_key: { tenantId, key: NO_SHOW_POLICY_KEY } },
      update: { value: next as never }, create: { tenantId, key: NO_SHOW_POLICY_KEY, value: next as never },
    });
    await this.audit.log({ tenantId, userId: user.userId, action: 'settings.no_show_policy_updated', resourceType: 'tenant', resourceId: tenantId, metadata: { ...next } });
    return next;
  }

  /** This salon's customers with this number, however it was typed (last 9 digits). */
  private async customerIdsByPhone(tenantId: string, raw: string): Promise<string[]> {
    const digits = raw.replace(/\D/g, '');
    if (digits.length < 7) return [];
    const tail = digits.slice(-9);
    const rows = await this.prisma.customer.findMany({ where: { tenantId, phone: { contains: digits.slice(-7) } }, select: { id: true, phone: true }, take: 20 });
    return rows.filter((r) => (r.phone ?? '').replace(/\D/g, '').endsWith(tail)).map((r) => r.id);
  }

  private async noShowCount(tenantId: string, customerIds: string[], policy: NoShowPolicy, now = new Date()): Promise<number> {
    if (!customerIds.length) return 0;
    return this.prisma.appointment.count({
      where: { tenantId, customerId: { in: customerIds }, status: AppointmentStatus.NO_SHOW, startTime: { gte: windowStart(policy, now) } },
    });
  }

  /** For the desk while booking: how often this client didn't come, and whether to warn. */
  async noShowCheck(user: AuthenticatedUser, q: { phone?: string; customerId?: string }) {
    const tenantId = this.tenantId(user);
    const policy = await this.noShowPolicyFor(tenantId);
    let ids: string[] = [];
    if (q.customerId) {
      const c = await this.prisma.customer.findFirst({ where: { id: q.customerId, tenantId }, select: { id: true } });
      if (c) ids = [c.id];
    } else if (q.phone) {
      ids = await this.customerIdsByPhone(tenantId, q.phone);
    }
    const count = await this.noShowCount(tenantId, ids, policy);
    return { count, months: policy.months, ...noShowVerdict(count, policy) };
  }

  private async assertNoShowPolicy(tenantId: string, phone: string): Promise<void> {
    const policy = await this.noShowPolicyFor(tenantId);
    if (policy.blockOnlineAt === null) return;
    const count = await this.noShowCount(tenantId, await this.customerIdsByPhone(tenantId, phone), policy);
    if (noShowVerdict(count, policy).blockOnline) throw new BadRequestException(NO_SHOW_BLOCK_MESSAGE);
  }

  async assignTable(user: AuthenticatedUser, id: string, tableId: string) {
    const tenantId = this.tenantId(user);
    const booking = await this.getById(user, id);
    const table = await this.prisma.restaurantTable.findFirst({ where: { id: tableId, tenantId }, select: { id: true } });
    if (!table) throw new NotFoundException('Table not found');
    const updated = await this.prisma.$transaction(async (tx) => {
      const clash = await tx.appointment.findFirst({
        where: {
          tenantId, tableId, id: { not: id },
          status: { notIn: [AppointmentStatus.CANCELLED, AppointmentStatus.NO_SHOW] },
          startTime: { lt: booking.endTime },
          endTime: { gt: booking.startTime },
        },
        select: { id: true },
      });
      if (clash) throw new ConflictException('That table is already booked for this time');
      await tx.appointment.updateMany({ where: { id, tenantId }, data: { tableId } });
      return tx.appointment.findFirst({ where: { id, tenantId }, include: BOOKING_INCLUDE });
    });
    await this.audit.log({ tenantId, userId: user.userId, action: 'booking.table_assigned', resourceType: 'appointment', resourceId: id, metadata: { tableId } });
    return updated;
  }

  /** Status transitions that don't need slot locking. */
  private async transition(
    user: AuthenticatedUser,
    id: string,
    status: AppointmentStatus,
    action: string,
    timestampField: keyof Prisma.AppointmentUpdateInput,
  ) {
    const tenantId = this.tenantId(user);
    await this.getById(user, id);
    await this.prisma.appointment.updateMany({
      where: { id, tenantId },
      data: { status, [timestampField]: new Date() },
    });
    await this.audit.log({
      tenantId,
      userId: user.userId,
      action,
      resourceType: 'appointment',
      resourceId: id,
    });
    return this.getById(user, id);
  }

  /**
   * Cancel a booking AND settle its money so it never inflates revenue:
   *  - already-collected (PAID) -> REFUNDED (drops out of revenue)
   *  - not-yet-collected (PENDING) -> FAILED (voided, can't be marked paid)
   * (No-show keeps its money — that path uses noShow(), not cancel().)
   */

  /** The human-readable name of the acting user, for "cancelled by" stamps. */
  private async actorName(userId: string | null): Promise<string | null> {
    if (!userId) return null;
    const u = await this.prisma.user.findUnique({ where: { id: userId }, select: { firstName: true, lastName: true, email: true } }).catch(() => null);
    if (!u) return null;
    return [u.firstName, u.lastName].filter(Boolean).join(' ').trim() || u.email || null;
  }

  async cancel(user: AuthenticatedUser, id: string, money?: MoneyChoice | null) {
    const tenantId = this.tenantId(user);
    await this.getById(user, id); // enforces tenant ownership / 404
    return this.cancelForTenant(tenantId, id, user.userId, 'staff', await this.actorName(user.userId), money === 'refund' || money === 'keep' ? money : null);
  }

  /** Cancel + settle money, scoped to a tenant (admin or token-based customer cancel). */
  async cancelForTenant(tenantId: string, id: string, actorUserId: string | null, by: 'staff' | 'customer' | 'ai' | 'system' = 'customer', byName: string | null = null, money: MoneyChoice | null = null) {
    // Cancelling twice must not tell everyone twice — nor refund twice.
    const before = await this.prisma.appointment.findFirst({ where: { id, tenantId }, select: { status: true, startTime: true, priceCents: true, customerId: true, partySize: true } as never }).catch(() => null) as
      { status: AppointmentStatus; startTime: Date; priceCents: number; customerId: string | null; partySize?: number | null } | null;
    await this.prisma.$transaction(async (tx) => {
      await tx.appointment.updateMany({
        where: { id, tenantId },
        data: { status: AppointmentStatus.CANCELLED, cancelledAt: new Date(), cancelledBy: by, cancelledByName: byName } as never,
      });
      // Nothing taken yet: the open "pay at the salon" / "pay now" rows close.
      await tx.payment.updateMany({
        where: { tenantId, appointmentId: id, status: PaymentStatus.PENDING },
        data: { status: PaymentStatus.FAILED },
      });
    });
    await this.audit.log({ tenantId, userId: actorUserId, action: 'booking.cancelled', resourceType: 'appointment', resourceId: id });
    // Money already taken follows the salon's rule (deposit-policy.ts): in
    // time → back to the card for real; late → the deposit stays with the salon.
    let moneyOut: { keptCents: number; refundedCents: number; failed: { provider: string; amountCents: number; error: string }[] } | null = null;
    if (before && before.status !== AppointmentStatus.CANCELLED) {
      moneyOut = await this.settleCancelledMoney(tenantId, id, before, by === 'staff' ? money : null).catch((e) => {
        this.logger.warn(`cancel money ${id}: ${String((e as Error)?.message ?? e).slice(0, 200)}`);
        return null;
      });
      this.sendChangeNotice(tenantId, id, 'cancelled', { by, byName }).catch(() => undefined);
    }
    const row = await this.prisma.appointment.findFirst({ where: { id, tenantId }, include: BOOKING_INCLUDE });
    return row && moneyOut ? Object.assign(row, { cancelMoney: moneyOut }) : row;
  }

  /** The money side of a cancellation: refund in time, keep the deposit when late (or when staff say so). */
  private async settleCancelledMoney(
    tenantId: string, id: string,
    appt: { startTime: Date; priceCents: number; customerId: string | null; partySize?: number | null },
    override: MoneyChoice | null,
  ) {
    const paid = await this.prisma.payment.findMany({ where: { tenantId, appointmentId: id, status: PaymentStatus.PAID }, select: { amountCents: true } });
    const paidCents = paid.reduce((s, p) => s + p.amountCents, 0);
    if (paidCents <= 0) return { keptCents: 0, refundedCents: 0, failed: [] };
    const dep = await this.settings.getDepositSettings(tenantId);
    const depositCents = dep.enabled
      ? await this.payments.depositFor(tenantId, { customerId: appt.customerId, priceCents: appt.priceCents, partySize: appt.partySize ?? null }, dep, await this.settings.getPartyDeposit(tenantId))
      : 0;
    const plan = cancelMoney({ startMs: appt.startTime.getTime(), nowMs: Date.now(), refundHours: dep.refundHours ?? DEFAULT_REFUND_HOURS, paidCents, depositCents, override });
    const res = plan.refundCents > 0 ? await this.payments.refundPaid(tenantId, id, plan.refundCents) : { refundedCents: 0, failed: [] };
    if (plan.keepCents > 0) {
      await this.audit.log({ tenantId, userId: null, action: 'payment.deposit_kept', resourceType: 'appointment', resourceId: id, metadata: { keptCents: plan.keepCents, reason: plan.reason } });
    }
    return { keptCents: plan.keepCents, refundedCents: res.refundedCents, failed: res.failed };
  }

  /**
   * Tell the people a cancellation or a move concerns: the customer (their
   * written record must match the calendar), the technician (a cancellation
   * frees their chair; a move changes their day) and the owner's phone. Which
   * template and channel is decided in ./change-notices; the templates are
   * the salon's own, from Settings → Notifications. Fire-and-forget.
   */
  private async sendChangeNotice(
    tenantId: string,
    appointmentId: string,
    kind: 'cancelled' | 'rescheduled',
    ctx: { by?: 'staff' | 'customer' | 'ai' | 'system' | null; byName?: string | null; from?: Date | null } = {},
  ) {
    const appt = await this.prisma.appointment.findFirst({
      where: { id: appointmentId, tenantId },
      select: {
        id: true, startTime: true, endTime: true, priceCents: true, currency: true, addons: true, notes: true, source: true,
        customer: { select: { firstName: true, lastName: true, email: true, phone: true } },
        service: { select: { name: true } },
        assignedStaff: { select: { id: true, firstName: true, lastName: true, email: true, phone: true, userId: true, user: { select: { email: true } } } },
      } as never,
    }).catch(() => null) as unknown as {
      id: string; startTime: Date; endTime: Date; priceCents: number; currency: string; addons: unknown; notes: string | null; source: string | null;
      customer: { firstName: string; lastName: string | null; email: string | null; phone: string | null } | null;
      service: { name: string } | null;
      assignedStaff: { id: string; firstName: string; lastName: string | null; email: string | null; phone: string | null; userId: string | null; user: { email: string | null } | null } | null;
    } | null;
    if (!appt) return;

    const [n, tenant, templates] = await Promise.all([
      this.settings.getNotificationSettings(tenantId),
      this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { name: true, contactEmail: true, contactPhone: true, branding: true, timezone: true } }),
      this.settings.getNotificationTemplates(tenantId),
    ]);
    const tz = tenant?.timezone || 'America/New_York';
    const loc = await this.customerLocale(tenantId, tenant?.timezone);
    const vi = loc.toLowerCase().startsWith('vi');
    const fmtT = (dd: Date) => dd.toLocaleTimeString(loc, { hour: 'numeric', minute: '2-digit', timeZone: tz });
    const fmtD = (dd: Date) => dd.toLocaleDateString(loc, { weekday: 'short', month: 'long', day: 'numeric', year: 'numeric', timeZone: tz });
    const fmtShort = (dd: Date) => `${dd.toLocaleDateString(loc, { weekday: 'short', month: 'numeric', day: 'numeric', timeZone: tz })} ${fmtT(dd)}`;
    const salon = tenant?.name ?? 'Our salon';
    const staffName = appt.assignedStaff ? `${appt.assignedStaff.firstName} ${appt.assignedStaff.lastName ?? ''}`.trim() : '';
    const custFull = `${appt.customer?.firstName ?? ''} ${appt.customer?.lastName ?? ''}`.trim();
    const lineItems: Array<Record<string, unknown>> = Array.isArray(appt.addons) ? (appt.addons as Array<Record<string, unknown>>).filter(Boolean) : [];
    const extra = await this.settings.getCompanyExtra(tenantId).catch(() => ({ address: '' } as { address?: string }));
    const pct: Record<string, string> = {
      salon_name: salon,
      customer_name: appt.customer?.firstName ?? (vi ? 'bạn' : 'there'),
      customer_full_name: custFull || (vi ? 'Khách' : 'A customer'),
      customer_phone: appt.customer?.phone ?? '',
      customer_email: appt.customer?.email ?? '',
      service_name: appt.service?.name ?? (vi ? 'lịch hẹn' : 'your appointment'),
      staff_name: staffName || (vi ? 'Tiệm sẽ sắp xếp' : 'To be assigned'),
      appointment_date: fmtD(appt.startTime),
      appointment_time: `${fmtT(appt.startTime)} – ${fmtT(appt.endTime)}`,
      old_date: ctx.from ? fmtD(ctx.from) : '',
      old_time: ctx.from ? fmtT(ctx.from) : '',
      duration: `${Math.round((appt.endTime.getTime() - appt.startTime.getTime()) / 60_000)} ${vi ? 'phút' : 'min'}`,
      total_price: formatMoney(appt.priceCents, appt.currency, loc),
      add_ons: lineItems.map((a) => a.name).filter(Boolean).join(', '),
      add_ons_only: lineItems.filter((l) => l.kind !== 'service').map((a) => a.name).filter(Boolean).join(', '),
      service_lineup: '',
      salon_contact: tenant?.contactEmail ?? tenant?.contactPhone ?? '',
      salon_address: (extra?.address ?? '').trim(),
      booking_id: appt.id,
      booking_ref: appt.id.slice(-6).toUpperCase(),
      booking_notes: (appt.notes ?? '').trim().slice(0, 400),
      booking_source: '',
      manage_url: kind === 'rescheduled' ? this.buildApptManageUrl(appt.id) : '',
    };
    const custTpl = templates[kind === 'cancelled' ? 'customer_booking_cancelled' : 'customer_booking_rescheduled'];
    const staffTpl = templates['staff_booking_cancelled'];
    const staffEmail = appt.assignedStaff ? (appt.assignedStaff.email || appt.assignedStaff.user?.email || null) : null;
    // The salon's own alert goes where its new-booking alert goes, under the
    // same two switches — the owner who asked to be emailed about bookings is
    // emailed about their cancellation too.
    const adminTo = await this.ownerAlertEmail(tenantId, [n.adminEmail, n.senderEmail, n.gmail.senderEmail, tenant?.contactEmail]);
    const targets = changeNoticeTargets({
      kind, market: n.market ?? 'US',
      customer: { email: appt.customer?.email ?? null, phone: appt.customer?.phone ?? null },
      customerTpl: custTpl ? { enabled: custTpl.enabled, email: custTpl.email, sms: custTpl.sms } : null,
      staff: appt.assignedStaff ? { email: staffEmail, phone: appt.assignedStaff.phone ?? null } : null,
      staffTpl: staffTpl ? { enabled: staffTpl.enabled, email: staffTpl.email, sms: staffTpl.sms } : null,
      owner: { email: adminTo || null, phone: n.adminPhone || null, emailOn: !!n.emailAdminOnBooking, smsOn: !!n.smsAdminOnBooking },
    });
    const ownerText = ownerNoticeText({
      kind, vi, salon, customer: custFull || pct.customer_name, phone: pct.customer_phone, service: pct.service_name,
      staff: pct.staff_name, when: fmtShort(appt.startTime), from: ctx.from ? fmtShort(ctx.from) : undefined, by: ctx.by ?? null, byName: ctx.byName ?? null,
    });

    const smtp = n.smtp.user && n.smtp.pass
      ? { host: n.smtp.host, port: n.smtp.port, user: n.smtp.user, pass: n.smtp.pass, secure: n.smtp.secure, replyTo: n.replyTo || undefined, from: `${n.senderName || salon} <${n.senderEmail || n.smtp.user}>` }
      : undefined;
    const brevo = n.brevo.apiKey && n.senderEmail
      ? { apiKey: n.brevo.apiKey, senderEmail: n.senderEmail, replyTo: n.replyTo || undefined, senderName: n.brevo.senderName || n.senderName || salon }
      : undefined;
    const senderName = n.senderName || salon;
    const replyTo = n.replyTo || n.senderEmail || undefined;
    const gmail = n.gmail.clientId && n.gmail.clientSecret && n.gmail.refreshToken && n.gmail.senderEmail
      ? { clientId: n.gmail.clientId, clientSecret: n.gmail.clientSecret, refreshToken: n.gmail.refreshToken, senderEmail: n.gmail.senderEmail, senderName, replyTo }
      : undefined;
    const accent = this.settings.brandingFrom(tenant?.branding).accentColor;
    const related = { relatedType: 'appointment', relatedId: appt.id };

    const jobs: Promise<unknown>[] = [];
    for (const t of targets) {
      if (t.to === 'owner') {
        if (t.channel === 'email') {
          const bodyHtml = ownerText.body.split('\n').map((l) => (l ? `<p style="margin:0 0 6px">${l}</p>` : '<br>')).join('');
          jobs.push(this.notifications.send({
            tenantId, channel: NotificationChannel.EMAIL, recipient: t.recipient,
            subject: ownerText.subject, body: ownerText.body,
            html: renderTemplatedEmailHtml({ salon, accent, contact: pct.salon_contact, bodyText: bodyHtml }),
            smtp, brevo, gmail, mailService: n.mailService, senderName, replyTo, ...related,
          }));
        } else {
          jobs.push(this.notifications.send({ tenantId, channel: NotificationChannel.SMS, recipient: t.recipient, body: ownerText.sms, twilio: n.twilio, ...related }));
        }
        continue;
      }
      const tpl = t.to === 'customer' ? custTpl! : staffTpl!;
      if (t.channel === 'email') {
        const bodyFilled = fillPct(tpl.body, pct) + (t.to === 'customer' && kind === 'rescheduled'
          ? `<p style="margin:16px 0 0"><a href="${pct.manage_url}" style="color:${accent};font-weight:600">${vi ? 'Xem hoặc đổi lịch hẹn →' : 'View or change your appointment →'}</a></p>` : '');
        jobs.push(this.notifications.send({
          tenantId, channel: NotificationChannel.EMAIL, recipient: t.recipient,
          subject: fillPct(tpl.subject, pct),
          body: htmlToText(bodyFilled),
          html: renderTemplatedEmailHtml({ salon, accent, contact: pct.salon_contact, bodyText: bodyFilled }),
          smtp, brevo, gmail, mailService: n.mailService, senderName, replyTo, ...related,
        }));
      } else {
        const smsPct = pct.manage_url ? { ...pct, manage_url: this.buildApptSmsUrl(appt.id) } : pct;
        jobs.push(this.notifications.send({ tenantId, channel: NotificationChannel.SMS, recipient: t.recipient, body: fillPct(tpl.smsBody, smsPct), twilio: n.twilio, ...related }));
      }
    }

    // The owner's phone, and the technician's: a cancellation frees a chair, a
    // move changes a day. Both best-effort; no-ops unless push is set up.
    const push = changePushText({
      kind, vi, customer: custFull || pct.customer_name, service: pct.service_name,
      when: fmtShort(appt.startTime), from: ctx.from ? fmtShort(ctx.from) : undefined, by: ctx.by ?? null, byName: ctx.byName ?? null,
    });
    this.push.sendToTenant(tenantId, { ...push, url: '/salon/calendar' }).catch(() => undefined);
    if (appt.assignedStaff?.userId) {
      this.push.sendToUser(tenantId, appt.assignedStaff.userId, { ...push, url: '/staff/today' }).catch(() => undefined);
    }
    await Promise.allSettled(jobs);
  }

  // ---- Customer self-service via signed reminder links (no login) ----------

  /**
   * Which locale this salon's messages to ITS customers are written in.
   *
   * A confirmation text is read by the customer, so it follows the salon's
   * country, exactly as the booking page does. Anything unset answers en-US,
   * which is what every salon running today already sends.
   */
  private async customerLocale(tenantId: string, timezone?: string | null): Promise<string> {
    try {
      const extra = await this.prisma.setting.findFirst({
        where: { tenantId, key: 'company_extra' }, select: { value: true },
      });
      return localeForCountry((extra?.value as { country?: string } | null)?.country ?? '', timezone);
    } catch {
      return 'en-US';
    }
  }

  private apptToken(appointmentId: string): string {
    const payload = Buffer.from(JSON.stringify({ a: appointmentId, exp: Date.now() + 30 * 86400 * 1000 })).toString('base64url');
    const sig = createHmac('sha256', signingSecret()).update(payload).digest('base64url');
    return `${payload}.${sig}`;
  }

  /** Public signed self-service URL for an appointment (view / confirm / cancel,
   *  no login). Used by confirmations and the Messenger bot. */
  buildApptManageUrl(appointmentId: string): string {
    return `${publicWebBase()}/appt/${this.apptToken(appointmentId)}`;
  }

  /**
   * The SMS-sized form of the same link: lumiobooking.com/a/<33 chars>
   * instead of /appt/<~180 chars>. A text is billed per 153 characters, and
   * the long token alone was more than one of them.
   *
   * 22 chars = the appointment uuid packed into 16 bytes; 11 chars = the first
   * 8 bytes of an HMAC over it, under the same signing secret as the long
   * token (and a different label, so neither can be turned into the other).
   * Nothing is stored: it is verified exactly like the long one. It carries no
   * date of its own — it stops working 30 days after the appointment instead
   * (shortLinkExpired), which is longer than any reminder needs.
   * Null for an id that is not a uuid; the caller then uses the long link.
   */
  private apptShortCode(appointmentId: string): string | null {
    const hex = String(appointmentId ?? '').replace(/-/g, '').toLowerCase();
    if (!/^[0-9a-f]{32}$/.test(hex)) return null;
    return Buffer.from(hex, 'hex').toString('base64url') + this.apptShortSig(hex);
  }

  private apptShortSig(hex: string): string {
    return createHmac('sha256', signingSecret()).update(`appt-sms:${hex}`).digest().subarray(0, 8).toString('base64url');
  }

  /** The short self-service link, for SMS. Emails and Messenger keep the long one. */
  buildApptSmsUrl(appointmentId: string): string {
    const code = this.apptShortCode(appointmentId);
    return code ? `${publicWebBase()}/a/${code}` : this.buildApptManageUrl(appointmentId);
  }

  private static isShortApptCode(token: string): boolean {
    return /^[A-Za-z0-9_-]{33}$/.test(token || '');
  }

  private verifyApptShortCode(code: string): string | null {
    if (!BookingsService.isShortApptCode(code)) return null;
    const idPart = code.slice(0, 22);
    const buf = Buffer.from(idPart, 'base64url');
    // Re-encode and compare: base64 decoding forgives stray bits, the check must not.
    if (buf.length !== 16 || buf.toString('base64url') !== idPart) return null;
    const hex = buf.toString('hex');
    const want = Buffer.from(this.apptShortSig(hex));
    const got = Buffer.from(code.slice(22));
    if (want.length !== got.length || !timingSafeEqual(want, got)) return null;
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }

  /** A short link is good until 30 days after the visit (the long one carries its own date). */
  private static shortLinkExpired(token: string, startTime: Date | null | undefined): boolean {
    if (!BookingsService.isShortApptCode(token) || !startTime) return false;
    return Date.now() > new Date(startTime).getTime() + 30 * 86400 * 1000;
  }

  private verifyApptToken(token: string): string | null {
    if (BookingsService.isShortApptCode(token)) return this.verifyApptShortCode(token);
    const [payload, sig] = (token || '').split('.');
    if (!payload || !sig) return null;
    const expect = createHmac('sha256', signingSecret()).update(payload).digest('base64url');
    if (sig !== expect) return null;
    try {
      const d = JSON.parse(Buffer.from(payload, 'base64url').toString()) as { a: string; exp: number };
      if (!d.exp || Date.now() > d.exp) return null;
      return d.a;
    } catch {
      return null;
    }
  }

  private static readonly ACTIONABLE: AppointmentStatus[] = [AppointmentStatus.PENDING, AppointmentStatus.ASSIGNED, AppointmentStatus.ACCEPTED, AppointmentStatus.CONFIRMED];

  /** Appointment summary for the customer self-service page (token-authenticated). */
  async apptSummaryByToken(token: string) {
    const id = this.verifyApptToken(token);
    if (!id) throw new NotFoundException('This link has expired or is invalid.');
    const a = await this.prisma.appointment.findUnique({
      where: { id },
      include: { service: { select: { name: true } }, tenant: { select: { name: true, slug: true, timezone: true, branding: true } }, customer: { select: { id: true, firstName: true } } },
    });
    if (!a) throw new NotFoundException('Appointment not found');
    if (BookingsService.shortLinkExpired(token, a.startTime)) throw new NotFoundException('This link has expired or is invalid.');
    const tz = a.tenant?.timezone || 'America/New_York';
    const loc = await this.customerLocale(a.tenantId, a.tenant?.timezone);
    // Referral: when the program is on, surface THIS customer's own share link so
    // they can invite friends straight from their appointment page. Purely a
    // bonus — never let it break the page.
    let referral: { link: string; message: string; referrerPoints: number; refereePoints: number } | null = null;
    try {
      if (a.customer?.id) {
        const s = await this.referral.getForTenant(a.tenantId);
        if (s.enabled) {
          const l = await this.referral.ensureLinkForCustomer(a.tenantId, a.customer.id);
          if (l) referral = { link: l.link, message: s.message, referrerPoints: s.referrerPoints, refereePoints: s.refereePoints };
        }
      }
    } catch { /* ignore — referral is optional */ }
    return {
      salon: a.tenant?.name ?? 'Our salon',
      slug: a.tenant?.slug ?? '',
      service: a.service?.name ?? 'your appointment',
      customer: a.customer?.firstName ?? 'there',
      date: a.startTime.toLocaleDateString(loc, { weekday: 'long', month: 'long', day: 'numeric', timeZone: tz }),
      time: a.startTime.toLocaleTimeString(loc, { hour: 'numeric', minute: '2-digit', timeZone: tz }),
      status: a.status,
      confirmed: !!a.customerConfirmedAt,
      canAct: BookingsService.ACTIONABLE.includes(a.status),
      referral,
      deposit: await this.depositNotice(a.tenantId, a.id, a.startTime, loc, tz),
    };
  }

  /** For the customer page: what is paid, and until when cancelling gets it back. */
  private async depositNotice(tenantId: string, id: string, startTime: Date, loc: string, tz: string) {
    try {
      const paid = await this.prisma.payment.findMany({ where: { tenantId, appointmentId: id, status: PaymentStatus.PAID }, select: { amountCents: true, currency: true } });
      const paidCents = paid.reduce((s, p) => s + p.amountCents, 0);
      if (paidCents <= 0) return null;
      const dep = await this.settings.getDepositSettings(tenantId);
      const hours = dep.refundHours ?? DEFAULT_REFUND_HOURS;
      const deadline = new Date(refundDeadline(startTime.getTime(), hours));
      return {
        paidCents, currency: paid[0]?.currency ?? 'USD', refundHours: hours,
        refundable: refundable(startTime.getTime(), Date.now(), hours),
        deadline: `${deadline.toLocaleDateString(loc, { weekday: 'short', month: 'short', day: 'numeric', timeZone: tz })} ${deadline.toLocaleTimeString(loc, { hour: 'numeric', minute: '2-digit', timeZone: tz })}`,
      };
    } catch {
      return null;
    }
  }

  /**
   * A booking the salon made itself is confirmed on the spot (see deskConfirm).
   * Only a still-open PENDING / ASSIGNED booking moves; with staffMustAccept
   * on, a booking that has a technician waits for that technician's accept.
   * Returns the updated booking, or null when nothing changed.
   *
   * `customer: true` — a booking a CUSTOMER made (autoConfirm). Same rules,
   * plus the salon's switch: off → nothing moves. The salon confirms it, so
   * customerConfirmedAt stays empty and her reminder still asks her to confirm.
   */
  private async confirmDeskBooking(tenantId: string, b: { id: string; status: AppointmentStatus; assignedStaffId: string | null }, opt?: { customer?: boolean }) {
    if (b.status !== AppointmentStatus.PENDING && b.status !== AppointmentStatus.ASSIGNED) return null;
    if (b.assignedStaffId || opt?.customer) {
      const rules = await this.settings.getBookingRules(tenantId).catch(() => null);
      if (!shouldConfirmOnCreate({ customer: !!opt?.customer, status: b.status, hasStaff: !!b.assignedStaffId, rules })) return null;
    }
    const now = new Date();
    const r = await this.prisma.appointment.updateMany({
      where: { id: b.id, tenantId, status: { in: [AppointmentStatus.PENDING, AppointmentStatus.ASSIGNED] } },
      data: { status: AppointmentStatus.CONFIRMED, confirmedAt: now, ...(opt?.customer ? {} : { customerConfirmedAt: now }), responseDeadline: null },
    });
    if (!r.count) return null;
    return this.prisma.appointment.findFirst({ where: { id: b.id, tenantId }, include: BOOKING_INCLUDE });
  }

  /**
   * The salon says yes to a booking a customer made (the header's "Cần xác
   * nhận" → "Xác nhận"). Only a booking still waiting moves; one already
   * confirmed, arrived, finished or cancelled is returned as it is. No message
   * to the customer: she was sent her booking confirmation when she booked.
   */
  async confirmBySalon(user: AuthenticatedUser, id: string) {
    const tenantId = this.tenantId(user);
    const a = await this.prisma.appointment.findFirst({ where: { id, tenantId }, select: { id: true, status: true } });
    if (!a) throw new NotFoundException('Booking not found');
    const waiting: AppointmentStatus[] = [AppointmentStatus.PENDING, AppointmentStatus.ASSIGNED, AppointmentStatus.ACCEPTED, AppointmentStatus.REJECTED];
    if (!waiting.includes(a.status)) return this.getById(user, id);
    const now = new Date();
    const r = await this.prisma.appointment.updateMany({
      where: { id, tenantId, status: { in: waiting } },
      data: { status: AppointmentStatus.CONFIRMED, confirmedAt: now, responseDeadline: null },
    });
    if (r.count) {
      await this.audit.log({ tenantId, userId: user.userId, action: 'booking.confirmed_by_salon', resourceType: 'appointment', resourceId: id, metadata: { from: a.status } });
    }
    return this.getById(user, id);
  }

  /** Customer taps "Confirm" in a reminder. */
  async confirmByToken(token: string) {
    const id = this.verifyApptToken(token);
    if (!id) throw new NotFoundException('This link has expired or is invalid.');
    const a = await this.prisma.appointment.findUnique({ where: { id }, select: { id: true, tenantId: true, status: true, startTime: true } });
    if (!a) throw new NotFoundException('Appointment not found');
    if (BookingsService.shortLinkExpired(token, a.startTime)) throw new NotFoundException('This link has expired or is invalid.');
    if (!BookingsService.ACTIONABLE.includes(a.status)) return { ok: false, status: a.status };
    await this.prisma.appointment.update({ where: { id }, data: { customerConfirmedAt: new Date(), status: AppointmentStatus.CONFIRMED, confirmedAt: new Date() } });
    await this.audit.log({ tenantId: a.tenantId, userId: null, action: 'booking.customer_confirmed', resourceType: 'appointment', resourceId: id });
    return { ok: true, status: AppointmentStatus.CONFIRMED };
  }

  /** Customer taps "Cancel" in a reminder. */
  async cancelByToken(token: string) {
    const id = this.verifyApptToken(token);
    if (!id) throw new NotFoundException('This link has expired or is invalid.');
    const a = await this.prisma.appointment.findUnique({ where: { id }, select: { id: true, tenantId: true, status: true, startTime: true } });
    if (!a) throw new NotFoundException('Appointment not found');
    if (BookingsService.shortLinkExpired(token, a.startTime)) throw new NotFoundException('This link has expired or is invalid.');
    if (!BookingsService.ACTIONABLE.includes(a.status)) return { ok: false, status: a.status };
    await this.cancelForTenant(a.tenantId, id, null);
    return { ok: true, status: AppointmentStatus.CANCELLED };
  }

  async complete(user: AuthenticatedUser, id: string) {
    const tenantId = this.tenantId(user);
    // Already completed: settling the money and the referral reward again would count them twice.
    const cur = await this.prisma.appointment.findFirst({ where: { id, tenantId }, select: { status: true } });
    if (cur?.status === AppointmentStatus.COMPLETED) return this.getById(user, id);
    const result = await this.transition(user, id, AppointmentStatus.COMPLETED, 'booking.completed', 'completedAt');
    // Completing a visit means the money was collected — settle payment automatically.
    await this.payments.settleOnComplete(tenantId, id, user.userId);
    // Referral reward: if this customer was referred, reward both on their first
    // completed visit (no-op otherwise; never throws).
    const appt = await this.prisma.appointment.findFirst({ where: { id, tenantId }, select: { customerId: true } });
    await this.referral.rewardOnCompletion(tenantId, appt?.customerId, id);
    return result;
  }

  /**
   * Set any status directly, in either direction — a receptionist who pressed
   * Complete too early must be able to walk it back.
   *
   * Money follows the status: leaving COMPLETED takes back the at-salon payment
   * and the loyalty points it earned; entering COMPLETED collects and awards
   * them again. Deposits/online charges and POS orders are never touched.
   */
  async setStatus(user: AuthenticatedUser, id: string, status: AppointmentStatus) {
    const tenantId = this.tenantId(user);
    const a = await this.prisma.appointment.findFirst({
      where: { id, tenantId },
      select: { status: true, customerId: true },
    });
    if (!a) throw new NotFoundException('Booking not found');
    if (a.status === status) return this.getById(user, id);

    const wasCompleted = a.status === AppointmentStatus.COMPLETED;
    const willComplete = status === AppointmentStatus.COMPLETED;
    if (wasCompleted && !willComplete) {
      await this.payments.unsettleOnUncomplete(tenantId, id, user.userId);
    }

    // Written out field by field on purpose: a computed key would type as a
    // string index signature and slip past Prisma's input checking.
    const now = new Date();
    const data: Prisma.AppointmentUpdateManyMutationInput = { status };
    if (status === AppointmentStatus.ARRIVED) data.arrivedAt = now;
    if (status === AppointmentStatus.COMPLETED) data.completedAt = now;
    if (status === AppointmentStatus.CANCELLED) {
      data.cancelledAt = now;
      // The dropdown is a staff tool — stamp the author so "Đã huỷ" always
      // answers "by whom?".
      (data as Record<string, unknown>).cancelledBy = 'staff';
      (data as Record<string, unknown>).cancelledByName = await this.actorName(user.userId);
    }
    if (a.status === AppointmentStatus.CANCELLED && status !== AppointmentStatus.CANCELLED) {
      (data as Record<string, unknown>).cancelledBy = null;
      (data as Record<string, unknown>).cancelledByName = null;
    }
    // Reopening clears the finished stamp so reports stop counting it.
    if (wasCompleted && !willComplete) data.completedAt = null;
    await this.prisma.appointment.updateMany({ where: { id, tenantId }, data });
    // The dropdown is the common way a cancellation happens from the calendar
    // (the "Bước tiếp" column): it must tell the same people the Cancel button does.
    if (status === AppointmentStatus.CANCELLED && a.status !== AppointmentStatus.CANCELLED) {
      this.sendChangeNotice(tenantId, id, 'cancelled', { by: 'staff', byName: (data as { cancelledByName?: string | null }).cancelledByName ?? null }).catch(() => undefined);
    }
    await this.audit.log({
      tenantId, userId: user.userId, action: 'booking.status_set',
      resourceType: 'appointment', resourceId: id, metadata: { from: a.status, to: status },
    });

    if (willComplete && !wasCompleted) {
      await this.payments.settleOnComplete(tenantId, id, user.userId);
      await this.referral.rewardOnCompletion(tenantId, a.customerId, id);
    }
    return this.getById(user, id);
  }

  /**
   * Edit an in-flight visit: add services, drop lines, or stretch the time.
   * Prices and the end time move together, and the new end time is checked for
   * overlap exactly like a reschedule, so a longer visit cannot silently sit on
   * top of the next customer.
   */
  async editLines(
    user: AuthenticatedUser,
    id: string,
    dto: { addServiceIds?: string[]; removeIndexes?: number[]; extraMinutes?: number; replaceMainServiceId?: string; lang?: string },
  ) {
    const tenantId = this.tenantId(user);
    const b = await this.prisma.appointment.findFirst({ where: { id, tenantId } });
    if (!b) throw new NotFoundException('Booking not found');
    if (b.status === AppointmentStatus.CANCELLED || b.status === AppointmentStatus.REJECTED) {
      throw new BadRequestException('This booking is cancelled and can no longer be edited.');
    }

    type Item = { id?: string; name?: string; priceCents?: number; durationMinutes?: number; kind?: string; staffMemberId?: string | null };
    const current: Item[] = Array.isArray(b.addons) ? (b.addons as unknown as Item[]) : [];

    // 1) Drop the lines the salon removed (by position in the stored list).
    const drop = new Set((dto.removeIndexes ?? []).filter((n) => Number.isInteger(n) && n >= 0));
    const kept = current.filter((_, i) => !drop.has(i));
    const removed = current.filter((_, i) => drop.has(i));
    let removedPrice = removed.reduce((sum, x) => sum + (x.priceCents ?? 0), 0);
    let removedMinutes = removed.reduce((sum, x) => sum + (x.durationMinutes ?? 0), 0);

    // 1b) The main service swapped for another ("she wants a full set, not a fill").
    // The main service's share of the price is what the lines do not account for;
    // its minutes are its catalogue length. The new one is priced like an added line.
    let mainSwap: { id: string; name: string; from: string | null; priceCents: number; minutes: number } | null = null;
    const swapTo = (dto.replaceMainServiceId ?? '').trim();
    if (swapTo && swapTo !== b.serviceId) {
      const sv = await this.prisma.service.findFirst({ where: { id: swapTo, tenantId, isActive: true } });
      if (!sv) throw new BadRequestException('That service is unavailable.');
      const old = b.serviceId ? await this.prisma.service.findFirst({ where: { id: b.serviceId, tenantId }, select: { name: true, durationMinutes: true } }) : null;
      const linesPrice = current.reduce((sum, x) => sum + (x.priceCents ?? 0), 0);
      removedPrice += Math.max(0, b.priceCents - linesPrice);
      removedMinutes += old?.durationMinutes ?? 0;
      const disc = Math.min(90, Math.max(0, sv.discountPercent ?? 0));
      const net = Math.round((sv.priceCents * (100 - disc)) / 100);
      const wd = await this.promoDiscountPercent(tenantId, b.startTime, sv.categoryId, channelOfSource(b.source));
      mainSwap = { id: sv.id, name: sv.name, from: old?.name ?? null, priceCents: Math.round((net * (100 - wd)) / 100), minutes: sv.durationMinutes };
    }

    // 2) Add the new services, priced the same way the booking form prices them.
    const addIds = [...new Set(dto.addServiceIds ?? [])].filter(Boolean);
    const added: Item[] = [];
    if (addIds.length) {
      const svcs = await this.prisma.service.findMany({ where: { id: { in: addIds }, tenantId, isActive: true } });
      if (svcs.length !== addIds.length) throw new BadRequestException('One or more selected services are unavailable.');
      for (const sv of svcs) {
        const disc = Math.min(90, Math.max(0, sv.discountPercent ?? 0));
        const net = Math.round((sv.priceCents * (100 - disc)) / 100);
        const wd = await this.promoDiscountPercent(tenantId, b.startTime, sv.categoryId, channelOfSource(b.source));
        added.push({
          id: sv.id, name: sv.name, durationMinutes: sv.durationMinutes, kind: 'service',
          priceCents: Math.round((net * (100 - wd)) / 100),
        });
      }
    }
    const addedPrice = added.reduce((sum, x) => sum + (x.priceCents ?? 0), 0) + (mainSwap?.priceCents ?? 0);
    const addedMinutes = added.reduce((sum, x) => sum + (x.durationMinutes ?? 0), 0) + (mainSwap?.minutes ?? 0);

    // 3) Manual time on top (the "customer wants longer" case).
    const extra = Math.max(-600, Math.min(600, Math.round(dto.extraMinutes ?? 0)));

    const curMinutes = Math.round((b.endTime.getTime() - b.startTime.getTime()) / 60000);
    const newMinutes = Math.max(5, curMinutes + addedMinutes - removedMinutes + extra);
    const newPrice = Math.max(0, b.priceCents + addedPrice - removedPrice);
    const newEnd = addMinutes(b.startTime, newMinutes);
    const lines = [...kept, ...added];

    // Running into the technician's next booking: a visit already under way
    // records the time it really took (and says what it now overlaps); one
    // still ahead is refused, naming the booking in the way. See ./stretch-policy.
    const lang: StretchLang = dto.lang === 'vi' ? 'vi' : 'en';
    let stretchWarning: string | null = null;
    const updated = await this.prisma.$transaction(async (tx) => {
      if (b.assignedStaffId && newEnd.getTime() > b.endTime.getTime()) {
        await this.lockStaffSlot(tx, tenantId, b.assignedStaffId);
        const clash = await tx.appointment.findFirst({
          where: {
            tenantId, assignedStaffId: b.assignedStaffId, status: { in: BLOCKING_STATUSES },
            startTime: { lt: newEnd }, endTime: { gt: b.startTime }, id: { not: id },
          },
          orderBy: { startTime: 'asc' },
          select: { startTime: true, endTime: true, customer: { select: { firstName: true, lastName: true } }, assignedStaff: { select: { firstName: true } } },
        });
        if (clash) {
          const tz = (await tx.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }).catch(() => null))?.timezone || 'UTC';
          const info = {
            staff: clash.assignedStaff?.firstName?.trim() ?? '',
            customer: [clash.customer?.firstName, clash.customer?.lastName].filter(Boolean).join(' ').trim(),
            start: clash.startTime, end: clash.endTime,
          };
          if (!stretchMayOverlap(b.status, b.startTime, new Date())) {
            throw new ConflictException(clashMessage(info, newEnd, tz, lang, 'blocked'));
          }
          stretchWarning = clashMessage(info, newEnd, tz, lang, 'warning');
        }
      }
      await tx.appointment.updateMany({
        where: { id, tenantId },
        data: { endTime: newEnd, priceCents: newPrice, addons: lines as unknown as Prisma.InputJsonValue, ...(mainSwap ? { serviceId: mainSwap.id } : {}) },
      });
      return tx.appointment.findFirst({ where: { id, tenantId }, include: BOOKING_INCLUDE });
    });
    await this.audit.log({
      tenantId, userId: user.userId, action: 'booking.lines_edited',
      resourceType: 'appointment', resourceId: id,
      // Names are optional on a stored line, and `undefined` is not valid JSON —
      // Prisma.InputJsonValue rejects it, so drop the blanks before logging.
      metadata: {
        added: added.map((x) => x.name ?? '').filter(Boolean),
        removed: removed.map((x) => x.name ?? '').filter(Boolean),
        ...(mainSwap ? { mainFrom: mainSwap.from ?? '', mainTo: mainSwap.name } : {}),
        extraMinutes: extra,
        priceCents: newPrice,
      },
    });
    return updated && stretchWarning ? { ...updated, stretchWarning } : updated;
  }

  /** The note on a booking ("allergic to acetone", "bring her daughter"), written or cleared by the desk. */
  async updateNotes(user: AuthenticatedUser, id: string, notes: string | null) {
    const tenantId = this.tenantId(user);
    const text = (notes ?? '').trim().slice(0, 1000) || null;
    const r = await this.prisma.appointment.updateMany({ where: { id, tenantId }, data: { notes: text } });
    if (!r.count) throw new NotFoundException('Booking not found');
    await this.audit.log({ tenantId, userId: user.userId, action: 'booking.notes_edited', resourceType: 'appointment', resourceId: id, metadata: { length: text?.length ?? 0 } });
    return this.getById(user, id);
  }

  async noShow(user: AuthenticatedUser, id: string) {
    const tenantId = this.tenantId(user);
    const cur = await this.prisma.appointment.findFirst({ where: { id, tenantId }, select: { status: true } });
    if (cur?.status === AppointmentStatus.COMPLETED) {
      throw new BadRequestException('Lịch này đã hoàn tất — dùng "Đổi trạng thái" nếu thật sự cần.');
    }
    const onFloor = await this.prisma.walkIn.findFirst({ where: { tenantId, appointmentId: id, status: { not: WalkInStatus.CANCELLED } }, select: { id: true } }).catch(() => null);
    if (onFloor) throw new BadRequestException('Khách đã check-in và có phiếu trên sàn — không thể đánh vắng mặt.');
    return this.transition(user, id, AppointmentStatus.NO_SHOW, 'booking.no_show', 'updatedAt');
  }

  /** Front desk marks the customer as checked-in (in the salon). */
  async arrive(user: AuthenticatedUser, id: string) {
    const tenantId = this.tenantId(user);
    const a = await this.prisma.appointment.findFirst({ where: { id, tenantId }, select: { status: true } });
    if (!a) throw new NotFoundException('Booking not found');
    if (!BookingsService.ACTIONABLE.includes(a.status)) {
      throw new BadRequestException('Only an upcoming booking can be checked in.');
    }
    return this.transition(user, id, AppointmentStatus.ARRIVED, 'booking.arrived', 'arrivedAt');
  }

  /**
   * Permanently delete a booking (admin cleanup). Its payments are deleted too so
   * the booking's revenue is removed from reports (no orphaned PAID rows left).
   */
  async remove(user: AuthenticatedUser, id: string) {
    const tenantId = this.tenantId(user);
    const booking = await this.getById(user, id); // 404 + tenant ownership

    // Snapshot before removing. A booking carries its payments, so both go into
    // the bin together — restoring half of it would leave money orphaned.
    const row = await this.prisma.appointment.findFirst({ where: { id, tenantId } });
    const pays = await this.prisma.payment.findMany({ where: { tenantId, appointmentId: id } });
    const b = booking as { customer?: { firstName?: string; lastName?: string | null } | null; service?: { name?: string } | null; startTime?: Date };
    const who = `${b?.customer?.firstName ?? ''} ${b?.customer?.lastName ?? ''}`.trim() || 'Walk-in';
    // The only identifying line on the trash row — in the SALON's clock, not
    // UTC, or the admin restores "01:30" for an 8:30pm appointment.
    const tzRow = await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }).catch(() => null);
    const whenLabel = b?.startTime
      ? new Intl.DateTimeFormat('sv-SE', {
        timeZone: tzRow?.timezone || 'UTC', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false,
      }).format(new Date(b.startTime))
      : '';
    const label = `${who} · ${b?.service?.name ?? 'Service'} · ${whenLabel}`;

    await this.prisma.$transaction(async (tx) => {
      await this.trash.capture(tx, {
        tenantId, entity: 'appointment', entityId: id, label,
        snapshot: { appointment: row, payments: pays },
        deletedByUserId: user.userId,
      });
      await tx.payment.deleteMany({ where: { tenantId, appointmentId: id } });
      await tx.appointment.deleteMany({ where: { id, tenantId } });
    });
    await this.audit.log({
      tenantId,
      userId: user.userId,
      action: 'booking.deleted',
      resourceType: 'appointment',
      resourceId: id,
    });
    return { id, deleted: true };
  }

  // =========================================================================
  // Step 7: staff accept/reject workflow + assignment engine integration
  // =========================================================================

  /** Resolves the StaffMember linked to a STAFF user account (or throws). */
  private async staffMemberIdForUser(user: AuthenticatedUser): Promise<string> {
    const tenantId = this.tenantId(user);
    const staff = await this.prisma.staffMember.findFirst({
      where: { tenantId, userId: user.userId },
      select: { id: true },
    });
    if (!staff) {
      throw new ForbiddenException('No staff profile is linked to this account');
    }
    return staff.id;
  }

  /** Bookings assigned to the signed-in staff member (their work queue). */
  /**
   * "Nhờ quầy liên hệ khách": a technician who cannot see a client's number
   * (common/contact-privacy) asks the front desk to call or text them. Her own
   * booking only; the desk's phones get a push, the audit log keeps the ask.
   */
  async askDeskToContact(user: AuthenticatedUser, id: string, message?: string) {
    const tenantId = this.tenantId(user);
    const staffId = await this.staffMemberIdForUser(user);
    const b = await this.prisma.appointment.findFirst({
      where: { id, tenantId, assignedStaffId: staffId },
      select: { id: true, startTime: true, customer: { select: { firstName: true, lastName: true } }, assignedStaff: { select: { firstName: true } } },
    });
    if (!b) throw new NotFoundException('Booking not found');
    const text = typeof message === 'string' ? message.trim().slice(0, 200) : '';
    const tz = (await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }).catch(() => null))?.timezone || 'UTC';
    const when = new Intl.DateTimeFormat('en-US', { timeZone: tz, weekday: 'short', hour: 'numeric', minute: '2-digit' }).format(b.startTime);
    const who = [b.customer?.firstName, b.customer?.lastName].filter(Boolean).join(' ') || 'Client';
    const [admins, staff] = await Promise.all([
      this.prisma.user.findMany({ where: { tenantId, role: UserRole.SALON_ADMIN, isActive: true }, select: { id: true } }),
      this.prisma.staffMember.findMany({ where: { tenantId, userId: { not: null } }, select: { userId: true, staffRole: true, permissions: true } as never }) as unknown as Promise<{ userId: string | null; staffRole: string | null; permissions?: unknown }[]>,
    ]);
    const to = deskUserIds(admins, staff);
    await this.push.sendToTenant(tenantId, {
      title: `📞 ${b.assignedStaff?.firstName ?? 'Tech'}: contact ${who}`,
      body: `${when}${text ? ` — ${text}` : ''}`,
      url: '/salon/calendar',
      tag: `desk-contact-${b.id}`,
    }, { onlyUserIds: to }).catch(() => undefined);
    await this.audit.log({ tenantId, userId: user.userId, action: 'booking.desk_contact_requested', resourceType: 'appointment', resourceId: b.id, metadata: { message: text || null, notified: to.length } });
    return { ok: true, notified: to.length };
  }

  async listMyAssignments(user: AuthenticatedUser, filters: ListBookingsDto) {
    const tenantId = this.tenantId(user);
    const staffId = await this.staffMemberIdForUser(user);
    const where: Prisma.AppointmentWhereInput = { tenantId, assignedStaffId: staffId };
    if (filters.status) where.status = filters.status;
    if (filters.from || filters.to) {
      where.startTime = {};
      if (filters.from) where.startTime.gte = new Date(filters.from);
      if (filters.to) where.startTime.lte = new Date(filters.to);
    }
    return this.prisma.appointment.findMany({
      where,
      include: BOOKING_INCLUDE,
      orderBy: { startTime: 'asc' },
    });
  }

  /** Her own open start times on one day — her shift, her bookings, her leave — for "Hẹn lần sau". */
  async myOpenTimes(user: AuthenticatedUser, q: { date: string; minutes?: number }) {
    const staffId = await this.staffMemberIdForUser(user);
    return this.openTimes(user, { ...q, staffId });
  }

  /**
   * "HẸN LẦN SAU" from the chair: while the client is still with her, the
   * technician books the next visit on HERSELF, confirmed at once (like the
   * till's rebook — source `counter`). The client comes from her own ticket
   * (the walk-in's customer record, or its name and phone) or from one of her
   * bookings; she can never book a client onto another technician, and never
   * from another salon's ticket.
   */
  async myRebook(user: AuthenticatedUser, dto: { walkInId?: string; appointmentId?: string; serviceId: string; serviceIds?: string[]; startTime: string; notes?: string }) {
    const tenantId = this.tenantId(user);
    const staffId = await this.staffMemberIdForUser(user);
    let customerId: string | null = null;
    let first = '';
    let last: string | undefined;
    let phone: string | undefined;
    if (dto.walkInId) {
      const w = await this.prisma.walkIn.findFirst({ where: { id: dto.walkInId, tenantId }, select: { customerId: true, customerName: true, phone: true, assignedStaffId: true, items: true } });
      if (!w) throw new NotFoundException('Ticket not found');
      // A technician rebooks her own client, never a colleague's (whose phone she would get).
      if (user.role === UserRole.STAFF) {
        const lines = (Array.isArray(w.items) ? w.items : []) as { staffId?: string | null }[];
        if (!staffId || (w.assignedStaffId !== staffId && !lines.some((l) => l?.staffId === staffId))) {
          throw new ForbiddenException('This client is not yours');
        }
      }
      customerId = w.customerId ?? null;
      const parts = (w.customerName ?? '').trim().split(/\s+/).filter(Boolean);
      first = parts[0] ?? '';
      last = parts.slice(1).join(' ') || undefined;
      phone = w.phone ?? undefined;
    } else if (dto.appointmentId) {
      const a = await this.prisma.appointment.findFirst({ where: { id: dto.appointmentId, tenantId }, select: { customerId: true, assignedStaffId: true, customer: { select: { firstName: true, lastName: true, phone: true } } } });
      if (!a) throw new NotFoundException('Booking not found');
      if (a.assignedStaffId !== staffId) throw new ForbiddenException('This booking is not assigned to you');
      customerId = a.customerId ?? null;
      first = a.customer?.firstName ?? '';
      last = a.customer?.lastName ?? undefined;
      phone = a.customer?.phone ?? undefined;
    } else {
      throw new BadRequestException('walkInId or appointmentId is required');
    }
    if (!customerId && !phone) throw new BadRequestException('This client has no phone on file — the desk can add one, then book.');
    const clean = Object.assign(new CreateBookingDto(), {
      serviceId: dto.serviceId, serviceIds: dto.serviceIds?.length ? dto.serviceIds : undefined, startTime: dto.startTime, staffId, confirmNow: true,
      customerId: customerId ?? undefined, customerFirstName: first || 'Khách', customerLastName: last, customerPhone: phone,
      notes: (dto.notes ?? '').trim().slice(0, 300) || undefined,
    }) as CreateBookingDto;
    return this.create(user, clean, 'counter');
  }

  /**
   * THẺ KHÁCH for the technician's booking sheet (bookings/client-card.ts).
   * A technician only reads it for a booking assigned to HER; the desk and
   * the owner for any booking of this salon. One salon's rows only.
   */
  async clientCard(user: AuthenticatedUser, id: string) {
    const tenantId = this.tenantId(user);
    const appt = await this.prisma.appointment.findFirst({ where: { id, tenantId }, select: { customerId: true, assignedStaffId: true } });
    if (!appt) throw new NotFoundException('Booking not found');
    let me: string | null = appt.assignedStaffId;
    if (user.role === UserRole.STAFF) {
      const sm = await this.prisma.staffMember.findFirst({ where: { tenantId, userId: user.userId }, select: { id: true, staffRole: true, permissions: true } as never }) as unknown as { id: string; staffRole?: string; permissions?: unknown } | null;
      if (!sm) throw new NotFoundException('No staff profile for this login');
      // Her own booking — or she runs the desk (a manager / receptionist with the bookings capability).
      const desk = capabilitiesFor(UserRole.STAFF, (sm.staffRole ?? 'TECHNICIAN') as never, sm.permissions).includes('bookings' as never);
      if (appt.assignedStaffId !== sm.id && !desk) throw new ForbiddenException('This booking is not assigned to you');
      if (appt.assignedStaffId === sm.id) me = sm.id;
    }
    if (!appt.customerId) return { card: null };
    const [customer, tenant, industry] = await Promise.all([
      this.prisma.customer.findFirst({
        where: { id: appt.customerId, tenantId },
        select: {
          firstName: true, lastName: true, notes: true, loyaltyPoints: true, birthDate: true, createdAt: true,
          industryFields: true, importedVisits: true, lastVisitAt: true,
          appointments: {
            where: { status: AppointmentStatus.COMPLETED, id: { not: id } },
            select: { startTime: true, assignedStaffId: true, service: { select: { name: true } }, assignedStaff: { select: { firstName: true } } },
            orderBy: { startTime: 'desc' }, take: 100,
          },
        } as never,
      }) as unknown as Promise<{
        firstName: string; lastName: string | null; notes: string | null; loyaltyPoints: number; birthDate: Date | null; createdAt: Date;
        industryFields?: unknown; importedVisits?: number; lastVisitAt?: Date | null;
        appointments: { startTime: Date; assignedStaffId: string | null; service: { name: string } | null; assignedStaff: { firstName: string } | null }[];
      } | null>,
      this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } }).catch(() => null),
      this.industryOfTenant(tenantId),
    ]);
    if (!customer) return { card: null };
    // Walk-in sales at the till are visits too (a regular who never books online).
    const orders = await this.prisma.order.findMany({
      where: { tenantId, customerId: appt.customerId, status: OrderStatus.PAID, appointmentId: null },
      select: { createdAt: true, items: { select: { name: true, staffMemberId: true } } },
      orderBy: { createdAt: 'desc' }, take: 100,
    }).catch(() => [] as { createdAt: Date; items: { name: string; staffMemberId: string | null }[] }[]);
    const techIds = [...new Set(orders.flatMap((o) => o.items.map((i) => i.staffMemberId)).filter((x): x is string => !!x))];
    const techs = techIds.length ? await this.prisma.staffMember.findMany({ where: { tenantId, id: { in: techIds } }, select: { id: true, firstName: true } }) : [];
    const techName = new Map(techs.map((t) => [t.id, t.firstName]));
    const visits: CardVisit[] = [
      ...customer.appointments.map((a) => ({ at: a.startTime, services: [a.service?.name ?? ''].filter(Boolean), staff: a.assignedStaff?.firstName ?? null, withMe: !!me && a.assignedStaffId === me })),
      ...orders.map((o) => ({
        at: o.createdAt, services: o.items.map((i) => i.name).filter(Boolean),
        staff: techName.get(o.items.find((i) => i.staffMemberId)?.staffMemberId ?? '') ?? null,
        withMe: !!me && o.items.some((i) => i.staffMemberId === me),
      })),
    ];
    return { card: buildClientCard({ industry, customer: { ...customer, industryFields: customer.industryFields ?? {} }, visits, tz: tenant?.timezone ?? null }) };
  }

  /** Staff accepts a booking that is assigned to them. */
  async accept(user: AuthenticatedUser, id: string) {
    const tenantId = this.tenantId(user);
    const staffId = await this.staffMemberIdForUser(user);
    const booking = await this.getById(user, id);

    if (booking.assignedStaffId !== staffId) {
      throw new ForbiddenException('This booking is not assigned to you');
    }
    if (booking.status !== AppointmentStatus.ASSIGNED) {
      throw new BadRequestException(`Cannot accept a booking in status ${booking.status}`);
    }

    await this.prisma.appointment.updateMany({
      where: { id, tenantId },
      data: { status: AppointmentStatus.ACCEPTED, acceptedAt: new Date() },
    });
    await this.audit.log({
      tenantId,
      userId: user.userId,
      action: 'booking.accepted',
      resourceType: 'appointment',
      resourceId: id,
      metadata: { staffId },
    });
    return this.getById(user, id);
  }

  /**
   * Staff rejects a booking assigned to them. The rejection is recorded and the
   * engine tries to reassign to the next best staff (excluding everyone who has
   * already rejected this booking). If nobody qualifies the booking returns to
   * PENDING for manual handling.
   */
  async reject(user: AuthenticatedUser, id: string, reason?: string) {
    const tenantId = this.tenantId(user);
    const staffId = await this.staffMemberIdForUser(user);
    const booking = await this.getById(user, id);

    if (booking.assignedStaffId !== staffId) {
      throw new ForbiddenException('This booking is not assigned to you');
    }
    if (booking.status !== AppointmentStatus.ASSIGNED) {
      throw new BadRequestException(`Cannot reject a booking in status ${booking.status}`);
    }

    await this.prisma.bookingRejection.create({
      data: {
        tenantId,
        appointmentId: id,
        staffMemberId: staffId,
        type: RejectionType.REJECTED,
        reason: reason ?? null,
      },
    });
    await this.audit.log({
      tenantId,
      userId: user.userId,
      action: 'booking.rejected',
      resourceType: 'appointment',
      resourceId: id,
      metadata: { staffId, reason },
    });

    return this.reassign(tenantId, id, user.userId);
  }

  /** Super/Salon admin asks the engine to assign a PENDING booking. */
  async autoAssign(user: AuthenticatedUser, id: string) {
    const tenantId = this.tenantId(user);
    const before = await this.getById(user, id); // tenant ownership / 404
    const res = await this.reassign(tenantId, id, user.userId);
    // Multi-service visits: give every extra line its own eligible tech too.
    // The public booking flow already does this; the front-desk button used to
    // stop at the primary, leaving the other services technically unowned.
    await this.assignExtraServiceLines(tenantId, id).catch(() => undefined);
    if (!before.assignedStaffId && (res as { reassigned?: boolean }).reassigned) await this.tellCustomerTechById(tenantId, id);
    return res;
  }

  private async tellCustomerTechById(tenantId: string, id: string) {
    const b = await this.prisma.appointment.findFirst({ where: { id, tenantId }, include: BOOKING_INCLUDE }).catch(() => null);
    if (b) this.tellCustomerTech(tenantId, b as never);
  }

  /**
   * Auto-assign for the public booking flow (no acting user). Runs the engine
   * (fair round-robin + skill/availability/history rules) for a tenant booking.
   */
  /**
   * Front desk picks the technician of ONE service line by hand. Needed when
   * the auto pick is wrong or the salon runs manual assignment: a visit of
   * "Colour + Nail Design" where Lisa only does colour MUST be splittable —
   * one tech per service — or the desk ends up lying to the floor.
   *
   * The primary service's tech stays on /assign (it owns the calendar slot);
   * this writes staffMemberId into the extra line inside the line-item
   * snapshot — the same field the auto engine and the POS checkout read, so
   * commission lands on the right tech with no extra plumbing.
   */
  async setLineStaff(user: AuthenticatedUser, id: string, dto: { serviceId: string; staffId?: string | null }) {
    const tenantId = this.tenantId(user);
    const appt = await this.prisma.appointment.findFirst({
      where: { id, tenantId },
      select: { id: true, addons: true },
    });
    if (!appt) throw new NotFoundException('Booking not found');

    const lines = Array.isArray(appt.addons) ? [...(appt.addons as unknown as Array<Record<string, unknown>>)] : [];
    const line = lines.find((l) => l && l.kind === 'service' && String(l.id) === dto.serviceId);
    if (!line) throw new NotFoundException('This service line is not on the booking.');

    if (dto.staffId) {
      await this.assertStaffActive(tenantId, dto.staffId);
      line.staffMemberId = dto.staffId;
    } else {
      delete line.staffMemberId;
    }

    await this.prisma.appointment.updateMany({
      where: { id, tenantId },
      data: { addons: lines as unknown as Prisma.InputJsonValue },
    });
    await this.audit.log({
      tenantId,
      userId: user.userId,
      action: 'booking.line_staff',
      resourceType: 'appointment',
      resourceId: id,
      metadata: { serviceId: dto.serviceId, staffId: dto.staffId ?? null },
    });
    await this.followOnFloor(tenantId, id, null, dto.staffId, dto.serviceId);
    return this.getById(user, id);
  }

  /**
   * "Why is nobody on this booking?" — the assignment mode and the engine's
   * filters, counted (assignment.service explain). For the desk's drawer.
   */
  async assignCheck(user: AuthenticatedUser, id: string) {
    const tenantId = this.tenantId(user);
    const b = await this.prisma.appointment.findFirst({
      where: { id, tenantId },
      select: { id: true, serviceId: true, startTime: true, endTime: true, preferredStaffId: true, assignedStaffId: true },
    });
    if (!b) throw new NotFoundException('Booking not found');
    const [rules, why] = await Promise.all([
      this.settings.getBookingRules(tenantId),
      this.assignment.explain(tenantId, { id: b.id, serviceId: b.serviceId, startTime: b.startTime, endTime: b.endTime, preferredStaffId: b.preferredStaffId }),
    ]);
    return { mode: rules.assignmentMode, assigned: Boolean(b.assignedStaffId), ...why };
  }

  /**
   * "Giao tự động các lịch chưa có thợ": every upcoming PENDING booking of
   * this salon with nobody on it goes through the engine once (fair turn,
   * skills, shifts). For after the owner fixed a setup gap. At most 100.
   */
  async autoAssignOpen(user: AuthenticatedUser, now = new Date()) {
    const tenantId = this.tenantId(user);
    const rows = await this.prisma.appointment.findMany({
      where: { tenantId, assignedStaffId: null, status: AppointmentStatus.PENDING, startTime: { gte: now } },
      select: { id: true }, orderBy: { startTime: 'asc' }, take: 100,
    });
    let assigned = 0;
    for (const r of rows) {
      try {
        const res = await this.autoAssignForTenant(tenantId, r.id);
        if ((res as { reassigned?: boolean } | null)?.reassigned) { assigned++; await this.tellCustomerTechById(tenantId, r.id); }
      } catch { /* the next one */ }
    }
    await this.audit.log({ tenantId, userId: user.userId, action: 'booking.auto_assign_open', resourceType: 'tenant', resourceId: tenantId, metadata: { checked: rows.length, assigned } });
    return { checked: rows.length, assigned };
  }

  async autoAssignForTenant(tenantId: string, bookingId: string) {
    // 1) Assign the PRIMARY service's technician (fair rotation, skill + availability).
    //    `notify: false` — the technician's mail is held back until step 2 has run,
    //    or it reads the booking while the other service lines are still unowned
    //    and tells a two-tech visit it is a one-tech visit.
    const res = await this.reassign(tenantId, bookingId, null, false);
    // 2) Multi-service visit: assign each EXTRA service to its own free specialist so a
    //    salon where every tech does one specialty needs ZERO manual assignment. The
    //    per-line tech is written into the appointment's line-item snapshot, and the POS
    //    checkout reads it — the front desk just presses Pay.
    await this.assignExtraServiceLines(tenantId, bookingId).catch(() => { /* best-effort */ });
    // 3) Now the picture is complete: tell the technician (fire-and-forget).
    if (res.reassigned) this.sendStaffAssignmentEmail(tenantId, bookingId).catch(() => undefined);
    return res;
  }

  /**
   * For a multi-service appointment, decide who does each extra service line
   * and write staffMemberId into the stored line items. Silent no-op for
   * single-service visits.
   *
   * ONE PERSON, ONE CHAIR. A single customer's services happen one after
   * another on one chair, so the technician on the visit (chosen by the
   * customer, or picked by the engine for the first service) does every line
   * they are able to do; somebody else takes a line only when that technician
   * genuinely cannot do it. This used to prefer "a specialist not yet used on
   * this visit" for every line — a rule written for groups that ran on
   * everyone, and how a customer who booked two services with Tuấn got a
   * booking that named Tuấn and Tiffany.
   *
   * A GROUP (partySize > 1) is several people served at the same time, and
   * there the lines are still spread across free technicians.
   *
   * `fillGaps` — may the engine pick somebody else on its own? True in auto
   * assignment mode; in manual mode a line the visit's technician cannot do
   * is left blank for the front desk.
   */
  private async assignExtraServiceLines(tenantId: string, bookingId: string, opts: { fillGaps?: boolean } = {}): Promise<void> {
    const fillGaps = opts.fillGaps ?? true;
    const appt = await this.prisma.appointment.findFirst({
      where: { id: bookingId, tenantId },
      select: { id: true, startTime: true, endTime: true, assignedStaffId: true, preferredStaffId: true, addons: true, partySize: true } as never,
    }) as { id: string; startTime: Date; endTime: Date; assignedStaffId: string | null; preferredStaffId: string | null; addons: unknown; partySize?: number } | null;
    if (!appt) return;
    const lines = Array.isArray(appt.addons) ? [...(appt.addons as unknown as Array<Record<string, unknown>>)] : [];
    const serviceLines = lines.filter((l) => l && l.kind === 'service');
    if (serviceLines.length === 0) return;

    // What the visit's technician is able to do. Skills are read the way the
    // engine reads them: a registered list means only those services; no list
    // means anything.
    const primaryId = appt.assignedStaffId;
    const primary = primaryId
      ? await this.prisma.staffMember.findFirst({
          where: { id: primaryId, tenantId, isActive: true },
          select: { id: true, staffServices: { select: { serviceId: true } } },
        }).catch(() => null)
      : null;
    const primaryCanDo = (serviceId: string) =>
      Boolean(primary && (primary.staffServices.length === 0 || primary.staffServices.some((x) => x.serviceId === serviceId)));

    const used = new Set<string>();
    if (primaryId) used.add(primaryId);
    let changed = false;

    for (const line of serviceLines) {
      const serviceId = String(line.id);
      const plan = planLineTechnician(line as { staffMemberId?: string | null }, {
        partySize: appt.partySize ?? 1,
        primaryStaffId: primary ? primary.id : null,
        primaryCanDo: primaryCanDo(serviceId),
        fillGaps,
      });
      if (plan === 'keep') { used.add(String(line.staffMemberId)); continue; }
      if (plan === 'leave') continue;
      if (plan === 'primary') {
        line.staffMemberId = primary!.id;
        changed = true;
        continue;
      }
      // 'other': the best free technician who can do THIS service — for a
      // group, preferring one not yet on the visit so the people are served
      // at once; if nobody else is free, allow reuse.
      const pick = async (exclude: string[]) => {
        const { orderedStaffIds } = await this.assignment.rankEligibleStaff(
          tenantId,
          { id: appt.id, serviceId, startTime: appt.startTime, endTime: appt.endTime, preferredStaffId: appt.preferredStaffId },
          exclude,
        );
        return orderedStaffIds[0] ?? null;
      };
      const staffId = (await pick([...used])) ?? (await pick([]));
      if (staffId) {
        line.staffMemberId = staffId;
        used.add(staffId);
        changed = true;
      }
    }

    if (changed) {
      await this.prisma.appointment.updateMany({
        where: { id: bookingId, tenantId },
        data: { addons: lines as unknown as Prisma.InputJsonValue },
      });
    }
  }

  /**
   * Core reassignment: ask the engine for the best eligible staff (excluding
   * everyone already in this booking's rejection log) and assign them race-safe,
   * or fall back to PENDING/unassigned.
   */
  private async reassign(tenantId: string, id: string, actorUserId: string | null, notify = true, opts: { keepWhenNobody?: boolean } = {}) {
    const booking = await this.prisma.appointment.findFirst({
      where: { id, tenantId },
      select: { id: true, serviceId: true, startTime: true, endTime: true, preferredStaffId: true },
    });
    if (!booking) {
      throw new NotFoundException('Booking not found');
    }

    const rejecters = await this.prisma.bookingRejection.findMany({
      where: { tenantId, appointmentId: id },
      select: { staffMemberId: true },
    });
    const excludeStaffIds = [...new Set(rejecters.map((r) => r.staffMemberId))];

    const { orderedStaffIds } = await this.assignment.rankEligibleStaff(
      tenantId,
      {
        id: booking.id,
        serviceId: booking.serviceId,
        startTime: booking.startTime,
        endTime: booking.endTime,
        preferredStaffId: booking.preferredStaffId,
      },
      excludeStaffIds,
    );

    const nextStaffId = orderedStaffIds[0] ?? null;

    if (!nextStaffId && opts.keepWhenNobody) {
      const kept = await this.prisma.appointment.findFirst({ where: { id, tenantId }, include: BOOKING_INCLUDE });
      return { reassigned: false, booking: kept };
    }

    if (!nextStaffId) {
      // No one available -> leave it PENDING and unassigned for manual handling.
      await this.prisma.appointment.updateMany({
        where: { id, tenantId },
        data: {
          status: AppointmentStatus.PENDING,
          assignedStaffId: null,
          assignedAt: null,
          responseDeadline: null,
        },
      });
      await this.audit.log({
        tenantId,
        userId: actorUserId,
        action: 'booking.unassigned_no_candidate',
        resourceType: 'appointment',
        resourceId: id,
      });
      const result = await this.prisma.appointment.findFirst({
        where: { id, tenantId },
        include: BOOKING_INCLUDE,
      });
      return { reassigned: false, booking: result };
    }

    const assigned = await this.assignStaff(tenantId, booking, nextStaffId, actorUserId, notify);
    return { reassigned: true, booking: assigned };
  }

  /** Race-safe assignment used by reassign / processTimeouts. */
  private async assignStaff(
    tenantId: string,
    booking: { id: string; startTime: Date; endTime: Date },
    staffId: string,
    actorUserId: string | null,
    /** Set false by a caller that will send the technician's mail itself, once
     *  the rest of the visit has been assigned too. */
    notify = true,
  ) {
    const updated = await this.prisma.$transaction(async (tx) => {
      await this.lockStaffSlot(tx, tenantId, staffId);
      await this.assertNoOverlap(tx, tenantId, staffId, booking.startTime, booking.endTime, booking.id);
      // A confirmed (or arrived) visit only changes hands — the engine picking
      // its technician must not send it back to "Chờ xác nhận".
      const cur = await tx.appointment.findFirst({ where: { id: booking.id, tenantId }, select: { status: true } });
      const keepStatus = cur?.status === AppointmentStatus.CONFIRMED || cur?.status === AppointmentStatus.ARRIVED;
      await tx.appointment.updateMany({
        where: { id: booking.id, tenantId },
        data: {
          assignedStaffId: staffId,
          assignedAt: new Date(),
          rejectedAt: null,
          ...(keepStatus ? {} : { status: AppointmentStatus.ASSIGNED, responseDeadline: addMinutes(new Date(), 30) }),
        },
      });
      return tx.appointment.findFirst({ where: { id: booking.id, tenantId }, include: BOOKING_INCLUDE });
    });
    await this.audit.log({
      tenantId,
      userId: actorUserId,
      action: 'booking.assigned',
      resourceType: 'appointment',
      resourceId: booking.id,
      metadata: { staffId, via: 'engine' },
    });
    // Notify the newly-assigned technician (fire-and-forget).
    if (notify) this.sendStaffAssignmentEmail(tenantId, booking.id).catch(() => undefined);
    return updated;
  }

  /**
   * Finds ASSIGNED bookings whose response deadline has passed, records a
   * NO_RESPONSE for the silent staff, and reassigns each (or returns the
   * booking to PENDING for the desk when nobody else is free). The scheduler
   * runs this for every salon every few minutes; an admin can also call it.
   */
  async processTimeouts(user: AuthenticatedUser) {
    return this.expireAssigned(this.tenantId(user), user.userId);
  }

  /**
   * The same sweep for every salon at once — one salon's failure never stops
   * the next, and every write below is scoped to the row's own tenantId.
   */
  async processTimeoutsEverywhere(now = new Date()): Promise<{ tenants: number; processed: number; reassigned: number }> {
    const rows = await this.prisma.appointment.findMany({
      where: { status: AppointmentStatus.ASSIGNED, responseDeadline: { lt: now }, assignedStaffId: { not: null } },
      select: { tenantId: true }, distinct: ['tenantId'],
    });
    let processed = 0;
    let reassigned = 0;
    for (const r of rows) {
      try {
        const out = await this.expireAssigned(r.tenantId, null, now);
        processed += out.processed; reassigned += out.reassigned;
      } catch (e) {
        this.logger.warn(`response-timeout sweep failed for tenant ${r.tenantId}: ${(e as Error).message}`);
      }
    }
    return { tenants: rows.length, processed, reassigned };
  }

  private async expireAssigned(tenantId: string, actorUserId: string | null, now = new Date()) {
    const expired = await this.prisma.appointment.findMany({
      where: {
        tenantId,
        status: AppointmentStatus.ASSIGNED,
        responseDeadline: { lt: now },
        assignedStaffId: { not: null },
      },
      select: { id: true, assignedStaffId: true },
    });
    if (!expired.length) return { processed: 0, reassigned: 0 };

    // Only a salon whose technicians answer in the app loses a silent
    // technician's booking (BookingRules.staffMustAccept). Everywhere else the
    // deadline is simply cleared: the technician the engine — or the desk —
    // picked keeps the booking. Taking it away after 30 minutes is what left
    // every salon's calendar reading "Chưa có thợ".
    const rules = await this.settings.getBookingRules(tenantId).catch(() => null);
    if (!rules?.staffMustAccept) {
      await this.prisma.appointment.updateMany({
        where: { id: { in: expired.map((e) => e.id) }, tenantId, status: AppointmentStatus.ASSIGNED },
        data: { responseDeadline: null },
      });
      return { processed: 0, reassigned: 0 };
    }

    let reassigned = 0;
    for (const appt of expired) {
      if (appt.assignedStaffId) {
        await this.prisma.bookingRejection.create({
          data: {
            tenantId,
            appointmentId: appt.id,
            staffMemberId: appt.assignedStaffId,
            type: RejectionType.NO_RESPONSE,
          },
        });
      }
      // Nobody else free: the booking stays with the technician it had —
      // a booking with someone is better than a booking with no one.
      const result = await this.reassign(tenantId, appt.id, actorUserId, true, { keepWhenNobody: true });
      if (result.reassigned) reassigned += 1;
      else await this.prisma.appointment.updateMany({ where: { id: appt.id, tenantId, status: AppointmentStatus.ASSIGNED }, data: { responseDeadline: null } });
    }

    return { processed: expired.length, reassigned };
  }

  /**
   * ONE-TIME REPAIR of what the response-deadline sweep did between Oct 4 and
   * the fix: for every salon that does not require "Accept" in the app, the
   * NO_RESPONSE marks it wrote are removed (they also pushed those technicians
   * down the rotation), and every upcoming booking it left without a
   * technician is run through the engine again — in auto-assignment salons
   * only, exactly as a new booking would be. Idempotent: a booking the engine
   * staffs is no longer unassigned; one nobody can take stays for the desk.
   */
  async repairStrippedAssignments(now = new Date()): Promise<{ tenants: number; cleared: number; restaffed: number }> {
    const since = new Date('2026-10-04T00:00:00Z');
    const marks = await this.prisma.bookingRejection.findMany({
      where: { type: RejectionType.NO_RESPONSE, createdAt: { gte: since } },
      select: { id: true, tenantId: true, appointmentId: true },
    });
    const byTenant = new Map<string, typeof marks>();
    for (const m of marks) byTenant.set(m.tenantId, [...(byTenant.get(m.tenantId) ?? []), m]);
    let cleared = 0, restaffed = 0;
    for (const [tenantId, rows] of byTenant) {
      try {
        const rules = await this.settings.getBookingRules(tenantId);
        if (rules.staffMustAccept) continue;
        const del = await this.prisma.bookingRejection.deleteMany({ where: { tenantId, id: { in: rows.map((r) => r.id) } } });
        cleared += del.count;
        if (rules.assignmentMode !== 'auto') continue;
        const open = await this.prisma.appointment.findMany({
          where: { tenantId, id: { in: [...new Set(rows.map((r) => r.appointmentId))] }, assignedStaffId: null, status: AppointmentStatus.PENDING, startTime: { gt: now } },
          select: { id: true },
        });
        for (const a of open) {
          const res = await this.autoAssignForTenant(tenantId, a.id).catch(() => null);
          if (res?.reassigned) restaffed += 1;
        }
      } catch (e) {
        this.logger.warn(`assignment repair failed for tenant ${tenantId}: ${(e as Error).message}`);
      }
    }
    return { tenants: byTenant.size, cleared, restaffed };
  }

  /**
   * Yesterday's bookings nobody touched. A customer who never came, on a
   * booking the desk never marked, stayed "Confirmed" on the calendar for
   * ever: it inflated the day's count, hid the no-show from her record, and
   * left a slot that looked taken. Once the salon's own day has ended, every
   * still-open booking from before it (pending, assigned, accepted or
   * confirmed — never one that ARRIVED) becomes NO_SHOW, keeping any deposit,
   * exactly as the desk's own No-show button does.
   */
  async closeMissedEverywhere(now = new Date()): Promise<{ tenants: number; closed: number }> {
    const open: AppointmentStatus[] = [AppointmentStatus.PENDING, AppointmentStatus.ASSIGNED, AppointmentStatus.ACCEPTED, AppointmentStatus.CONFIRMED];
    // Anything that ended more than a day ago is from before today anywhere on Earth;
    // the per-tenant pass below uses the salon's own midnight for the rest.
    const rows = await this.prisma.appointment.findMany({
      where: { status: { in: open }, endTime: { lt: new Date(now.getTime() - 60 * 60 * 1000) } },
      select: { tenantId: true }, distinct: ['tenantId'],
    });
    let closed = 0;
    for (const r of rows) {
      try { closed += await this.closeMissed(r.tenantId, now); }
      catch (e) { this.logger.warn(`no-show sweep failed for tenant ${r.tenantId}: ${(e as Error).message}`); }
    }
    return { tenants: rows.length, closed };
  }

  /** Bookings proven by a same-day ticket of the same customer: paired, returned. */
  private async pairWithVisits(tenantId: string, tz: string, appts: { id: string; customerId: string | null; startTime: Date }[]): Promise<string[]> {
    const custIds = [...new Set(appts.map((a) => a.customerId).filter((x): x is string => !!x))];
    if (!custIds.length) return [];
    const first = appts.reduce((m, a) => Math.min(m, +new Date(a.startTime)), Infinity);
    const last = appts.reduce((m, a) => Math.max(m, +new Date(a.startTime)), 0);
    const tickets = await this.prisma.walkIn.findMany({
      where: { tenantId, customerId: { in: custIds }, appointmentId: null, status: { not: WalkInStatus.CANCELLED }, createdAt: { gte: new Date(first - 86400000), lte: new Date(last + 86400000) } },
      select: { id: true, customerId: true, createdAt: true, appointmentId: true, status: true },
    });
    const pairs = matchMissedToVisits(appts, tickets as never, (d) => dayKeyTz(d, tz));
    const done: string[] = [];
    for (const p of pairs) {
      if (await pairTicketWithBooking(this.prisma as never, tenantId, p.walkInId, p.appointmentId, p.at)) {
        done.push(p.appointmentId);
        await this.audit.log({ tenantId, userId: null, action: 'booking.matched_walkin', resourceType: 'appointment', resourceId: p.appointmentId, metadata: { walkInId: p.walkInId } }).catch(() => undefined);
      }
    }
    return done;
  }

  /**
   * Once per boot (idempotent): bookings the midnight sweep marked NO_SHOW in
   * the last 60 days although the customer was served as a walk-in that day go
   * back to ARRIVED, tied to that ticket. Only the sweep's own marks
   * (audit booking.no_show_auto) — never a No-show the desk pressed.
   */
  /** Till sales written before 26/10/2026 that lost their booking (till-repair.ts). Idempotent. */
  async repairTillLinks(now = new Date()): Promise<{ payments: number; services: number }> {
    return repairTillLinks(this.prisma as never, now);
  }

  async repairFalseNoShows(now = new Date()): Promise<{ tenants: number; repaired: number }> {
    const since = new Date(now.getTime() - 60 * 86400000);
    const marks = await this.prisma.auditLog.findMany({
      where: { action: 'booking.no_show_auto', createdAt: { gte: since } },
      select: { tenantId: true, resourceId: true }, take: 20000,
    });
    const byTenant = new Map<string, string[]>();
    for (const m of marks) {
      if (!m.tenantId || !m.resourceId) continue;
      const list = byTenant.get(m.tenantId) ?? [];
      list.push(m.resourceId);
      byTenant.set(m.tenantId, list);
    }
    let repaired = 0;
    for (const [tenantId, ids] of byTenant) {
      try {
        const t = await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } });
        const appts = await this.prisma.appointment.findMany({
          where: { tenantId, id: { in: ids }, status: AppointmentStatus.NO_SHOW },
          select: { id: true, customerId: true, startTime: true },
        });
        if (!appts.length) continue;
        // Back to open for a moment so the pairing (which only touches open bookings) can move them to ARRIVED.
        const tz = t?.timezone || 'UTC';
        const custIds = [...new Set(appts.map((a) => a.customerId).filter((x): x is string => !!x))];
        if (!custIds.length) continue;
        const first = appts.reduce((m, a) => Math.min(m, +a.startTime), Infinity);
        const last = appts.reduce((m, a) => Math.max(m, +a.startTime), 0);
        const tickets = await this.prisma.walkIn.findMany({
          where: { tenantId, customerId: { in: custIds }, appointmentId: null, status: { not: WalkInStatus.CANCELLED }, createdAt: { gte: new Date(first - 86400000), lte: new Date(last + 86400000) } },
          select: { id: true, customerId: true, createdAt: true, appointmentId: true, status: true },
        });
        for (const p of matchMissedToVisits(appts, tickets as never, (d) => dayKeyTz(d, tz))) {
          const w = await this.prisma.walkIn.updateMany({ where: { id: p.walkInId, tenantId, appointmentId: null }, data: { appointmentId: p.appointmentId } });
          if (!w.count) continue;
          const a = await this.prisma.appointment.updateMany({ where: { id: p.appointmentId, tenantId, status: AppointmentStatus.NO_SHOW }, data: { status: AppointmentStatus.ARRIVED, arrivedAt: p.at } });
          if (!a.count) continue;
          repaired++;
          await this.audit.log({ tenantId, userId: null, action: 'booking.no_show_reverted', resourceType: 'appointment', resourceId: p.appointmentId, metadata: { walkInId: p.walkInId } }).catch(() => undefined);
        }
      } catch (e) {
        this.logger.warn(`false no-show repair failed for tenant ${tenantId}: ${(e as Error).message}`);
      }
    }
    return { tenants: byTenant.size, repaired };
  }

  private async closeMissed(tenantId: string, now: Date): Promise<number> {
    const t = await this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { timezone: true } });
    const tz = t?.timezone || 'UTC';
    const today = startOfDayTz(dayKeyTz(now, tz), tz); // the salon's own midnight
    const open: AppointmentStatus[] = [AppointmentStatus.PENDING, AppointmentStatus.ASSIGNED, AppointmentStatus.ACCEPTED, AppointmentStatus.CONFIRMED];
    const missed = await this.prisma.appointment.findMany({
      where: { tenantId, status: { in: open }, startTime: { lt: today } },
      select: { id: true, customerId: true, startTime: true },
    });
    if (!missed.length) return 0;
    // A customer who came in as a walk-in that day is not a no-show: tie her
    // ticket to the booking (ARRIVED) instead (walkins/booking-link.ts).
    const came = new Set(await this.pairWithVisits(tenantId, tz, missed as { id: string; customerId: string | null; startTime: Date }[]).catch(() => [] as string[]));
    const ids = missed.map((m) => m.id).filter((id) => !came.has(id));
    if (!ids.length) return 0;
    const res = await this.prisma.appointment.updateMany({
      where: { id: { in: ids }, tenantId, status: { in: open } },
      data: { status: AppointmentStatus.NO_SHOW, updatedAt: now },
    });
    for (const id of ids) {
      await this.audit.log({ tenantId, userId: null, action: 'booking.no_show_auto', resourceType: 'appointment', resourceId: id }).catch(() => undefined);
    }
    return res.count;
  }
}

/** A menu line as the public booking page receives it. */
export interface PublicServiceRow {
  id: string; name: string; description: string | null; durationMinutes: number; priceCents: number; discountPercent: number; currency: string;
  categoryId: string | null; isFeatured: boolean; priceFrom: boolean; imageUrl: string | null; sortOrder: number; walkInOnly?: boolean;
  addons: { id: string; name: string; durationMinutes: number; priceCents: number; currency: string; askAtBooking?: boolean }[];
}

/** The one sentence every channel says about a walk-in-only service. */
/**
 * May a desk booking be born ARRIVED? Only when its start is near now: up to
 * 30 minutes ahead (the chair is being set up) or up to 12 hours back (the
 * desk recording a customer already in the chair — the same 12 hours the
 * past-time rule allows).
 */
export function arrivedNowApplies(start: Date, now: Date): boolean {
  const t = start.getTime();
  if (!Number.isFinite(t)) return false;
  const ahead = t - now.getTime();
  return ahead <= 30 * 60_000 && ahead >= -12 * 60 * 60_000;
}

export function walkInOnlyMessage(serviceName: string): string {
  return `${serviceName} is walk-in only at this salon (first come, first served) — no appointment needed, just come in.`;
}
