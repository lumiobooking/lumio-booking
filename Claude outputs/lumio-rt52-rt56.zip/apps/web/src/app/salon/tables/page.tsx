'use client';

import { useCallback, useEffect, useState } from 'react';
import { SalonShell } from '../../../components/SalonShell';
import { useAuth } from '../../../lib/auth';
import { apiFetch } from '../../../lib/api';
import { ui } from '../../../lib/ui';
import { useLang, tr } from '../../../lib/i18n';
import { TableImport } from '../../../components/MenuTableImport';
import { FloorMap } from '../../../components/FloorMap';
import { TableQrCodes } from '../../../components/TableQrCodes';
import { useBulkSelect, BulkBar, BulkAllBox, BulkRowBox, runBulkDelete } from '../../../components/BulkDelete';

interface Table { id: string; name: string; seats: number; area: string | null; isActive: boolean; sortOrder: number }


export default function TablesPage() {
  return <SalonShell><Inner /></SalonShell>;
}

function Inner() {
  const { token, user } = useAuth();
  // The host at the door (staff with `bookings`) works the floor map; the table list is the owner's.
  const owner = user?.role !== 'STAFF';
  const { lang } = useLang();
  const t = (k: string) => tr(k, lang);
  const [tables, setTables] = useState<Table[]>([]);
  const bulk = useBulkSelect(tables.map((r) => r.id));
  const [err, setErr] = useState<string | null>(null);
  const [form, setForm] = useState({ name: '', seats: '2', area: '' });
  const [busy, setBusy] = useState(false);
  const [view, setView] = useState<'list' | 'map' | 'qr'>('list');
  // "Nhập bàn & sơ đồ từ Excel": template, upload, check, import (MenuTableImport).
  const [showImport, setShowImport] = useState(false);
  // The till's settings link straight to the QR codes (/salon/tables?view=qr).
  useEffect(() => {
    try { const v = new URLSearchParams(window.location.search).get('view'); if (v === 'qr' || v === 'map') setView(v); } catch { /* no window */ }
  }, []);
  const vi = lang === 'vi';

  const load = useCallback(async () => {
    if (!token || !owner) return;
    try { setTables(await apiFetch<Table[]>('/tables', { token })); }
    catch (e) { setErr(e instanceof Error ? e.message : (vi ? 'Không tải được danh sách bàn' : 'Failed to load')); }
  }, [token, owner]);
  useEffect(() => { load(); }, [load]);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) return;
    setBusy(true); setErr(null);
    try {
      await apiFetch('/tables', { method: 'POST', token, body: { name: form.name.trim(), seats: parseInt(form.seats, 10) || 2, area: form.area.trim() || undefined } });
      setForm({ name: '', seats: '2', area: '' });
      await load();
    } catch (e2) { setErr(e2 instanceof Error ? e2.message : 'Failed'); }
    finally { setBusy(false); }
  }

  async function patch(id: string, data: Partial<Table>) {
    try { await apiFetch(`/tables/${id}`, { method: 'PATCH', token, body: data }); await load(); }
    catch (e) { setErr(e instanceof Error ? e.message : (vi ? 'Không lưu được' : 'Failed')); }
  }
  async function remove(id: string) {
    try { await apiFetch(`/tables/${id}`, { method: 'DELETE', token }); await load(); }
    catch (e) { setErr(e instanceof Error ? e.message : (vi ? 'Không lưu được' : 'Failed')); }
  }

  async function loadSampleRes() {
    setBusy(true); setErr(null);
    try {
      const svcs = await apiFetch<{ id: string; name: string }[]>('/services', { token });
      const svc = svcs.find((sv) => /reserv|table/i.test(sv.name)) || svcs[0];
      if (!svc) { setErr('No reservation service — set this tenant to Restaurant first.'); return; }
      const at = (h: number, m: number) => { const d = new Date(); d.setHours(h, m, 0, 0); return d.toISOString(); };
      const RES: [string, string, string, number, string][] = [
        ['Emily', 'Tran', '4155550101', 2, at(17, 0)],
        ['Michael', 'Nguyen', '4155550102', 4, at(17, 30)],
        ['The Johnson', 'Family', '4155550103', 6, at(18, 0)],
        ['David', 'Chen', '4155550104', 10, at(18, 0)],
        ['Sarah', 'Pham', '4155550105', 2, at(18, 30)],
        ['James', 'Le', '4155550106', 4, at(19, 0)],
        ['Birthday', 'Party', '4155550107', 8, at(19, 0)],
        ['Jessica', 'Do', '4155550108', 2, at(19, 30)],
        ['Kevin', 'Vo', '4155550109', 4, at(19, 30)],
        ['Company', 'Group', '4155550110', 12, at(20, 0)],
        ['Amanda', 'Hoang', '4155550111', 2, at(20, 0)],
        ['Brian', 'Dang', '4155550112', 6, at(20, 30)],
      ];
      let n = 0;
      for (const [fn, ln, ph, party, startTime] of RES) {
        try { await apiFetch('/bookings', { method: 'POST', token, body: { serviceId: svc.id, startTime, partySize: party, customerFirstName: fn, customerLastName: ln, customerPhone: ph } }); n++; } catch { /* skip */ }
      }
      alert(vi ? `Đã thêm ${n} lượt đặt bàn mẫu cho hôm nay. Mở Lịch và chuyển sang chế độ xem Bàn.` : 'Added ' + n + ' reservations for today. Open Calendar and switch to the Tables view.');
    } catch (e) { setErr(e instanceof Error ? e.message : (vi ? 'Không lưu được' : 'Failed')); }
    finally { setBusy(false); }
  }

  return (
    <section style={{ maxWidth: view !== 'list' || !owner ? 1040 : 720 }}>
      <h1 style={{ fontSize: 22, margin: '0 0 4px' }}>{t('tb.title')}</h1>
      <p style={{ color: 'var(--c94a3b8)', fontSize: 14, marginTop: 0 }}>{t('tb.subtitle')}</p>
      {owner && <div role="tablist" style={{ display: 'inline-flex', gap: 4, padding: 3, borderRadius: 10, border: '1px solid var(--c334155)', marginBottom: 14 }}>
        {(['list', 'map', 'qr'] as const).map((v) => (
          <button key={v} type="button" role="tab" aria-selected={view === v} onClick={() => setView(v)}
            style={{ padding: '6px 14px', borderRadius: 8, border: 'none', cursor: 'pointer', fontSize: 13, background: view === v ? 'var(--c1e293b)' : 'transparent', color: 'var(--ccbd5e1)' }}>
            {v === 'list' ? (vi ? 'Danh sách' : 'List') : v === 'map' ? (vi ? 'Sơ đồ bàn' : 'Floor map') : (vi ? 'Mã QR gọi món' : 'QR codes')}
          </button>
        ))}
      </div>}
      {view === 'qr' && owner ? <TableQrCodes token={token} vi={vi} /> : view === 'map' || !owner ? <FloorMap token={token} vi={vi} canArrange={owner} /> : <>
      {err && <div style={ui.banner}>{err}</div>}

      <button type="button" onClick={() => setShowImport((x) => !x)} aria-expanded={showImport}
        style={{ ...ui.primaryBtn, marginBottom: 12, marginRight: 8 }}>
        ⇪ {vi ? 'Nhập bàn & sơ đồ từ Excel (có file mẫu)' : 'Import tables & floor plan from Excel (template included)'}
      </button>
      {showImport && token && (
        <TableImport token={token} vi={vi} existing={tables} onDone={() => { void load(); }} onClose={() => setShowImport(false)} />
      )}
      <button onClick={loadSampleRes} disabled={busy} style={{ padding: '7px 12px', borderRadius: 8, border: '1px solid var(--c334155)', background: 'transparent', color: 'var(--ccbd5e1)', fontSize: 13, cursor: 'pointer', marginBottom: 14 }}>{vi ? '+ Đặt bàn mẫu (hôm nay)' : '+ Sample reservations (today)'}</button>

      <form onSubmit={add} style={{ ...ui.card, display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
        <label style={{ flex: '2 1 150px' }}><span style={ui.label}>{t('tb.name')}</span>
          <input style={ui.input} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="T1" /></label>
        <label style={{ flex: '1 1 80px' }}><span style={ui.label}>{t('tb.seats')}</span>
          <input style={ui.input} type="number" min={1} max={50} value={form.seats} onChange={(e) => setForm({ ...form, seats: e.target.value })} /></label>
        <label style={{ flex: '2 1 130px' }}><span style={ui.label}>{t('tb.area')}</span>
          <input style={ui.input} value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} placeholder={vi ? 'Trong nhà / Sân vườn' : 'Indoor / Patio'} /></label>
        <button type="submit" disabled={busy} style={ui.primaryBtn}>{t('tb.add')}</button>
      </form>

      {tables.length > 0 && (
        <label style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 12, color: 'var(--c94a3b8)', cursor: 'pointer', marginTop: 14 }}>
          <BulkAllBox on={bulk.allOn} onChange={bulk.toggleAll} />
          {tr('bulk.selectAll', lang)}
        </label>
      )}
      <div style={{ marginTop: 10 }}>
        <BulkBar count={bulk.count} ids={bulk.sel} onClear={bulk.clear} onDelete={(ids) => runBulkDelete(ids, (id) => apiFetch(`/tables/${id}`, { method: 'DELETE', token }), load)} />
      </div>
      <div style={{ marginTop: 6, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {tables.length === 0 && <p style={{ color: 'var(--c64748b)', fontSize: 14 }}>{t('tb.empty')}</p>}
        {[...tables].sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' })).map((tb) => (
          <div key={tb.id} style={{ ...ui.card, display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap', padding: 12, opacity: tb.isActive ? 1 : 0.55, borderColor: bulk.has(tb.id) ? '#4338ca' : undefined, background: bulk.has(tb.id) ? 'var(--c1e1b4b)' : undefined }}>
            <BulkRowBox on={bulk.has(tb.id)} onChange={() => bulk.toggle(tb.id)} />
            <input style={{ ...ui.input, width: 110 }} value={tb.name}
              onChange={(e) => setTables((xs) => xs.map((x) => (x.id === tb.id ? { ...x, name: e.target.value } : x)))}
              onBlur={(e) => patch(tb.id, { name: e.target.value })} />
            <span style={{ color: 'var(--c94a3b8)', fontSize: 13 }}>{t('tb.seats')}</span>
            <input style={{ ...ui.input, width: 68 }} type="number" min={1} max={50} value={tb.seats}
              onChange={(e) => setTables((xs) => xs.map((x) => (x.id === tb.id ? { ...x, seats: parseInt(e.target.value, 10) || 1 } : x)))}
              onBlur={(e) => patch(tb.id, { seats: parseInt(e.target.value, 10) || 1 })} />
            <input style={{ ...ui.input, width: 130 }} value={tb.area ?? ''} placeholder={t('tb.area')}
              onChange={(e) => setTables((xs) => xs.map((x) => (x.id === tb.id ? { ...x, area: e.target.value } : x)))}
              onBlur={(e) => patch(tb.id, { area: e.target.value })} />
            <label style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, color: 'var(--ccbd5e1)' }}>
              <input type="checkbox" checked={tb.isActive} onChange={(e) => patch(tb.id, { isActive: e.target.checked })} />{t('tb.active')}
            </label>
            <button onClick={() => remove(tb.id)} style={{ marginLeft: 'auto', background: 'none', border: '1px solid #ef4444', color: 'var(--ink-bad)', borderRadius: 6, padding: '5px 10px', cursor: 'pointer', fontSize: 13 }}>{t('tb.delete')}</button>
          </div>
        ))}
      </div>
      </>}
    </section>
  );
}
